using wpfCSharp_LiveOnly_WPF.Models;
namespace wpfCSharp_LiveOnly_WPF.Services;
public sealed class IndicatorService
{
    public void ApplyAll(List<Candle> c)
    {
        ApplyEma(c, 12, null); ApplyEma(c, 20, (x, v) => x.Ema20 = v); ApplyEma(c, 26, null); ApplyEma(c, 50, (x, v) => x.Ema50 = v); ApplyEma(c, 200, (x, v) => x.Ema200 = v);
        ApplySma(c, 20, (x, v) => x.Sma20 = v); ApplySma(c, 50, (x, v) => x.Sma50 = v);
        ApplyVwap(c); ApplyAtr(c, 14); ApplyRsi(c, 14); ApplyMacd(c); ApplyAdx(c, 14); ApplyBands(c, 20); ApplyChannels(c, 20); ApplyRvol(c, 20); ApplySuperTrend(c, 10, 3m); ApplyVolumeProfile(c, 80); ApplyRoc(c, 14); ApplyCci(c, 20); ApplyStochastic(c, 14); ApplyMfi(c, 14); ApplyCmf(c, 20); ApplyObv(c); ApplyAdLine(c); ApplySmartFlow(c, 20); ApplyAbsorption(c, 20); ApplyHistoricalVolatility(c, 20);
    }
    private List<decimal> CalcEmaValues(List<Candle> c, int p){ var list=new List<decimal>(); decimal k=2m/(p+1), ema=0; for(int i=0;i<c.Count;i++){ema=i==0?c[i].Close:c[i].Close*k+ema*(1-k); list.Add(ema);} return list; }
    private void ApplyEma(List<Candle> c, int p, Action<Candle, decimal>? set){var values=CalcEmaValues(c,p); if(set!=null) for(int i=0;i<c.Count;i++) set(c[i],values[i]);}
    private void ApplySma(List<Candle> c, int p, Action<Candle, decimal> set){ for(int i=0;i<c.Count;i++) set(c[i], i+1<p?0:c.Skip(i-p+1).Take(p).Average(x=>x.Close)); }
    private void ApplyVwap(List<Candle> c){ decimal pv=0,vol=0; DateTime day=DateTime.MinValue; foreach(var x in c){ if(x.Time.Date!=day){day=x.Time.Date; pv=0; vol=0;} decimal typical=(x.High+x.Low+x.Close)/3; pv+=typical*x.Volume; vol+=x.Volume; x.Vwap=vol>0?pv/vol:0; } }
    private void ApplyAtr(List<Candle> c,int p){ decimal atr=0; for(int i=0;i<c.Count;i++){ decimal prev=i==0?c[i].Close:c[i-1].Close; decimal tr=Math.Max(c[i].High-c[i].Low,Math.Max(Math.Abs(c[i].High-prev),Math.Abs(c[i].Low-prev))); atr=i==0?tr:((atr*(p-1))+tr)/p; c[i].Atr14=atr; } }
    private void ApplyRsi(List<Candle> c,int p){ decimal gain=0,loss=0; for(int i=1;i<c.Count;i++){ decimal ch=c[i].Close-c[i-1].Close; gain=((gain*(p-1))+Math.Max(0,ch))/p; loss=((loss*(p-1))+Math.Max(0,-ch))/p; c[i].Rsi14=loss==0?100:100-(100/(1+gain/loss)); } }
    private void ApplyMacd(List<Candle> c){ var ema12=CalcEmaValues(c,12); var ema26=CalcEmaValues(c,26); var macd=ema12.Select((v,i)=>v-ema26[i]).ToList(); decimal k=2m/(9+1), sig=0; for(int i=0;i<c.Count;i++){ sig=i==0?macd[i]:macd[i]*k+sig*(1-k); c[i].Macd=macd[i]; c[i].MacdSignal=sig; c[i].MacdHistogram=macd[i]-sig; } }
    private void ApplyAdx(List<Candle> c,int p){ decimal trS=0,pdmS=0,mdmS=0,adx=0; for(int i=1;i<c.Count;i++){ decimal up=c[i].High-c[i-1].High, down=c[i-1].Low-c[i].Low; decimal pdm=up>down&&up>0?up:0, mdm=down>up&&down>0?down:0; decimal tr=Math.Max(c[i].High-c[i].Low,Math.Max(Math.Abs(c[i].High-c[i-1].Close),Math.Abs(c[i].Low-c[i-1].Close))); trS=((trS*(p-1))+tr)/p; pdmS=((pdmS*(p-1))+pdm)/p; mdmS=((mdmS*(p-1))+mdm)/p; decimal pdi=trS>0?100*pdmS/trS:0, mdi=trS>0?100*mdmS/trS:0; decimal dx=(pdi+mdi)>0?100*Math.Abs(pdi-mdi)/(pdi+mdi):0; adx=((adx*(p-1))+dx)/p; c[i].PlusDi14=pdi; c[i].MinusDi14=mdi; c[i].Adx14=adx; } }
    private void ApplyBands(List<Candle> c,int p){ for(int i=p-1;i<c.Count;i++){ var list=c.Skip(i-p+1).Take(p).Select(x=>x.Close).ToList(); decimal avg=list.Average(); decimal sd=(decimal)Math.Sqrt(list.Average(v=>Math.Pow((double)(v-avg),2))); c[i].BollMiddle=avg; c[i].BollUpper=avg+2*sd; c[i].BollLower=avg-2*sd; } }
    private void ApplyChannels(List<Candle> c,int p){ for(int i=p-1;i<c.Count;i++){ var list=c.Skip(i-p+1).Take(p); c[i].DonchianUpper=list.Max(x=>x.High); c[i].DonchianLower=list.Min(x=>x.Low); c[i].KeltnerUpper=c[i].Ema20+2*c[i].Atr14; c[i].KeltnerLower=c[i].Ema20-2*c[i].Atr14; } }
    private void ApplyRvol(List<Candle> c,int p){ for(int i=p-1;i<c.Count;i++){ decimal avg=c.Skip(i-p+1).Take(p).Average(x=>x.Volume); c[i].Rvol=avg>0?c[i].Volume/avg:0; } }
    private void ApplySuperTrend(List<Candle> c,int p,decimal m){ for(int i=0;i<c.Count;i++){ decimal mid=(c[i].High+c[i].Low)/2; c[i].SuperTrend=mid-m*c[i].Atr14; c[i].SuperTrendBullish=c[i].Close>=c[i].SuperTrend; } }
    private void ApplyVolumeProfile(List<Candle> c,int lookback){ var recent=c.TakeLast(Math.Min(lookback,c.Count)).ToList(); if(!recent.Any()) return; decimal poc=recent.GroupBy(x=>Math.Round(x.Close/10m)*10m).OrderByDescending(g=>g.Sum(x=>x.Volume)).First().Key; foreach(var x in c) x.VolumeProfilePoc=poc; }

    private void ApplyRoc(List<Candle> c, int p)
    {
        for (int i = p; i < c.Count; i++)
            c[i].Roc14 = c[i - p].Close == 0 ? 0 : ((c[i].Close - c[i - p].Close) / c[i - p].Close) * 100;
    }
    private void ApplyCci(List<Candle> c, int p)
    {
        for (int i = p - 1; i < c.Count; i++)
        {
            var tp = c.Skip(i - p + 1).Take(p).Select(x => (x.High + x.Low + x.Close) / 3m).ToList();
            decimal avg = tp.Average();
            decimal md = tp.Average(x => Math.Abs(x - avg));
            c[i].Cci20 = md == 0 ? 0 : (tp[^1] - avg) / (0.015m * md);
        }
    }
    private void ApplyStochastic(List<Candle> c, int p)
    {
        for (int i = p - 1; i < c.Count; i++)
        {
            var list = c.Skip(i - p + 1).Take(p).ToList();
            decimal high = list.Max(x => x.High);
            decimal low = list.Min(x => x.Low);
            c[i].StochasticK14 = high == low ? 0 : ((c[i].Close - low) / (high - low)) * 100;
        }
    }
    private void ApplyMfi(List<Candle> c, int p)
    {
        for (int i = p; i < c.Count; i++)
        {
            decimal pos = 0, neg = 0;
            for (int j = i - p + 1; j <= i; j++)
            {
                decimal tp = (c[j].High + c[j].Low + c[j].Close) / 3m;
                decimal prevTp = (c[j - 1].High + c[j - 1].Low + c[j - 1].Close) / 3m;
                decimal money = tp * c[j].Volume;
                if (tp > prevTp) pos += money;
                else if (tp < prevTp) neg += money;
            }
            c[i].Mfi14 = neg == 0 ? 100 : 100 - (100 / (1 + pos / neg));
        }
    }
    private void ApplyCmf(List<Candle> c, int p)
    {
        for (int i = p - 1; i < c.Count; i++)
        {
            decimal mfv = 0, vol = 0;
            foreach (var x in c.Skip(i - p + 1).Take(p))
            {
                decimal range = x.High - x.Low;
                if (range == 0) continue;
                decimal multiplier = ((x.Close - x.Low) - (x.High - x.Close)) / range;
                mfv += multiplier * x.Volume;
                vol += x.Volume;
            }
            c[i].Cmf20 = vol == 0 ? 0 : mfv / vol;
        }
    }
    private void ApplyObv(List<Candle> c)
    {
        decimal obv = 0;
        for (int i = 1; i < c.Count; i++)
        {
            if (c[i].Close > c[i - 1].Close) obv += c[i].Volume;
            else if (c[i].Close < c[i - 1].Close) obv -= c[i].Volume;
            c[i].Obv = obv;
        }
    }
    private void ApplyAdLine(List<Candle> c)
    {
        decimal ad = 0;
        foreach (var x in c)
        {
            decimal range = x.High - x.Low;
            if (range != 0)
            {
                decimal multiplier = ((x.Close - x.Low) - (x.High - x.Close)) / range;
                ad += multiplier * x.Volume;
            }
            x.AdLine = ad;
        }
    }
    private void ApplySmartFlow(List<Candle> c, int p)
    {
        for (int i = p - 1; i < c.Count; i++)
        {
            var list = c.Skip(i - p + 1).Take(p).ToList();
            decimal bull = list.Where(x => x.Close >= x.Open).Sum(x => x.Volume);
            decimal bear = list.Where(x => x.Close < x.Open).Sum(x => x.Volume);
            decimal total = bull + bear;
            c[i].SmartFlow = total == 0 ? 0 : ((bull - bear) / total) * 100;
        }
    }
    private void ApplyAbsorption(List<Candle> c, int p)
    {
        for (int i = p - 1; i < c.Count; i++)
        {
            decimal avgVol = c.Skip(i - p + 1).Take(p).Average(x => x.Volume);
            decimal range = c[i].High - c[i].Low;
            decimal body = Math.Abs(c[i].Close - c[i].Open);
            if (avgVol == 0 || range == 0) { c[i].AbsorptionScore = 0; continue; }
            decimal volRatio = c[i].Volume / avgVol;
            decimal bodyRatio = body / range;
            c[i].AbsorptionScore = volRatio >= 1.5m && bodyRatio <= 0.35m ? 80 : volRatio >= 1.2m && bodyRatio <= 0.50m ? 60 : 30;
        }
    }
    private void ApplyHistoricalVolatility(List<Candle> c, int p)
    {
        for (int i = p; i < c.Count; i++)
        {
            var returns = new List<double>();
            for (int j = i - p + 1; j <= i; j++)
            {
                if (c[j - 1].Close > 0)
                    returns.Add(Math.Log((double)(c[j].Close / c[j - 1].Close)));
            }
            if (returns.Count == 0) continue;
            double avg = returns.Average();
            double variance = returns.Average(x => Math.Pow(x - avg, 2));
            c[i].HistoricalVolatility20 = (decimal)(Math.Sqrt(variance) * Math.Sqrt(252) * 100);
        }
    }

    public TrendSnapshot BuildTrend(List<Candle> c)
    {
        var x=c.LastOrDefault(); if(x==null) return new TrendSnapshot();
        bool bullEma=x.Ema20>x.Ema50&&x.Ema50>x.Ema200, bullSma=x.Sma20>x.Sma50, aboveVwap=x.Close>x.Vwap;
        string band=x.Close>x.BollUpper?"Above Upper":x.Close<x.BollLower?"Below Lower":"Inside";
        string don=x.Close>=x.DonchianUpper?"Break High":x.Close<=x.DonchianLower?"Break Low":"Inside";
        string kel=x.Close>x.KeltnerUpper?"Above Upper":x.Close<x.KeltnerLower?"Below Lower":"Inside";
        return new TrendSnapshot
        {
            EmaTrend=bullEma?"Bullish":"Bearish/Flat",
            SmaTrend=bullSma?"Bullish":"Bearish/Flat",
            VwapStatus=aboveVwap?"Above":"Below",
            Atr=x.Atr14,
            Rsi=x.Rsi14,
            Macd=x.Macd,
            MacdSignal=x.MacdSignal,
            MacdStatus=x.Macd>x.MacdSignal?"Bullish":"Bearish",
            Adx=x.Adx14,
            AdxStatus=x.Adx14>=25?"Strong":"Weak",
            SuperTrend=x.SuperTrendBullish?"Buy":"Sell",
            BollingerStatus=band,
            DonchianStatus=don,
            KeltnerStatus=kel,
            Rvol=x.Rvol,
            VolumeProfilePoc=x.VolumeProfilePoc,
            Roc=x.Roc14,
            Cci=x.Cci20,
            Stochastic=x.StochasticK14,
            Mfi=x.Mfi14,
            Cmf=x.Cmf20,
            Obv=x.Obv,
            AdLine=x.AdLine,
            SmartFlow=x.SmartFlow,
            AbsorptionScore=x.AbsorptionScore,
            HistoricalVolatility=x.HistoricalVolatility20,
            TrendBias=bullEma&&aboveVwap&&x.Macd>x.MacdSignal?"Bullish":(!aboveVwap&&x.Macd<x.MacdSignal?"Bearish":"Neutral"),
            EmaBrush=bullEma?"#19C37D":"#FF4D4D",
            SmaBrush=bullSma?"#19C37D":"#FF4D4D",
            VwapBrush=aboveVwap?"#19C37D":"#FF4D4D",
            RsiBrush=x.Rsi14>=70?"#FFC857":x.Rsi14<=30?"#2DD4FF":"#E7EEFB",
            MacdBrush=x.Macd>x.MacdSignal?"#19C37D":"#FF4D4D",
            AdxBrush=x.Adx14>=25?"#FFC857":"#93A4BD",
            SuperTrendBrush=x.SuperTrendBullish?"#19C37D":"#FF4D4D",
            RvolBrush=x.Rvol>=1.5m?"#FFC857":x.Rvol>=1.1m?"#2DD4FF":"#93A4BD",
            BollingerBrush=band=="Above Upper"?"#19C37D":band=="Below Lower"?"#FF4D4D":"#93A4BD",
            DonchianBrush=don=="Break High"?"#19C37D":don=="Break Low"?"#FF4D4D":"#93A4BD",
            KeltnerBrush=kel=="Above Upper"?"#19C37D":kel=="Below Lower"?"#FF4D4D":"#93A4BD",
            RocBrush=x.Roc14>0?"#19C37D":x.Roc14<0?"#FF4D4D":"#93A4BD",
            CciBrush=x.Cci20>=100?"#19C37D":x.Cci20<=-100?"#FF4D4D":"#FFC857",
            StochasticBrush=x.StochasticK14>=80?"#FFC857":x.StochasticK14<=20?"#2DD4FF":x.StochasticK14>=50?"#19C37D":"#FF4D4D",
            MfiBrush=x.Mfi14>=80?"#FFC857":x.Mfi14<=20?"#2DD4FF":x.Mfi14>=50?"#19C37D":"#FF4D4D",
            CmfBrush=x.Cmf20>0?"#19C37D":x.Cmf20<0?"#FF4D4D":"#93A4BD",
            ObvBrush=x.Obv>=0?"#19C37D":"#FF4D4D",
            AdLineBrush=x.AdLine>=0?"#19C37D":"#FF4D4D",
            SmartFlowBrush=x.SmartFlow>=0?"#19C37D":"#FF4D4D",
            AbsorptionBrush=x.AbsorptionScore>=60?"#19C37D":x.AbsorptionScore>=30?"#FFC857":"#93A4BD",
            HistoricalVolatilityBrush=x.HistoricalVolatility20>=40?"#FF4D4D":x.HistoricalVolatility20>=20?"#FFC857":"#19C37D"
        };
    }
}
