namespace wpfCSharp_LiveOnly_WPF.Models;

public sealed class OptionExpiryItem
{
    public string Label { get; set; } = string.Empty;
    public string Timestamp { get; set; } = string.Empty;

    public override string ToString()
    {
        return Label;
    }
}
