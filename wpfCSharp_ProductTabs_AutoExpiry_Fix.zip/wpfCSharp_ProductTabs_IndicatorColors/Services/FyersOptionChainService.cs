using Newtonsoft.Json.Linq;
using wpfCSharp_LiveOnly_WPF.Models;
namespace wpfCSharp_LiveOnly_WPF.Services;
public sealed class FyersOptionChainService
{
    private readonly FyersApiClient _api;
    private readonly Dictionary<string, OptionLeg> _previous = new(StringComparer.OrdinalIgnoreCase);
    public decimal CurrentSpot { get; private set; }
    public string CurrentExpiry { get; private set; } = "Nearest / Current";
    public List<OptionExpiryItem> ExpiryItems { get; } = new();
    public string SelectedExpiryTimestamp { get; set; } = string.Empty;
    public FyersOptionChainService(FyersApiClient api) => _api = api;
    public async Task<List<OptionChainRow>> GetRowsAsync(string symbol, int strikeCount)
    {
        string strikeParam = strikeCount <= 0 ? string.Empty : $"&strikecount={strikeCount}";
        string timestampParam = string.IsNullOrWhiteSpace(SelectedExpiryTimestamp)
            ? string.Empty
            : Uri.EscapeDataString(SelectedExpiryTimestamp);
        string url = "https://api-t1.fyers.in/data/options-chain-v3" +
            $"?symbol={Uri.EscapeDataString(symbol)}{strikeParam}&timestamp={timestampParam}&greeks=1";
        string json = await _api.GetAsync(url);
        var rows = ParseOptionChain(json);
        await ApplyQuotesAsync(rows);
        CalculateSignals(rows);
        SaveSnapshot(rows);
        return rows;
    }
    private List<OptionChainRow> ParseOptionChain(string json)
    {
        JObject root = JObject.Parse(json);
        ParseExpiryData(root);
        JArray chain = root["data"]?["optionsChain"] as JArray ?? new JArray();
        CurrentSpot = GetDec(root["data"], "underlyingValue", "underlying_value", "ltp", "spot");
        var map = new Dictionary<decimal, OptionChainRow>();
        foreach (JToken item in chain)
        {
            decimal strike = GetDec(item, "strike_price", "strikePrice", "strike");
            if (strike <= 0) continue;
            if (!map.ContainsKey(strike)) map[strike] = new OptionChainRow { Strike = strike };
            string type = GetStr(item, "option_type", "optionType", "type", "symbol");
            if (type.Contains("CE", StringComparison.OrdinalIgnoreCase)) map[strike].CE = ParseLeg(item, "CE", strike);
            if (type.Contains("PE", StringComparison.OrdinalIgnoreCase)) map[strike].PE = ParseLeg(item, "PE", strike);
            if (item["CE"] != null) map[strike].CE = ParseLeg(item["CE"]!, "CE", strike);
            if (item["PE"] != null) map[strike].PE = ParseLeg(item["PE"]!, "PE", strike);
        }
        var rows = map.Values.OrderBy(x => x.Strike).ToList();
        if (rows.Count > 0)
        {
            decimal atm = rows.OrderBy(x => Math.Abs(x.Strike - CurrentSpot)).First().Strike;
            foreach (var row in rows)
            {
                row.IsAtm = row.Strike == atm;
                row.StrikeBrush = row.IsAtm ? "#2DD4FF" : "#E7EEFB";
            }
        }
        CalculateGreeks(rows);
        return rows;
    }
    private void ParseExpiryData(JObject root)
    {
        ExpiryItems.Clear();

        JArray expiryData =
            root["data"]?["expiryData"] as JArray
            ?? root["data"]?["expiry_data"] as JArray
            ?? root["expiryData"] as JArray
            ?? new JArray();

        foreach (JToken item in expiryData)
        {
            string label = GetStr(item, "date", "expiryDate", "label");
            string timestamp = GetStr(item, "expiry", "timestamp", "expiry_ts", "expiryTs");

            if (string.IsNullOrWhiteSpace(label) && string.IsNullOrWhiteSpace(timestamp))
                continue;

            ExpiryItems.Add(new OptionExpiryItem
            {
                Label = string.IsNullOrWhiteSpace(label) ? timestamp : label,
                Timestamp = timestamp
            });
        }

        if (ExpiryItems.Count == 0)
        {
            CurrentExpiry = "Nearest / Current";
            return;
        }

        // Always auto-select the nearest/current expiry returned by FYERS.
        // No manual expiry selection is used in the UI.
        SelectedExpiryTimestamp = ExpiryItems[0].Timestamp;
        CurrentExpiry = ExpiryItems[0].Label;
    }

    private OptionLeg ParseLeg(JToken t, string side, decimal strike) => new()
    {
        Symbol = GetStr(t, "symbol", "n"), Side = side, Strike = strike,
        Ltp = GetDec(t, "ltp", "lp", "last_price", "lastPrice"), Oi = GetDec(t, "oi", "open_interest", "openInterest"),
        OiChange = GetDec(t, "oich", "oi_change", "oiChange", "change_oi", "changeOi"), Volume = GetDec(t, "volume", "vol", "v"),
        Iv = GetDec(t, "iv", "implied_volatility", "impliedVolatility"), Delta = GetGreek(t, "delta"), Gamma = GetGreek(t, "gamma"), Theta = GetGreek(t, "theta"), Vega = GetGreek(t, "vega")
    };
    private async Task ApplyQuotesAsync(List<OptionChainRow> rows)
    {
        var symbols = rows.SelectMany(x => new[] { x.CE?.Symbol, x.PE?.Symbol }).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().Take(50).ToList();
        if (symbols.Count == 0) return;
        string url = "https://api-t1.fyers.in/data/quotes?symbols=" + Uri.EscapeDataString(string.Join(",", symbols));
        string json = await _api.GetAsync(url);
        JObject root = JObject.Parse(json);
        var map = new Dictionary<string, JToken>(StringComparer.OrdinalIgnoreCase);
        foreach (JToken q in root["d"] as JArray ?? new JArray())
        {
            string s = GetStr(q, "n", "symbol");
            if (!string.IsNullOrWhiteSpace(s)) map[s] = q["v"] ?? q;
        }
        foreach (var leg in rows.SelectMany(x => new[] { x.CE, x.PE }).Where(x => x != null).Cast<OptionLeg>())
        {
            if (!map.TryGetValue(leg.Symbol, out JToken? v)) continue;
            decimal lp = GetDec(v, "lp", "ltp"); if (lp > 0) leg.Ltp = lp;
            leg.Volume = Math.Max(leg.Volume, GetDec(v, "volume", "vol", "v"));
            leg.PriceChange = GetDec(v, "ch", "change");
        }
    }
    private void CalculateSignals(List<OptionChainRow> rows)
    {
        foreach (var leg in rows.SelectMany(x => new[] { x.CE, x.PE }).Where(x => x != null).Cast<OptionLeg>())
        {
            decimal oiDiff, priceDiff;
            if (_previous.TryGetValue($"{leg.Strike}_{leg.Side}", out var prev)) { oiDiff = leg.Oi - prev.Oi; priceDiff = leg.Ltp - prev.Ltp; }
            else { oiDiff = leg.OiChange; priceDiff = leg.PriceChange; }
            leg.Signal = BuildSignal(oiDiff, priceDiff);
            leg.SignalBrush = BrushForSignal(leg.Signal, leg.Side);
            leg.PriceBrush = PriceBrush(leg.PriceChange);
            leg.IvBrush = IvBrush(leg.Iv);
            leg.OiChangeBrush = OiChangeBrush(leg.OiChange, leg.Side);
            leg.DeltaBrush = DeltaBrush(leg.Delta, leg.Side);
            leg.GammaBrush = leg.Gamma != 0 ? "#2DD4FF" : "#93A4BD";
            leg.ThetaBrush = leg.Theta < 0 ? "#FF4D4D" : leg.Theta > 0 ? "#19C37D" : "#93A4BD";
            leg.VegaBrush = leg.Vega != 0 ? "#C084FC" : "#93A4BD";
        }
    }
    private static string BuildSignal(decimal oi, decimal price)
    {
        if (oi > 0 && price > 0) return "Long Build";
        if (oi > 0 && price < 0) return "Short Build";
        if (oi < 0 && price < 0) return "Long Unwind";
        if (oi < 0 && price > 0) return "Short Cover";
        if (oi > 0) return "OI Added";
        if (oi < 0) return "OI Reduced";
        return "Neutral";
    }
    private static string BrushForSignal(string signal, string side) => signal switch
    {
        "Long Build" => "#19C37D", "Short Build" => "#FF4D4D", "Short Cover" => "#2DD4FF", "Long Unwind" => "#FFC857",
        "OI Added" => side == "CE" ? "#D94B4B" : "#36C983", "OI Reduced" => "#B59B3B", _ => "#93A4BD"
    };

    private static string PriceBrush(decimal priceChange)
    {
        if (priceChange > 0) return "#19C37D";
        if (priceChange < 0) return "#FF4D4D";
        return "#E7EEFB";
    }
    private static string IvBrush(decimal iv)
    {
        if (iv >= 25) return "#FFC857";
        if (iv >= 18) return "#E7EEFB";
        return "#93A4BD";
    }
    private static string OiChangeBrush(decimal oiChange, string side)
    {
        if (oiChange == 0) return "#93A4BD";
        if (side == "CE") return oiChange > 0 ? "#FF4D4D" : "#2DD4FF";
        return oiChange > 0 ? "#19C37D" : "#FFC857";
    }
    private static string DeltaBrush(decimal delta, string side)
    {
        if (delta == 0) return "#93A4BD";
        if (side == "CE") return delta > 0 ? "#19C37D" : "#FFC857";
        return delta < 0 ? "#FF4D4D" : "#FFC857";
    }
    private void SaveSnapshot(List<OptionChainRow> rows)
    {
        foreach (var leg in rows.SelectMany(x => new[] { x.CE, x.PE }).Where(x => x != null).Cast<OptionLeg>())
            _previous[$"{leg.Strike}_{leg.Side}"] = new OptionLeg { Symbol = leg.Symbol, Side = leg.Side, Strike = leg.Strike, Ltp = leg.Ltp, Oi = leg.Oi };
    }
    private void CalculateGreeks(List<OptionChainRow> rows)
    {
        if (CurrentSpot <= 0) return;
        double t = Math.Max(1.0 / 365.0, 7.0 / 365.0), r = 0.06;
        foreach (var leg in rows.SelectMany(x => new[] { x.CE, x.PE }).Where(x => x != null).Cast<OptionLeg>())
        {
            double sigma = leg.Iv > 0 ? (double)leg.Iv / 100.0 : 0.20, s = (double)CurrentSpot, k = (double)leg.Strike, sqrtT = Math.Sqrt(t);
            double d1 = (Math.Log(s / k) + (r + 0.5 * sigma * sigma) * t) / (sigma * sqrtT), d2 = d1 - sigma * sqrtT;
            double pdf = Math.Exp(-0.5 * d1 * d1) / Math.Sqrt(2 * Math.PI), cdf = N(d1);
            leg.Delta = (decimal)(leg.Side == "CE" ? cdf : cdf - 1); leg.Gamma = (decimal)(pdf / (s * sigma * sqrtT));
            leg.Theta = (decimal)((-(s * pdf * sigma) / (2 * sqrtT)) / 365.0); leg.Vega = (decimal)(s * pdf * sqrtT / 100.0);
        }
    }
    private static double N(double x) { double sign = x < 0 ? -1 : 1; x = Math.Abs(x) / Math.Sqrt(2); double t = 1 / (1 + 0.3275911 * x); double y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - .284496736) * t + .254829592) * t * Math.Exp(-x * x); return .5 * (1 + sign * y); }
    private static decimal GetDec(JToken? t, params string[] names) { if (t == null) return 0; foreach (string n in names) if (decimal.TryParse(t[n]?.ToString(), out var d)) return d; return 0; }
    private static string GetStr(JToken? t, params string[] names) { if (t == null) return string.Empty; foreach (string n in names) { string? v = t[n]?.ToString(); if (!string.IsNullOrWhiteSpace(v)) return v; } return string.Empty; }
    private static decimal GetGreek(JToken t, string n) => GetDec(t, n) != 0 ? GetDec(t, n) : GetDec(t["greeks"], n);
}
