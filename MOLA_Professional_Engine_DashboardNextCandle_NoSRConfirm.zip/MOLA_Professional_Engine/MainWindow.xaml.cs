using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using wpfCSharp_LiveOnly_WPF.Models;
using wpfCSharp_LiveOnly_WPF.ViewModels;
namespace wpfCSharp_LiveOnly_WPF;
public partial class MainWindow : Window
{
    private readonly MainViewModel _vm = new();
    public MainWindow()
    {
        InitializeComponent();
        DataContext = _vm;
        _vm.Candles.CollectionChanged += Candles_CollectionChanged;
        _vm.SignalPopupRequested += Vm_SignalPopupRequested;
    }
    private void Vm_SignalPopupRequested(SignalPopupInfo popup)
    {
        Dispatcher.Invoke(() =>
            MessageBox.Show(popup.Message, popup.Title, MessageBoxButton.OK, MessageBoxImage.Information));
    }

    private void Candles_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) => DrawCharts();
    private void ChartCanvas_SizeChanged(object sender, SizeChangedEventArgs e) => DrawCharts();
    private void DrawCharts()
    {
        ChartCanvas.Children.Clear(); VolumeCanvas.Children.Clear();
        var candles = _vm.Candles.ToList(); if (candles.Count < 2 || ChartCanvas.ActualWidth <= 0 || ChartCanvas.ActualHeight <= 0) return;
        decimal max = candles.Max(x => Math.Max(x.High, Math.Max(x.BollUpper, Math.Max(x.DonchianUpper, x.KeltnerUpper))));
        decimal min = candles.Min(x => { var vals = new[] { x.Low, x.BollLower == 0 ? x.Low : x.BollLower, x.DonchianLower == 0 ? x.Low : x.DonchianLower, x.KeltnerLower == 0 ? x.Low : x.KeltnerLower }; return vals.Min(); });
        if (max <= min) return;
        double w = ChartCanvas.ActualWidth / candles.Count; double h = ChartCanvas.ActualHeight;
        double Y(decimal v) => h - (double)((v - min) / (max - min)) * h;
        DrawLine(candles.Select((c, i) => (i * w + w / 2, Y(c.Ema20))).ToList(), Brushes.Gold, 1.2);
        DrawLine(candles.Select((c, i) => (i * w + w / 2, Y(c.Ema50))).ToList(), Brushes.Orange, 1.2);
        DrawLine(candles.Select((c, i) => (i * w + w / 2, Y(c.Ema200))).ToList(), Brushes.White, 1.0);
        DrawLine(candles
            .Select((c, i) => new { c, i })
            .Where(x => x.c.Vwap > 0)
            .Select(x => (x.i * w + w / 2, Y(x.c.Vwap)))
            .ToList(), Brushes.DeepSkyBlue, 1.4);
        DrawLine(candles
            .Select((c, i) => new { c, i })
            .Where(x => x.c.SuperTrend > 0)
            .Select(x => (x.i * w + w / 2, Y(x.c.SuperTrend)))
            .ToList(), Brushes.LimeGreen, 1.0);
        decimal spotLine = _vm.Spot > 0 ? _vm.Spot : candles.Last().Close;
        if (spotLine >= min && spotLine <= max)
        {
            double sy = Y(spotLine);
            var line = new Line { X1 = 0, X2 = ChartCanvas.ActualWidth, Y1 = sy, Y2 = sy, Stroke = Brushes.DeepSkyBlue, StrokeThickness = 1.2, StrokeDashArray = new DoubleCollection { 4, 3 } };
            ChartCanvas.Children.Add(line);
            var label = new TextBlock { Text = $"SPOT / ATM {spotLine:0.00}", Foreground = Brushes.DeepSkyBlue, FontSize = 10, FontWeight = FontWeights.Bold };
            Canvas.SetLeft(label, 6); Canvas.SetTop(label, Math.Max(0, sy - 14)); ChartCanvas.Children.Add(label);
        }

        for (int i = 0; i < candles.Count; i++)
        {
            Candle c = candles[i]; double x = i * w + w / 2; Brush brush = c.Close >= c.Open ? Brushes.LimeGreen : Brushes.Red;
            var wick = new Line { X1 = x, X2 = x, Y1 = Y(c.High), Y2 = Y(c.Low), Stroke = brush, StrokeThickness = 1 };
            ChartCanvas.Children.Add(wick);
            double top = Y(Math.Max(c.Open, c.Close)); double bot = Y(Math.Min(c.Open, c.Close));
            var rect = new Rectangle { Width = Math.Max(2, w * .65), Height = Math.Max(2, bot - top), Fill = brush, Opacity = .85 };
            Canvas.SetLeft(rect, x - rect.Width / 2); Canvas.SetTop(rect, top); ChartCanvas.Children.Add(rect);
        }
        decimal maxVol = candles.Max(x => x.Volume); if (maxVol > 0)
        {
            double vh = VolumeCanvas.ActualHeight;
            for (int i = 0; i < candles.Count; i++)
            {
                Candle c = candles[i]; double barH = (double)(c.Volume / maxVol) * vh; Brush brush = c.Close >= c.Open ? Brushes.LimeGreen : Brushes.Red;
                var r = new Rectangle { Width = Math.Max(2, w * .65), Height = barH, Fill = brush, Opacity = c.Rvol20 >= 1.5m ? .95 : .45 };
                Canvas.SetLeft(r, i * w + (w - r.Width) / 2); Canvas.SetTop(r, vh - barH); VolumeCanvas.Children.Add(r);
            }
        }
    }

    private void UpdateOhlcHeader(Candle c) { }

    private string BuildCandleTooltip(Candle c)
    {
        return
            $"Time   : {c.Time:dd-MMM-yyyy HH:mm}\n" +
            $"Open   : {c.Open:0.00}\n" +
            $"High   : {c.High:0.00}\n" +
            $"Low    : {c.Low:0.00}\n" +
            $"Close  : {c.Close:0.00}\n" +
            $"Volume : {FormatQty(c.Volume)}\n" +
            $"EMA20  : {c.Ema20:0.00}\n" +
            $"EMA50  : {c.Ema50:0.00}\n" +
            $"EMA200 : {c.Ema200:0.00}\n" +
            $"VWAP   : {c.Vwap:0.00}\n" +
            $"ATR    : {c.Atr14:0.00}\n" +
            $"RSI    : {c.Rsi14:0.00}\n" +
            $"MACD   : {c.Macd:0.00}\n" +
            $"ADX    : {c.Adx14:0.00}\n" +
            $"RVOL10 : {c.Rvol10:0.00}x\n" +
            $"RVOL20 : {c.Rvol20:0.00}x\n" +
            $"StdDev : {c.StdDev20:0.00}\n" +
            $"DEMA20 : {c.Dema20:0.00}\n" +
            $"TEMA20 : {c.Tema20:0.00}\n" +
            $"D vs T : {c.DemaTemaSignal}\n" +
            $"VWMA20 : {c.Vwma20:0.00}\n" +
            $"TTM    : {c.TtmSqueezeStatus}\n" +
            $"Vortex : {c.VortexSignal}  (+{c.VortexPlus14:0.00}/-{c.VortexMinus14:0.00})\n" +
            $"Chand. : {c.ChandelierSignal}  L {c.ChandelierLong:0.00} S {c.ChandelierShort:0.00}\n" +
            $"Elder  : {c.ElderRaySignal}  Bull {c.ElderBullPower:0.00} Bear {c.ElderBearPower:0.00}\n" +
            $"T3/T20 : {c.Tema3VsTema20Signal}\n" +
            $"P/EMA3 : {c.PriceVsEma3Signal}\n" +
            $"Camar. : {c.CamarillaZone}\n" +
            $"Aroon  : {c.AroonSignal}  U {c.AroonUp14:0.00} D {c.AroonDown14:0.00}\n" +
            $"PSAR   : {c.PsarSignal}  {c.Psar:0.00}\n" +
            $"BOS    : {c.BosSignal}\n" +
            $"Liq    : {c.LiquiditySignal}\n" +
            $"OB     : {c.OrderBlockSignal}  H {c.OrderBlockHigh:0.00} L {c.OrderBlockLow:0.00}\n" +
            $"FVG    : {c.FvgSignal}  Zone {c.FvgLow:0.00}-{c.FvgHigh:0.00}\n" +
            $"ST     : {(c.SuperTrendBullish ? "Buy" : "Sell")}  Score {(c.SuperTrendBullish ? 80 : 25)}\n" +
            $"SMC    : {c.SmartMoneyStructureSignal}  Score {c.SmartMoneyStructureScore}\n" +
            $"Pattern: {c.CandlestickPattern}\n" +
            $"Bias   : {c.CandlestickBias}";
    }

    private static string FormatQty(decimal value)
    {
        decimal abs = Math.Abs(value);
        if (abs >= 10000000m) return (value / 10000000m).ToString("0.00") + "Cr";
        if (abs >= 100000m) return (value / 100000m).ToString("0.00") + "L";
        if (abs >= 1000m) return (value / 1000m).ToString("0.00") + "K";
        return value.ToString("0");
    }


    private void DrawPriceLevel(string label, decimal value, double y, Brush brush, bool isResistance)
    {
        if (y < 0 || y > ChartCanvas.ActualHeight) return;
        var line = new Line
        {
            X1 = 0,
            X2 = ChartCanvas.ActualWidth,
            Y1 = y,
            Y2 = y,
            Stroke = brush,
            StrokeThickness = isResistance ? 1.1 : 1.0,
            StrokeDashArray = new DoubleCollection { 3, 4 },
            Opacity = .72
        };
        ChartCanvas.Children.Add(line);
        var text = new TextBlock
        {
            Text = $"{label} {value:0.00}",
            Foreground = brush,
            FontSize = 9,
            FontWeight = FontWeights.Bold,
            Background = new SolidColorBrush(Color.FromArgb(120, 7, 16, 31)),
            Padding = new Thickness(3, 0, 3, 0)
        };
        Canvas.SetLeft(text, isResistance ? ChartCanvas.ActualWidth - 88 : 6);
        Canvas.SetTop(text, Math.Max(0, Math.Min(ChartCanvas.ActualHeight - 14, y - 7)));
        ChartCanvas.Children.Add(text);
    }

    private static Brush BrushFromHex(string hex)
    {
        try
        {
            return (Brush)new BrushConverter().ConvertFromString(hex)!;
        }
        catch
        {
            return Brushes.Gray;
        }
    }

    private void DrawLine(List<(double x, double y)> points, Brush brush, double thickness)
    {
        if (points.Count < 2) return;
        var geo = new StreamGeometry(); using (var ctx = geo.Open()) { ctx.BeginFigure(new Point(points[0].x, points[0].y), false, false); ctx.PolyLineTo(points.Skip(1).Select(p => new Point(p.x, p.y)).ToList(), true, false); }
        ChartCanvas.Children.Add(new Path { Data = geo, Stroke = brush, StrokeThickness = thickness, Opacity = .9 });
    }
    private void RealTradingConfirm_Click(object sender, RoutedEventArgs e)
    {
        var result = MessageBox.Show("Real Trading mode can cause financial loss if broker execution is connected." +
            "This project build keeps broker execution locked and does not send orders." +
            "Do you want to confirm Real Trading preview mode?",
            "Confirm Real Trading Preview",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);

        if (result == MessageBoxResult.Yes)
            _vm.ConfirmRealTradingPreview();
    }

}
