using wpfCSharp_LiveOnly_WPF.Models;

namespace wpfCSharp_LiveOnly_WPF.Services;

public sealed class SmartMoneyService
{
    public SmartMoneySnapshot Build(TrendSnapshot t, List<OptionChainRow> rows, decimal spot)
    {
        decimal ceChg = rows.Sum(x => x.CE?.OiChange ?? 0);
        decimal peChg = rows.Sum(x => x.PE?.OiChange ?? 0);
        decimal ceOi = rows.Sum(x => x.CE?.Oi ?? 0);
        decimal peOi = rows.Sum(x => x.PE?.Oi ?? 0);
        decimal pcr = ceOi > 0 ? peOi / ceOi : 0;
        decimal avgIv = rows
            .SelectMany(x => new[] { x.CE?.Iv ?? 0, x.PE?.Iv ?? 0 })
            .Where(x => x > 0)
            .DefaultIfEmpty(0)
            .Average();

        decimal maxPain = CalculateMaxPain(rows);
        decimal effectiveSpot = spot > 0
            ? spot
            : (rows.Count > 0 ? rows.OrderBy(x => x.Strike).ElementAt(rows.Count / 2).Strike : 0);

        decimal support = rows
            .Where(x => x.Strike < effectiveSpot && x.PE != null && x.PE.Oi > 0)
            .OrderByDescending(x => (x.PE!.Oi * 0.70m) + (Math.Max(0, x.PE!.OiChange) * 0.30m))
            .FirstOrDefault()?.Strike ?? 0;

        decimal resistance = rows
            .Where(x => x.Strike > effectiveSpot && x.CE != null && x.CE.Oi > 0)
            .OrderByDescending(x => (x.CE!.Oi * 0.70m) + (Math.Max(0, x.CE!.OiChange) * 0.30m))
            .FirstOrDefault()?.Strike ?? 0;

        if (support == resistance)
        {
            var strikes = rows.Select(x => x.Strike).Distinct().OrderBy(x => x).ToList();
            support = strikes.Where(x => x < effectiveSpot).DefaultIfEmpty(0).Max();
            resistance = strikes.Where(x => x > effectiveSpot).DefaultIfEmpty(0).Min();
        }

        decimal ceUnwind = rows.Sum(x => x.CE?.Signal == "Long Unwind" ? Math.Abs(x.CE?.OiChange ?? 0) : 0);
        decimal peUnwind = rows.Sum(x => x.PE?.Signal == "Long Unwind" ? Math.Abs(x.PE?.OiChange ?? 0) : 0);

        decimal ceBuild = rows.Sum(x =>
            x.CE?.Signal == "Short Build" || x.CE?.Signal == "OI Added"
                ? Math.Abs(x.CE?.OiChange ?? 0)
                : 0);

        decimal peBuild = rows.Sum(x =>
            x.PE?.Signal == "Short Build" ||
            x.PE?.Signal == "OI Added" ||
            x.PE?.Signal == "Long Build"
                ? Math.Abs(x.PE?.OiChange ?? 0)
                : 0);

        int trend =
            t.TrendBias == "Bullish" ? 80 :
            t.TrendBias == "Bearish" ? 25 :
            50;

        int oi = 50;

        if (peChg > ceChg && pcr >= 1)
            oi = 80;
        else if (ceChg > peChg && pcr <= 1)
            oi = 25;
        else if (peChg > ceChg)
            oi = 65;
        else if (ceChg > peChg)
            oi = 35;

        if (pcr >= 1.05m)
            oi = Math.Min(100, oi + 10);

        if (pcr > 0 && pcr <= 0.95m)
            oi = Math.Max(0, oi - 10);

        int vol =
            t.Rvol20 >= 1.5m ? 80 :
            t.Rvol20 >= 1.1m ? 60 :
            45;

        int iv =
            avgIv >= 25 ? 70 :
            avgIv >= 18 ? 60 :
            avgIv > 0 ? 45 :
            50;

        int superTrend =
            t.SuperTrend == "Buy" ? 80 :
            t.SuperTrend == "Sell" ? 25 :
            50;

        int momentum = 50;
        if (t.Rsi >= 55 && t.Roc > 0 && t.MacdStatus == "Bullish") momentum = 75;
        else if (t.Rsi <= 45 && t.Roc < 0 && t.MacdStatus == "Bearish") momentum = 25;
        else if (t.Roc > 0) momentum = 60;
        else if (t.Roc < 0) momentum = 40;

        int moneyFlow = 50;
        if (t.Mfi >= 55 && t.Cmf > 0 && t.SmartFlow > 0) moneyFlow = 78;
        else if (t.Mfi <= 45 && t.Cmf < 0 && t.SmartFlow < 0) moneyFlow = 28;
        else if (t.Cmf > 0 || t.SmartFlow > 0) moneyFlow = 62;
        else if (t.Cmf < 0 || t.SmartFlow < 0) moneyFlow = 38;

        int smc =
            t.SmartMoneyStructureSignal.Contains("Buy")
                ? (t.SmartMoneyStructureScore >= 70 ? 85 : 65)
                : t.SmartMoneyStructureSignal.Contains("Sell")
                    ? (t.SmartMoneyStructureScore >= 70 ? 20 : 35)
                    : 50;

        int final = (trend + momentum + moneyFlow + oi + vol + iv + superTrend + smc) / 8;

        string signal =
            final >= 75 ? "BUY Bias" :
            final <= 35 ? "SELL Bias" :
            "WAIT";

        decimal atr = rows.Count > 0
            ? Math.Max(20, Math.Abs(rows[0].Strike - rows[^1].Strike) / Math.Max(1, rows.Count))
            : 50;

        return new SmartMoneySnapshot
        {
            TrendScore = trend,
            OiScore = oi,
            VolumeScore = vol,
            IvScore = iv,
            MomentumScore = momentum,
            MoneyFlowScore = moneyFlow,
            SmcScore = smc,
            PatternScore = t.CandlestickBias == "Bullish" ? 75 : t.CandlestickBias == "Bearish" ? 25 : 50,
            FinalScore = final,
            BuyScore = final,
            SellScore = 100 - final,
            Bias = final >= 75 ? "Bullish" : final <= 35 ? "Bearish" : "Neutral",
            Signal = signal,
            StopLoss = signal.StartsWith("BUY") ? spot - atr : spot + atr,
            Target1 = signal.StartsWith("BUY") ? spot + atr : spot - atr,
            Target2 = signal.StartsWith("BUY") ? spot + atr * 2 : spot - atr * 2,
            Support = support,
            Resistance = resistance,
            PcrOi = pcr,
            AverageIv = avgIv,
            MaxPain = maxPain,
            CeBuildScore = ceBuild,
            PeBuildScore = peBuild,
            CeUnwindScore = ceUnwind,
            PeUnwindScore = peUnwind,
            IvRank = avgIv,
            Reason =
                $"Trend={trend}, OI={oi}, Vol={vol}, IV={iv}, SuperTrend={superTrend}, SMC={smc}, " +
                $"Bias={t.TrendBias}, ST={t.SuperTrend}, SMCSignal={t.SmartMoneyStructureSignal}, " +
                $"PCR={pcr:0.00}, PE OIChg={peChg:0}, CE OIChg={ceChg:0}, RVOL20={t.Rvol20:0.00}, AvgIV={avgIv:0.00}"
        };
    }

    private static decimal CalculateMaxPain(List<OptionChainRow> rows)
    {
        if (rows.Count == 0) return 0;

        decimal bestStrike = 0;
        decimal bestPain = decimal.MaxValue;

        foreach (var candidate in rows.Select(x => x.Strike))
        {
            decimal pain = 0;

            foreach (var row in rows)
            {
                decimal ceOi = row.CE?.Oi ?? 0;
                decimal peOi = row.PE?.Oi ?? 0;

                pain += Math.Max(0, candidate - row.Strike) * ceOi;
                pain += Math.Max(0, row.Strike - candidate) * peOi;
            }

            if (pain < bestPain)
            {
                bestPain = pain;
                bestStrike = candidate;
            }
        }

        return bestStrike;
    }
}
