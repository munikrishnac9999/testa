This full project is built from the working wpfCSharp_ProductTabs_TradingTab_ScrollFix code base.

Included:
- Existing FYERS API services and chart drawing flow preserved.
- 6/9 card institutional dashboard layout.
- Option Chain, OI Analytics, Strategies, Trading, Paper Trading, Alerts and Settings tabs.
- Paper trading thresholds are exposed in frontend.
- Spot fallback: option-chain spot falls back to latest candle close.
- Support/resistance are calculated using PE OI below spot and CE OI above spot to avoid same value.
- Real order execution remains disabled through RealOrderDisabledService.

Open: wpfCSharp_LiveOnly_WPF.csproj
Build in Visual Studio on Windows.

Latest UI update:
- Dashboard now fits 9 cards in one window without ScrollViewer.
- SuperTrend is shown in header, Trend card, and Smart Money card with color binding.
- Paper Trading card now shows WinRate, ProfitFactor and Drawdown.
