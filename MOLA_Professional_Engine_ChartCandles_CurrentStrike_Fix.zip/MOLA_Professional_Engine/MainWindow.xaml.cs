using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using wpfCSharp_LiveOnly_WPF.Models;
using wpfCSharp_LiveOnly_WPF.ViewModels;
namespace wpfCSharp_LiveOnly_WPF;
public partial class MainWindow : Window
{
    private readonly MainViewModel _vm = new();
    public MainWindow()
    {
        InitializeComponent();
        DataContext = _vm;
        _vm.Candles.CollectionChanged += Candles_CollectionChanged;
        _vm.SignalPopupRequested += Vm_SignalPopupRequested;
    }
    private void Vm_SignalPopupRequested(SignalPopupInfo popup)
    {
        Dispatcher.Invoke(() =>
            MessageBox.Show(popup.Message, popup.Title, MessageBoxButton.OK, MessageBoxImage.Information));
    }

    private void Candles_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) => DrawCharts();
    private void ChartCanvas_SizeChanged(object sender, SizeChangedEventArgs e) => DrawCharts();
    private void DrawCharts()
    {
        ChartCanvas.Children.Clear();
        VolumeCanvas.Children.Clear();
        var candles = _vm.Candles.ToList();
        if (candles.Count < 2 || ChartCanvas.ActualHeight <= 0) return;

        double visibleWidth = Math.Max(ChartCanvas.ActualWidth, 1);
        double candleSlotWidth = Math.Max(10.0, visibleWidth / Math.Max(1, candles.Count));
        double chartWidth = Math.Max(visibleWidth, candles.Count * candleSlotWidth);
        ChartCanvas.Width = chartWidth;
        VolumeCanvas.Width = chartWidth;

        decimal currentStrike = GetCurrentStrike(candles);
        decimal max = candles.Max(x => Math.Max(x.High, Math.Max(x.BollUpper, Math.Max(x.DonchianUpper, x.KeltnerUpper))));
        decimal min = candles.Min(x =>
        {
            var vals = new[] { x.Low, x.BollLower == 0 ? x.Low : x.BollLower, x.DonchianLower == 0 ? x.Low : x.DonchianLower, x.KeltnerLower == 0 ? x.Low : x.KeltnerLower };
            return vals.Min();
        });
        if (currentStrike > 0)
        {
            max = Math.Max(max, currentStrike);
            min = Math.Min(min, currentStrike);
        }
        if (max <= min) return;
        decimal pad = Math.Max(1m, (max - min) * 0.08m);
        max += pad; min -= pad;
        double h = ChartCanvas.ActualHeight;
        double Y(decimal v) => h - (double)((v - min) / (max - min)) * h;

        DrawLine(candles.Select((c, i) => (i * candleSlotWidth + candleSlotWidth / 2, Y(c.Ema20))).ToList(), Brushes.Gold, 1.2);
        DrawLine(candles.Select((c, i) => (i * candleSlotWidth + candleSlotWidth / 2, Y(c.Ema50))).ToList(), Brushes.Orange, 1.2);
        DrawLine(candles.Select((c, i) => (i * candleSlotWidth + candleSlotWidth / 2, Y(c.Ema200))).ToList(), Brushes.White, 1.0);
        DrawLine(candles.Select((c, i) => new { c, i }).Where(x => x.c.Vwap > 0).Select(x => (x.i * candleSlotWidth + candleSlotWidth / 2, Y(x.c.Vwap))).ToList(), Brushes.DeepSkyBlue, 1.4);
        DrawLine(candles.Select((c, i) => new { c, i }).Where(x => x.c.SuperTrend > 0).Select(x => (x.i * candleSlotWidth + candleSlotWidth / 2, Y(x.c.SuperTrend))).ToList(), Brushes.LimeGreen, 1.0);

        for (int i = 0; i < candles.Count; i++)
        {
            Candle c = candles[i];
            double centerX = i * candleSlotWidth + candleSlotWidth / 2;
            Brush candleBrush = c.Close >= c.Open ? Brushes.LimeGreen : Brushes.Red;
            Brush labelBrush = c.Close >= c.Open ? Brushes.LightGreen : Brushes.LightCoral;
            double highY = Y(c.High);
            double lowY = Y(c.Low);
            double openY = Y(c.Open);
            double closeY = Y(c.Close);
            double top = Math.Min(openY, closeY);
            double bottom = Math.Max(openY, closeY);
            double bodyWidth = Math.Max(6, candleSlotWidth * .62);
            var wick = new Line { X1 = centerX, X2 = centerX, Y1 = highY, Y2 = lowY, Stroke = candleBrush, StrokeThickness = 1.3, ToolTip = BuildCandleTooltip(c) };
            ChartCanvas.Children.Add(wick);
            var body = new Rectangle { Width = bodyWidth, Height = Math.Max(2, bottom - top), Fill = candleBrush, Stroke = Brushes.White, StrokeThickness = .35, Opacity = .88, ToolTip = BuildCandleTooltip(c) };
            Canvas.SetLeft(body, centerX - body.Width / 2);
            Canvas.SetTop(body, top);
            ChartCanvas.Children.Add(body);
            if (candleSlotWidth >= 24 || i == candles.Count - 1)
            {
                AddCandleValueLabel($"H {c.High:0.00}", centerX + 3, highY - 15, labelBrush);
                AddCandleValueLabel($"L {c.Low:0.00}", centerX + 3, lowY + 2, labelBrush);
            }
        }

        DrawCurrentStrikeLine(currentStrike, Y, min, max);

        decimal maxVol = candles.Max(x => x.Volume);
        if (maxVol > 0 && VolumeCanvas.ActualHeight > 0)
        {
            double vh = VolumeCanvas.ActualHeight;
            for (int i = 0; i < candles.Count; i++)
            {
                Candle c = candles[i];
                double barH = (double)(c.Volume / maxVol) * vh;
                Brush brush = c.Close >= c.Open ? Brushes.LimeGreen : Brushes.Red;
                var r = new Rectangle { Width = Math.Max(6, candleSlotWidth * .62), Height = barH, Fill = brush, Opacity = c.Rvol20 >= 1.5m ? .95 : .45, ToolTip = $"{c.Time:dd-MMM HH:mm}\nVolume: {FormatQty(c.Volume)}\nRVOL20: {c.Rvol20:0.00}x" };
                Canvas.SetLeft(r, i * candleSlotWidth + (candleSlotWidth - r.Width) / 2);
                Canvas.SetTop(r, vh - barH);
                VolumeCanvas.Children.Add(r);
            }
        }
    }

    private decimal GetCurrentStrike(IReadOnlyList<Candle> candles)
    {
        decimal spot = _vm.Spot > 0 ? _vm.Spot : candles.Last().Close;
        var optionRows = _vm.OptionRows.ToList();
        var atm = optionRows.FirstOrDefault(x => x.IsAtm);
        if (atm != null && atm.Strike > 0) return atm.Strike;
        var nearest = optionRows.Where(x => x.Strike > 0).OrderBy(x => Math.Abs(x.Strike - spot)).FirstOrDefault();
        return nearest != null && nearest.Strike > 0 ? nearest.Strike : spot;
    }

    private void DrawCurrentStrikeLine(decimal currentStrike, Func<decimal, double> yMap, decimal min, decimal max)
    {
        if (currentStrike <= 0 || currentStrike < min || currentStrike > max) return;
        double y = yMap(currentStrike);
        var line = new Line { X1 = 0, X2 = ChartCanvas.Width, Y1 = y, Y2 = y, Stroke = Brushes.DeepSkyBlue, StrokeThickness = 1.7, StrokeDashArray = new DoubleCollection { 5, 3 } };
        ChartCanvas.Children.Add(line);
        decimal spot = _vm.Spot > 0 ? _vm.Spot : currentStrike;
        var label = new TextBlock { Text = $"CURRENT STRIKE {currentStrike:0.00} | SPOT {spot:0.00}", Foreground = Brushes.DeepSkyBlue, FontSize = 11, FontWeight = FontWeights.Bold, Background = new SolidColorBrush(Color.FromArgb(160, 7, 16, 31)), Padding = new Thickness(4, 1, 4, 1) };
        Canvas.SetLeft(label, 6);
        Canvas.SetTop(label, Math.Max(0, Math.Min(ChartCanvas.ActualHeight - 18, y - 18)));
        ChartCanvas.Children.Add(label);
        var rightValue = new TextBlock { Text = currentStrike.ToString("0.00"), Foreground = Brushes.White, Background = Brushes.DeepSkyBlue, FontSize = 11, FontWeight = FontWeights.Bold, Padding = new Thickness(5, 1, 5, 1) };
        Canvas.SetLeft(rightValue, Math.Max(0, ChartCanvas.Width - 72));
        Canvas.SetTop(rightValue, Math.Max(0, Math.Min(ChartCanvas.ActualHeight - 18, y - 9)));
        ChartCanvas.Children.Add(rightValue);
    }

    private void AddCandleValueLabel(string text, double x, double y, Brush brush)
    {
        var label = new TextBlock { Text = text, Foreground = brush, FontSize = 9, FontWeight = FontWeights.Bold, Background = new SolidColorBrush(Color.FromArgb(125, 7, 16, 31)), Padding = new Thickness(2, 0, 2, 0) };
        Canvas.SetLeft(label, Math.Max(0, x));
        Canvas.SetTop(label, Math.Max(0, Math.Min(ChartCanvas.ActualHeight - 14, y)));
        ChartCanvas.Children.Add(label);
    }

    private void UpdateOhlcHeader(Candle c) { }

    private string BuildCandleTooltip(Candle c)
    {
        return
            $"Time   : {c.Time:dd-MMM-yyyy HH:mm}\n" +
            $"Open   : {c.Open:0.00}\n" +
            $"High   : {c.High:0.00}\n" +
            $"Low    : {c.Low:0.00}\n" +
            $"Close  : {c.Close:0.00}\n" +
            $"Volume : {FormatQty(c.Volume)}\n" +
            $"EMA20  : {c.Ema20:0.00}\n" +
            $"EMA50  : {c.Ema50:0.00}\n" +
            $"EMA200 : {c.Ema200:0.00}\n" +
            $"VWAP   : {c.Vwap:0.00}\n" +
            $"ATR    : {c.Atr14:0.00}\n" +
            $"RSI    : {c.Rsi14:0.00}\n" +
            $"MACD   : {c.Macd:0.00}\n" +
            $"ADX    : {c.Adx14:0.00}\n" +
            $"RVOL10 : {c.Rvol10:0.00}x\n" +
            $"RVOL20 : {c.Rvol20:0.00}x\n" +
            $"StdDev : {c.StdDev20:0.00}\n" +
            $"DEMA20 : {c.Dema20:0.00}\n" +
            $"TEMA20 : {c.Tema20:0.00}\n" +
            $"D vs T : {c.DemaTemaSignal}\n" +
            $"VWMA20 : {c.Vwma20:0.00}\n" +
            $"TTM    : {c.TtmSqueezeStatus}\n" +
            $"Vortex : {c.VortexSignal}  (+{c.VortexPlus14:0.00}/-{c.VortexMinus14:0.00})\n" +
            $"Chand. : {c.ChandelierSignal}  L {c.ChandelierLong:0.00} S {c.ChandelierShort:0.00}\n" +
            $"Elder  : {c.ElderRaySignal}  Bull {c.ElderBullPower:0.00} Bear {c.ElderBearPower:0.00}\n" +
            $"T3/T20 : {c.Tema3VsTema20Signal}\n" +
            $"P/EMA3 : {c.PriceVsEma3Signal}\n" +
            $"Camar. : {c.CamarillaZone}\n" +
            $"Aroon  : {c.AroonSignal}  U {c.AroonUp14:0.00} D {c.AroonDown14:0.00}\n" +
            $"PSAR   : {c.PsarSignal}  {c.Psar:0.00}\n" +
            $"BOS    : {c.BosSignal}\n" +
            $"Liq    : {c.LiquiditySignal}\n" +
            $"OB     : {c.OrderBlockSignal}  H {c.OrderBlockHigh:0.00} L {c.OrderBlockLow:0.00}\n" +
            $"FVG    : {c.FvgSignal}  Zone {c.FvgLow:0.00}-{c.FvgHigh:0.00}\n" +
            $"ST     : {(c.SuperTrendBullish ? "Buy" : "Sell")}  Score {(c.SuperTrendBullish ? 80 : 25)}\n" +
            $"SMC    : {c.SmartMoneyStructureSignal}  Score {c.SmartMoneyStructureScore}\n" +
            $"Pattern: {c.CandlestickPattern}\n" +
            $"Bias   : {c.CandlestickBias}";
    }

    private static string FormatQty(decimal value)
    {
        decimal abs = Math.Abs(value);
        if (abs >= 10000000m) return (value / 10000000m).ToString("0.00") + "Cr";
        if (abs >= 100000m) return (value / 100000m).ToString("0.00") + "L";
        if (abs >= 1000m) return (value / 1000m).ToString("0.00") + "K";
        return value.ToString("0");
    }


    private void DrawPriceLevel(string label, decimal value, double y, Brush brush, bool isResistance)
    {
        if (y < 0 || y > ChartCanvas.ActualHeight) return;
        var line = new Line
        {
            X1 = 0,
            X2 = ChartCanvas.ActualWidth,
            Y1 = y,
            Y2 = y,
            Stroke = brush,
            StrokeThickness = isResistance ? 1.1 : 1.0,
            StrokeDashArray = new DoubleCollection { 3, 4 },
            Opacity = .72
        };
        ChartCanvas.Children.Add(line);
        var text = new TextBlock
        {
            Text = $"{label} {value:0.00}",
            Foreground = brush,
            FontSize = 9,
            FontWeight = FontWeights.Bold,
            Background = new SolidColorBrush(Color.FromArgb(120, 7, 16, 31)),
            Padding = new Thickness(3, 0, 3, 0)
        };
        Canvas.SetLeft(text, isResistance ? ChartCanvas.ActualWidth - 88 : 6);
        Canvas.SetTop(text, Math.Max(0, Math.Min(ChartCanvas.ActualHeight - 14, y - 7)));
        ChartCanvas.Children.Add(text);
    }

    private static Brush BrushFromHex(string hex)
    {
        try
        {
            return (Brush)new BrushConverter().ConvertFromString(hex)!;
        }
        catch
        {
            return Brushes.Gray;
        }
    }

    private void DrawLine(List<(double x, double y)> points, Brush brush, double thickness)
    {
        if (points.Count < 2) return;
        var geo = new StreamGeometry(); using (var ctx = geo.Open()) { ctx.BeginFigure(new Point(points[0].x, points[0].y), false, false); ctx.PolyLineTo(points.Skip(1).Select(p => new Point(p.x, p.y)).ToList(), true, false); }
        ChartCanvas.Children.Add(new Path { Data = geo, Stroke = brush, StrokeThickness = thickness, Opacity = .9 });
    }
    private void RealTradingConfirm_Click(object sender, RoutedEventArgs e)
    {
        var result = MessageBox.Show("Real Trading mode can cause financial loss if broker execution is connected." +
            "This project build keeps broker execution locked and does not send orders." +
            "Do you want to confirm Real Trading preview mode?",
            "Confirm Real Trading Preview",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);

        if (result == MessageBoxResult.Yes)
            _vm.ConfirmRealTradingPreview();
    }

}
