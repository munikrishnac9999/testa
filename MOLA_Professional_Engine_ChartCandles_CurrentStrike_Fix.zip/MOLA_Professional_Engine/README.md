# MOLA Professional Engine

WPF .NET 8 live-only FYERS strategy engine with dashboard indicators, option chain, stock scanner, MOLA Studio, MOLA Query, Telegram alerts, Excel/CSV export, frontend thresholds, and option paper trading.

## Build

```bash
dotnet restore
dotnet build
```

## Notes

- Real broker order placement is intentionally blocked by `RealOrderDisabledService`.
- `StocksWatchlist.json` is copied to output and used by the stock scanner.
- MOLA Query uses the existing internal `MOLA...` class/property names for compatibility, while visible UI labels are renamed to MOLA.


## Option Signal Popups

When the live strategy score generates a BUY or SELL option signal:

- BUY signal shows a popup to buy ATM CE
- SELL signal shows a popup to buy ATM PE
- Popup includes option symbol, strike, entry rate, Target 1, Target 2, Stop Loss, and risk amount/percent
- Same signal is also inserted into the Alerts tab


## Client Dashboard Update

The project now opens with a client-focused dashboard:

- Market watchlist
- Live strategy snapshot
- Best Trade Now card
- option entry rate, Target 1, Target 2, Stop Loss, Risk and Risk %
- MOLA Studio / MOLA Query visible branding
- option signal popup and Alerts tab integration


## Option Chain Greeks restored

- Full option chain tab again shows IV, Delta, Gamma, Theta, Vega, OI, OI change, volume, bid, ask and LTP for CE and PE.
- ATM/current strike row is highlighted with a cyan line/background.
- CE/PE signal, price, IV, OI change and Greeks use colored bindings from OptionLeg brush properties.
- Chart label now clearly shows current spot / ATM line.


## Color-coded scanner alerts

- Scanner rows now use BUY/SELL/WAIT background colors.
- Signal, RVOL, SuperTrend and Structure cells are color coded.
- Scanner completion now pushes top BUY/SELL scanner opportunities into the Alerts tab with matching green/red/yellow colors.
- Alerts tab rows now use each alert message brush color.


## AI Chart Reader

Adds an AI-assisted next-day scenario module. The module reads the latest chart/indicator state and produces a probabilistic scenario, not a guaranteed market prediction. Inputs include EMA alignment, VWAP, SuperTrend, RSI, MACD, RVOL, market structure, SMC, candlestick bias, ATR range and option PCR.

Outputs:

- Next-day bias: bullish, bearish or range/wait
- Confidence percentage
- Expected high / expected low from ATR range
- Breakout and breakdown levels
- Suggested action for CE/PE confirmation
- Reasoning summary


## AI Market Intelligence

Adds expanded AI analysis modules:

- AI weekly trend scenario
- AI intraday timeframe scenario
- AI option-chain analysis
- AI sector trend / rotation analysis
- AI earnings/event impact analysis
- AI news sentiment analysis from pasted headlines

News sentiment is implemented as a local headline/text analyzer. For live news APIs, connect a licensed news provider later.


## Support Resistance Levels

Adds real-time pivot support/resistance overlays on the live chart:

- Daily R1/R2/R3 and S1/S2/S3
- Weekly R1/R2/R3 and S1/S2/S3
- Monthly R1/R2/R3 and S1/S2/S3
- Pivot line for each timeframe
- Dedicated S/R Levels tab
- Chart overlay labels: D/W/M Pivot, R1-R3 and S1-S3

Levels use standard pivot calculation from completed day/week/month candle groups where available.


## Candle Pattern Detector and Next Candle Predictor

Adds a Candle Predictor tab that reads the latest candlestick pattern and estimates the next candle scenario using local rule-based logic. Inputs include candlestick pattern bias, upper/lower wick rejection, VWAP, EMA20/EMA50, SuperTrend, RSI, MACD and RVOL.

Outputs:

- Current pattern and pattern bias
- Next candle bullish / bearish / wait scenario
- Confidence percentage
- Expected next candle open/high/low/close scenario
- Break above and break below levels
- Suggested CE/PE confirmation action
- Color-coded alert in the Alerts tab


## Final Live Chart Cleanup

Removed separate AI Chart Reader, AI Market Intelligence, Candle Predictor and S/R Levels tabs from the UI. The main Dashboard now shows the real-time live chart with intraday, daily, weekly and monthly support/resistance overlays directly on the chart. The dashboard also shows automatic next-candle prediction summary and has horizontal/vertical scroll bars. S/R breakout and breakdown alerts are generated automatically.


## S/R Sustain CE/PE Confirmation Cleanup

The extra dashboard chart/panel was removed. S/R lines remain on the previous live chart only. The live chart/header now shows sustain confirmation: BUY CE only when price sustains above pivot/resistance, BUY PE only when price sustains below pivot/support. Sustain means the last two candles closed beyond the level.


## Previous Chart + Sustain Sound Alerts Update

The dashboard uses the previous real-time chart only. Monthly/weekly/daily/intraday S/R overlay lines were removed from the chart. The chart keeps only the current spot/strike horizontal line. The sustain status is color coded in the dashboard header and chart message. BUY CE/BUY PE sustain triggers now play a Windows sound alert. An Automatic Next Candle card was added to the dashboard indicator-card area.


## Dashboard right panel cleanup

Removed the dashboard option-chain mini grid from the right side of the real-time chart and replaced that space with an Automatic Next Candle card. Removed S/R sustain confirmation text and sustain sound triggers from the dashboard. The chart remains the previous real-time chart with the current spot/strike line only.


## Chart candle rendering fix

Real-time chart candles now draw proper high-low wicks and candle bodies. Each candle has an OHLC tooltip, high/low labels when spacing allows, horizontal chart scrolling for many candles, and a current strike line with visible current strike and spot values.
