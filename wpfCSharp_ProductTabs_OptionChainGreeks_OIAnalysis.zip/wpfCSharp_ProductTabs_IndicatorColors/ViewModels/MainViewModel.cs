using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using System.Windows.Threading;
using wpfCSharp_LiveOnly_WPF.Models;
using wpfCSharp_LiveOnly_WPF.Services;
namespace wpfCSharp_LiveOnly_WPF.ViewModels;
public sealed class MainViewModel : INotifyPropertyChanged
{
    private readonly FyersApiClient _api = new();
    private readonly FyersAuthService _auth = new();
    private readonly IndicatorService _ind = new();
    private readonly SmartMoneyService _smart = new();
    private FyersHistoryService? _history;
    private FyersOptionChainService? _chain;
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(2) };
    public ObservableCollection<Candle> Candles { get; } = new();
    public ObservableCollection<OptionChainRow> OptionRows { get; } = new();
    public ObservableCollection<OptionChainRow> LongBuildRows { get; } = new();
    public ObservableCollection<OptionChainRow> ShortBuildRows { get; } = new();
    public ObservableCollection<OptionChainRow> LongUnwindRows { get; } = new();
    public ObservableCollection<OptionChainRow> ShortCoverRows { get; } = new();
    public ObservableCollection<AlertMessage> Alerts { get; } = new();
    public ICommand LoginCommand { get; }
    public ICommand StartCommand { get; }
    public ICommand StopCommand { get; }
    public ICommand TimeframeCommand { get; }
    public string AppId { get => _api.AppId; set { _api.AppId = value; OnPropertyChanged(); } }
    private string _appSecret = string.Empty; public string AppSecret { get => _appSecret; set { _appSecret = value; OnPropertyChanged(); } }
    private string _authCode = string.Empty; public string AuthCode { get => _authCode; set { _authCode = value; OnPropertyChanged(); } }
    private string _symbol = "NSE:NIFTY50-INDEX"; public string Symbol { get => _symbol; set { _symbol = value; OnPropertyChanged(); } }
    private string _resolution = "5"; public string Resolution { get => _resolution; set { _resolution = value; OnPropertyChanged(); } }
    // 50 gives a much broader current-expiry scan. Use 0 to request all current-expiry strikes if FYERS returns it.
    private int _strikeCount = 50; public int StrikeCount { get => _strikeCount; set { _strikeCount = value; OnPropertyChanged(); } }
    private string _status = "Not logged in"; public string Status { get => _status; set { _status = value; OnPropertyChanged(); } }
    private decimal _spot; public decimal Spot { get => _spot; set { _spot = value; OnPropertyChanged(); } }
    private string _expiry = "-"; public string Expiry { get => _expiry; set { _expiry = value; OnPropertyChanged(); } }
    private TrendSnapshot _trend = new(); public TrendSnapshot Trend { get => _trend; set { _trend = value; OnPropertyChanged(); } }
    private SmartMoneySnapshot _score = new(); public SmartMoneySnapshot Score { get => _score; set { _score = value; OnPropertyChanged(); } }
    public MainViewModel()
    {
        LoginCommand = new RelayCommand(LoginAsync);
        StartCommand = new RelayCommand(async _ => { _timer.Start(); await RefreshAsync(); Status = "LIVE"; });
        StopCommand = new RelayCommand(_ => { _timer.Stop(); Status = "Stopped"; });
        TimeframeCommand = new RelayCommand(SetTimeframeAsync);
        _timer.Tick += async (_, _) => await RefreshAsync();
    }

    private async Task SetTimeframeAsync(object? parameter)
    {
        string? tf = parameter?.ToString();
        if (string.IsNullOrWhiteSpace(tf)) return;
        Resolution = tf;
        AddAlert($"Timeframe changed to {tf}m", "#2DD4FF");
        if (_history != null && _chain != null)
            await RefreshAsync();
    }

    private async Task LoginAsync(object? _)
    {
        _api.AccessToken = await _auth.ExchangeAuthCodeAsync(_api.RawHttpClient, AppId, AppSecret, AuthCode);
        _history = new FyersHistoryService(_api); _chain = new FyersOptionChainService(_api);
        Status = "Logged in. Click Start Live.";
        AddAlert("Login success. Live-only mode enabled.", "#19C37D");
    }
    private async Task RefreshAsync()
    {
        if (_history == null || _chain == null) return;
        try
        {
            var candles = await _history.GetCandlesAsync(Symbol, Resolution, 5); _ind.ApplyAll(candles);
            Candles.Clear(); foreach (var c in candles.TakeLast(120)) Candles.Add(c);
            Trend = _ind.BuildTrend(candles);
            var rows = await _chain.GetRowsAsync(Symbol, StrikeCount);
            OptionRows.Clear(); foreach (var r in rows) OptionRows.Add(r);
            UpdateBuildTabs(rows);
            Spot = _chain.CurrentSpot; Expiry = _chain.CurrentExpiry;
            Score = _smart.Build(Trend, rows, Spot);
            AddAlert($"{Score.Signal} | Score {Score.FinalScore} | {Score.Reason}", Score.Signal.StartsWith("BUY") ? "#19C37D" : Score.Signal.StartsWith("SELL") ? "#FF4D4D" : "#FFC857");
            Status = "LIVE " + DateTime.Now.ToString("HH:mm:ss");
        }
        catch (Exception ex) { Status = "Error"; AddAlert(ex.Message, "#FF4D4D"); }
    }

    private void UpdateBuildTabs(List<OptionChainRow> rows)
    {
        LongBuildRows.Clear();
        ShortBuildRows.Clear();
        LongUnwindRows.Clear();
        ShortCoverRows.Clear();

        foreach (var row in rows)
        {
            if (row.CE?.Signal == "Long Build" || row.PE?.Signal == "Long Build") LongBuildRows.Add(row);
            if (row.CE?.Signal == "Short Build" || row.PE?.Signal == "Short Build") ShortBuildRows.Add(row);
            if (row.CE?.Signal == "Long Unwind" || row.PE?.Signal == "Long Unwind") LongUnwindRows.Add(row);
            if (row.CE?.Signal == "Short Cover" || row.PE?.Signal == "Short Cover") ShortCoverRows.Add(row);
        }
    }

    private void AddAlert(string text, string brush)
    {
        Alerts.Insert(0, new AlertMessage { Text = text, Brush = brush });
        while (Alerts.Count > 50) Alerts.RemoveAt(Alerts.Count - 1);
    }
    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? n = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
}
