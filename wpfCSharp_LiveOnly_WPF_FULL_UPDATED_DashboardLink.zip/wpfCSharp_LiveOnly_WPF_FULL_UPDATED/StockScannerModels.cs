namespace wpfCSharp_LiveOnly_WPF.Models;

public sealed class StockScanResult
{
    public int Rank { get; set; }
    public DateTime Time { get; set; } = DateTime.Now;
    public string Symbol { get; set; } = string.Empty;
    public decimal Ltp { get; set; }
    public decimal ChangePercent { get; set; }
    public string Signal { get; set; } = "WAIT";
    public string Bias { get; set; } = "Neutral";
    public int FinalScore { get; set; }
    public int BuyScore { get; set; }
    public int SellScore { get; set; }
    public string SuperTrend { get; set; } = "Neutral";
    public int SuperTrendScore { get; set; }
    public decimal Rsi { get; set; }
    public decimal Roc { get; set; }
    public decimal Cci { get; set; }
    public decimal Mfi { get; set; }
    public decimal Cmf { get; set; }
    public decimal Rvol10 { get; set; }
    public decimal Rvol20 { get; set; }
    public decimal Atr { get; set; }
    public string Pattern { get; set; } = "-";
    public string PatternBias { get; set; } = "Neutral";
    public string SmcSignal { get; set; } = "Neutral";
    public int SmcScore { get; set; }
    public string Reason { get; set; } = string.Empty;

    public string SignalBrush => Signal.StartsWith("BUY") ? "#19C37D" : Signal.StartsWith("SELL") ? "#FF4D4D" : "#FFC857";
    public string ChangeBrush => ChangePercent > 0 ? "#19C37D" : ChangePercent < 0 ? "#FF4D4D" : "#93A4BD";
    public string SuperTrendBrush => SuperTrend.Contains("Buy") ? "#19C37D" : SuperTrend.Contains("Sell") ? "#FF4D4D" : "#FFC857";
    public string RvolBrush => Rvol20 >= 1.5m || Rvol10 >= 1.5m ? "#19C37D" : Rvol20 >= 1.2m || Rvol10 >= 1.2m ? "#2DD4FF" : "#93A4BD";
}
