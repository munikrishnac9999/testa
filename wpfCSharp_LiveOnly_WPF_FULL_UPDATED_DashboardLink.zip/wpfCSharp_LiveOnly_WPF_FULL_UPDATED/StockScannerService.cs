using wpfCSharp_LiveOnly_WPF.Models;

namespace wpfCSharp_LiveOnly_WPF.Services;

public sealed class StockScannerService
{
    private readonly FyersHistoryService _history;
    private readonly IndicatorService _indicators;
    private readonly SmartMoneyService _smartMoney;

    public StockScannerService(FyersHistoryService history, IndicatorService indicators, SmartMoneyService smartMoney)
    {
        _history = history;
        _indicators = indicators;
        _smartMoney = smartMoney;
    }

    public async Task<List<StockScanResult>> ScanAsync(
        IEnumerable<string> symbols,
        string resolution,
        int lookbackDays,
        StrategyThresholdSettings thresholds,
        CancellationToken cancellationToken = default)
    {
        var results = new List<StockScanResult>();
        int rank = 1;

        foreach (string raw in symbols)
        {
            cancellationToken.ThrowIfCancellationRequested();
            string symbol = NormalizeSymbol(raw);
            if (string.IsNullOrWhiteSpace(symbol))
                continue;

            try
            {
                List<Candle> candles = await _history.GetCandlesAsync(symbol, resolution, lookbackDays);
                if (candles.Count < 30)
                    continue;

                _indicators.ApplyAll(candles);
                Candle last = candles.Last();
                Candle prev = candles.Count >= 2 ? candles[^2] : last;
                TrendSnapshot trend = _indicators.BuildTrend(candles);
                SmartMoneySnapshot score = _smartMoney.Build(trend, new List<OptionChainRow>(), last.Close, thresholds);

                string scanSignal = BuildScanSignal(score, trend);
                var row = new StockScanResult
                {
                    Rank = rank++,
                    Time = DateTime.Now,
                    Symbol = symbol,
                    Ltp = last.Close,
                    ChangePercent = prev.Close == 0 ? 0 : ((last.Close - prev.Close) / prev.Close) * 100m,
                    Signal = scanSignal,
                    Bias = score.Bias,
                    FinalScore = score.FinalScore,
                    BuyScore = score.BuyScore,
                    SellScore = score.SellScore,
                    SuperTrend = trend.SuperTrend,
                    SuperTrendScore = trend.SuperTrendScore,
                    Rsi = trend.Rsi,
                    Roc = trend.Roc,
                    Cci = trend.Cci,
                    Mfi = trend.Mfi,
                    Cmf = trend.Cmf,
                    Rvol10 = trend.Rvol10,
                    Rvol20 = trend.Rvol20,
                    Atr = trend.Atr,
                    Pattern = trend.CandlestickPattern,
                    PatternBias = trend.CandlestickBias,
                    SmcSignal = trend.SmartMoneyStructureSignal,
                    SmcScore = trend.SmartMoneyStructureScore,
                    Reason = BuildReason(score, trend)
                };
                results.Add(row);
            }
            catch (Exception ex)
            {
                results.Add(new StockScanResult
                {
                    Rank = rank++,
                    Time = DateTime.Now,
                    Symbol = symbol,
                    Signal = "ERROR",
                    Reason = ex.Message
                });
            }

            // Small delay to avoid hammering the FYERS history API while scanning many symbols.
            await Task.Delay(120, cancellationToken);
        }

        return results
            .OrderByDescending(x => x.Signal.StartsWith("BUY"))
            .ThenBy(x => x.Signal.StartsWith("WAIT"))
            .ThenByDescending(x => x.FinalScore)
            .ThenByDescending(x => Math.Max(x.Rvol10, x.Rvol20))
            .ToList();
    }

    private static string NormalizeSymbol(string value)
    {
        string symbol = value.Trim();
        if (string.IsNullOrWhiteSpace(symbol)) return string.Empty;
        if (!symbol.Contains(':')) symbol = "NSE:" + symbol;
        if (!symbol.Contains('-') && !symbol.EndsWith("-INDEX", StringComparison.OrdinalIgnoreCase)) symbol += "-EQ";
        return symbol.ToUpperInvariant();
    }

    private static string BuildScanSignal(SmartMoneySnapshot score, TrendSnapshot trend)
    {
        if (score.Signal.StartsWith("BUY") && (trend.SuperTrend.Contains("Buy") || trend.Rvol20 >= 1.2m || trend.Rvol10 >= 1.2m))
            return trend.SuperTrend == "Strong Buy" ? "BUY Strong" : "BUY";

        if (score.Signal.StartsWith("SELL") && (trend.SuperTrend.Contains("Sell") || trend.Rvol20 >= 1.2m || trend.Rvol10 >= 1.2m))
            return trend.SuperTrend == "Strong Sell" ? "SELL Strong" : "SELL";

        if (trend.SuperTrend == "Strong Buy" && score.FinalScore >= 60)
            return "BUY Watch";

        if (trend.SuperTrend == "Strong Sell" && score.FinalScore <= 40)
            return "SELL Watch";

        return "WAIT";
    }

    private static string BuildReason(SmartMoneySnapshot score, TrendSnapshot trend)
    {
        return $"Score={score.FinalScore}, ST={trend.SuperTrend}, RSI={trend.Rsi:0.00}, ROC={trend.Roc:0.00}, " +
               $"MFI={trend.Mfi:0.00}, CMF={trend.Cmf:0.000}, RVOL10={trend.Rvol10:0.00}, RVOL20={trend.Rvol20:0.00}, " +
               $"SMC={trend.SmartMoneyStructureSignal}, Pattern={trend.CandlestickPattern}";
    }
}
