using wpfCSharp_LiveOnly_WPF.Models;
namespace wpfCSharp_LiveOnly_WPF.Services;
public sealed class SmartMoneyService
{
    public SmartMoneySnapshot Build(TrendSnapshot t, List<OptionChainRow> rows, decimal spot)
    {
        decimal ceChg = rows.Sum(x => x.CE?.OiChange ?? 0), peChg = rows.Sum(x => x.PE?.OiChange ?? 0);
        decimal ceOi = rows.Sum(x => x.CE?.Oi ?? 0), peOi = rows.Sum(x => x.PE?.Oi ?? 0);
        decimal pcr = ceOi > 0 ? peOi / ceOi : 0;
        decimal avgIv = rows.SelectMany(x => new[] { x.CE?.Iv ?? 0, x.PE?.Iv ?? 0 }).Where(x => x > 0).DefaultIfEmpty(0).Average();
        decimal maxPain = CalculateMaxPain(rows);
        decimal support = rows.Where(x => x.PE != null).OrderByDescending(x => x.PE!.Oi).FirstOrDefault()?.Strike ?? 0;
        decimal resistance = rows.Where(x => x.CE != null).OrderByDescending(x => x.CE!.Oi).FirstOrDefault()?.Strike ?? 0;
        decimal ceBuild = rows.Sum(x => x.CE?.Signal == "Short Build" || x.CE?.Signal == "OI Added" ? Math.Abs(x.CE?.OiChange ?? 0) : 0);
        decimal peBuild = rows.Sum(x => x.PE?.Signal == "Short Build" || x.PE?.Signal == "OI Added" || x.PE?.Signal == "Long Build" ? Math.Abs(x.PE?.OiChange ?? 0) : 0);
        int trend = t.TrendBias == "Bullish" ? 80 : t.TrendBias == "Bearish" ? 25 : 50;
        int oi = peChg > ceChg ? 80 : ceChg > peChg ? 25 : 50;
        int vol = t.Rvol >= 1.5m ? 80 : t.Rvol >= 1.1m ? 60 : 45;
        int iv = 60;
        if (pcr >= 1.05m) oi = Math.Min(100, oi + 10);
        if (pcr > 0 && pcr <= 0.95m) oi = Math.Max(0, oi - 10);
        int final = (trend + oi + vol + iv) / 4;
        string signal = final >= 70 ? "BUY Bias" : final <= 35 ? "SELL Bias" : "WAIT";
        decimal atr = rows.Count > 0 ? Math.Max(20, Math.Abs(rows[0].Strike - rows[^1].Strike) / Math.Max(1, rows.Count)) : 50;
        return new SmartMoneySnapshot
        {
            TrendScore = trend,
            OiScore = oi,
            VolumeScore = vol,
            IvScore = iv,
            FinalScore = final,
            BuyScore = final,
            SellScore = 100 - final,
            Bias = final >= 70 ? "Bullish" : final <= 35 ? "Bearish" : "Neutral",
            Signal = signal,
            StopLoss = signal.StartsWith("BUY") ? spot - atr : spot + atr,
            Target1 = signal.StartsWith("BUY") ? spot + atr : spot - atr,
            Target2 = signal.StartsWith("BUY") ? spot + atr * 2 : spot - atr * 2,
            Support = support,
            Resistance = resistance,
            PcrOi = pcr,
            AverageIv = avgIv,
            MaxPain = maxPain,
            CeBuildScore = ceBuild,
            PeBuildScore = peBuild,
            IvRank = avgIv,
            Reason = $"Trend={t.TrendBias}, PCR={pcr:0.00}, PE OIChg={peChg:0}, CE OIChg={ceChg:0}, RVOL={t.Rvol:0.00}"
        };
    }

    private static decimal CalculateMaxPain(List<OptionChainRow> rows)
    {
        if (rows.Count == 0) return 0;
        decimal bestStrike = 0;
        decimal bestPain = decimal.MaxValue;
        foreach (var candidate in rows.Select(x => x.Strike))
        {
            decimal pain = 0;
            foreach (var row in rows)
            {
                decimal ceOi = row.CE?.Oi ?? 0;
                decimal peOi = row.PE?.Oi ?? 0;
                pain += Math.Max(0, candidate - row.Strike) * ceOi;
                pain += Math.Max(0, row.Strike - candidate) * peOi;
            }
            if (pain < bestPain)
            {
                bestPain = pain;
                bestStrike = candidate;
            }
        }
        return bestStrike;
    }
}
