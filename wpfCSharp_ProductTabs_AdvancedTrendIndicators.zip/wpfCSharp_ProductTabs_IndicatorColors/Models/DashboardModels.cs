namespace wpfCSharp_LiveOnly_WPF.Models;
public sealed class TrendSnapshot
{
    public string EmaTrend { get; set; } = "-";
    public string SmaTrend { get; set; } = "-";
    public string VwapStatus { get; set; } = "-";
    public decimal Atr { get; set; }
    public decimal Rsi { get; set; }
    public string MacdStatus { get; set; } = "-";
    public decimal Macd { get; set; }
    public decimal MacdSignal { get; set; }
    public decimal Adx { get; set; }
    public string AdxStatus { get; set; } = "-";
    public string SuperTrend { get; set; } = "-";
    public string BollingerStatus { get; set; } = "-";
    public string DonchianStatus { get; set; } = "-";
    public string KeltnerStatus { get; set; } = "-";
    public decimal Rvol { get; set; }
    public decimal VolumeProfilePoc { get; set; }
    public string TrendBias { get; set; } = "Neutral";
    public string EmaBrush { get; set; } = "#93A4BD";
    public string SmaBrush { get; set; } = "#93A4BD";
    public string VwapBrush { get; set; } = "#93A4BD";
    public string RsiBrush { get; set; } = "#93A4BD";
    public string MacdBrush { get; set; } = "#93A4BD";
    public string AdxBrush { get; set; } = "#93A4BD";
    public string SuperTrendBrush { get; set; } = "#93A4BD";
    public string RvolBrush { get; set; } = "#93A4BD";
    public string BollingerBrush { get; set; } = "#93A4BD";
    public string DonchianBrush { get; set; } = "#93A4BD";
    public string KeltnerBrush { get; set; } = "#93A4BD";

    public decimal Roc { get; set; }
    public decimal Cci { get; set; }
    public decimal Stochastic { get; set; }
    public decimal Mfi { get; set; }
    public decimal Cmf { get; set; }
    public decimal Obv { get; set; }
    public decimal AdLine { get; set; }
    public decimal SmartFlow { get; set; }
    public decimal AbsorptionScore { get; set; }
    public decimal HistoricalVolatility { get; set; }
    public decimal StdDev20 { get; set; }
    public decimal Dema20 { get; set; }
    public decimal Tema20 { get; set; }
    public string DemaTemaSignal { get; set; } = "Neutral";
    public decimal Vwma20 { get; set; }
    public string TtmSqueezeStatus { get; set; } = "-";
    public decimal VortexPlus { get; set; }
    public decimal VortexMinus { get; set; }
    public string VortexSignal { get; set; } = "Neutral";
    public decimal ChandelierLong { get; set; }
    public decimal ChandelierShort { get; set; }
    public string ChandelierSignal { get; set; } = "Neutral";
    public decimal ElderBullPower { get; set; }
    public decimal ElderBearPower { get; set; }
    public string ElderRaySignal { get; set; } = "Neutral";
    public decimal Tema3 { get; set; }
    public string Tema3VsTema20Signal { get; set; } = "Neutral";
    public string PriceVsEma3Signal { get; set; } = "Neutral";
    public string CamarillaZone { get; set; } = "-";
    public decimal AroonUp { get; set; }
    public decimal AroonDown { get; set; }
    public string AroonSignal { get; set; } = "Neutral";
    public decimal Psar { get; set; }
    public string PsarSignal { get; set; } = "Neutral";

    public string RocBrush { get; set; } = "#93A4BD";
    public string CciBrush { get; set; } = "#93A4BD";
    public string StochasticBrush { get; set; } = "#93A4BD";
    public string MfiBrush { get; set; } = "#93A4BD";
    public string CmfBrush { get; set; } = "#93A4BD";
    public string ObvBrush { get; set; } = "#93A4BD";
    public string AdLineBrush { get; set; } = "#93A4BD";
    public string SmartFlowBrush { get; set; } = "#93A4BD";
    public string AbsorptionBrush { get; set; } = "#93A4BD";
    public string HistoricalVolatilityBrush { get; set; } = "#93A4BD";
    public string StdDevBrush { get; set; } = "#93A4BD";
    public string DemaBrush { get; set; } = "#93A4BD";
    public string TemaBrush { get; set; } = "#93A4BD";
    public string DemaTemaBrush { get; set; } = "#93A4BD";
    public string VwmaBrush { get; set; } = "#93A4BD";
    public string TtmSqueezeBrush { get; set; } = "#93A4BD";
    public string VortexBrush { get; set; } = "#93A4BD";
    public string ChandelierBrush { get; set; } = "#93A4BD";
    public string ElderRayBrush { get; set; } = "#93A4BD";
    public string Tema3VsTema20Brush { get; set; } = "#93A4BD";
    public string PriceVsEma3Brush { get; set; } = "#93A4BD";
    public string CamarillaBrush { get; set; } = "#93A4BD";
    public string AroonBrush { get; set; } = "#93A4BD";
    public string PsarBrush { get; set; } = "#93A4BD";

    public string CandlestickPattern { get; set; } = "-";
    public string CandlestickBias { get; set; } = "Neutral";
    public string CandlestickBrush { get; set; } = "#93A4BD";
}
public sealed class SmartMoneySnapshot
{
    public int TrendScore { get; set; }
    public int OiScore { get; set; }
    public int VolumeScore { get; set; }
    public int IvScore { get; set; }
    public int FinalScore { get; set; }
    public string Bias { get; set; } = "Neutral";
    public string Signal { get; set; } = "WAIT";
    public decimal StopLoss { get; set; }
    public decimal Target1 { get; set; }
    public decimal Target2 { get; set; }
    public string StrategyName { get; set; } = "No Strategy";
    public decimal Support { get; set; }
    public decimal Resistance { get; set; }
    public decimal PcrOi { get; set; }
    public decimal PcrVolume { get; set; }
    public decimal AverageIv { get; set; }
    public int BuyScore { get; set; }
    public int SellScore { get; set; }

    public decimal MaxPain { get; set; }
    public decimal CeBuildScore { get; set; }
    public decimal PeBuildScore { get; set; }
    public decimal IvRank { get; set; }
    public string PcrBrush => PcrOi >= 1 ? "#19C37D" : PcrOi > 0 ? "#FF4D4D" : "#93A4BD";
    public string MaxPainBrush => MaxPain > 0 ? "#FFC857" : "#93A4BD";
    public string CeBuildBrush => CeBuildScore > 0 ? "#FF4D4D" : "#93A4BD";
    public string PeBuildBrush => PeBuildScore > 0 ? "#19C37D" : "#93A4BD";
    public string IvRankBrush => IvRank >= 25 ? "#FF4D4D" : IvRank >= 15 ? "#FFC857" : "#93A4BD";
    public string Reason { get; set; } = string.Empty;
    public string SignalBrush => Signal.StartsWith("BUY") ? "#19C37D" : Signal.StartsWith("SELL") ? "#FF4D4D" : "#FFC857";
}
public sealed class AlertMessage
{
    public DateTime Time { get; set; } = DateTime.Now;
    public string Text { get; set; } = string.Empty;
    public string Brush { get; set; } = "#E7EEFB";
}
