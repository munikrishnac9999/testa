using wpfCSharp_LiveOnly_WPF.Models;
namespace wpfCSharp_LiveOnly_WPF.Services;
public sealed class IndicatorService
{
    public void ApplyAll(List<Candle> c)
    {
        ApplyEma(c, 12, null); ApplyEma(c, 20, (x, v) => x.Ema20 = v); ApplyEma(c, 26, null); ApplyEma(c, 50, (x, v) => x.Ema50 = v); ApplyEma(c, 200, (x, v) => x.Ema200 = v);
        ApplySma(c, 20, (x, v) => x.Sma20 = v); ApplySma(c, 50, (x, v) => x.Sma50 = v);
        ApplyVwap(c); ApplyAtr(c, 14); ApplyRsi(c, 14); ApplyMacd(c); ApplyAdx(c, 14); ApplyBands(c, 20); ApplyDemaTema(c, 20); ApplyChannels(c, 20); ApplyAdvancedTrendSet(c); ApplyRvol(c, 20); ApplySuperTrend(c, 10, 3m); ApplyVolumeProfile(c, 80); ApplyRoc(c, 14); ApplyCci(c, 20); ApplyStochastic(c, 14); ApplyMfi(c, 14); ApplyCmf(c, 20); ApplyObv(c); ApplyAdLine(c); ApplySmartFlow(c, 20); ApplyAbsorption(c, 20); ApplyHistoricalVolatility(c, 20); ApplyCandlestickPatterns(c);
    }
    private List<decimal> CalcEmaValues(List<Candle> c, int p){ var list=new List<decimal>(); decimal k=2m/(p+1), ema=0; for(int i=0;i<c.Count;i++){ema=i==0?c[i].Close:c[i].Close*k+ema*(1-k); list.Add(ema);} return list; }
    private void ApplyEma(List<Candle> c, int p, Action<Candle, decimal>? set){var values=CalcEmaValues(c,p); if(set!=null) for(int i=0;i<c.Count;i++) set(c[i],values[i]);}
    private void ApplySma(List<Candle> c, int p, Action<Candle, decimal> set){ for(int i=0;i<c.Count;i++) set(c[i], i+1<p?0:c.Skip(i-p+1).Take(p).Average(x=>x.Close)); }
    private void ApplyVwap(List<Candle> c){ decimal pv=0,vol=0; DateTime day=DateTime.MinValue; foreach(var x in c){ if(x.Time.Date!=day){day=x.Time.Date; pv=0; vol=0;} decimal typical=(x.High+x.Low+x.Close)/3; pv+=typical*x.Volume; vol+=x.Volume; x.Vwap=vol>0?pv/vol:0; } }
    private void ApplyAtr(List<Candle> c,int p){ decimal atr=0; for(int i=0;i<c.Count;i++){ decimal prev=i==0?c[i].Close:c[i-1].Close; decimal tr=Math.Max(c[i].High-c[i].Low,Math.Max(Math.Abs(c[i].High-prev),Math.Abs(c[i].Low-prev))); atr=i==0?tr:((atr*(p-1))+tr)/p; c[i].Atr14=atr; } }
    private void ApplyRsi(List<Candle> c,int p){ decimal gain=0,loss=0; for(int i=1;i<c.Count;i++){ decimal ch=c[i].Close-c[i-1].Close; gain=((gain*(p-1))+Math.Max(0,ch))/p; loss=((loss*(p-1))+Math.Max(0,-ch))/p; c[i].Rsi14=loss==0?100:100-(100/(1+gain/loss)); } }
    private void ApplyMacd(List<Candle> c){ var ema12=CalcEmaValues(c,12); var ema26=CalcEmaValues(c,26); var macd=ema12.Select((v,i)=>v-ema26[i]).ToList(); decimal k=2m/(9+1), sig=0; for(int i=0;i<c.Count;i++){ sig=i==0?macd[i]:macd[i]*k+sig*(1-k); c[i].Macd=macd[i]; c[i].MacdSignal=sig; c[i].MacdHistogram=macd[i]-sig; } }

    private List<decimal> CalcEmaFromValues(List<decimal> values, int p)
    {
        var list = new List<decimal>();
        if (values.Count == 0) return list;
        decimal k = 2m / (p + 1), ema = 0;
        for (int i = 0; i < values.Count; i++)
        {
            ema = i == 0 ? values[i] : values[i] * k + ema * (1 - k);
            list.Add(ema);
        }
        return list;
    }

    private void ApplyDemaTema(List<Candle> c, int p)
    {
        var close = c.Select(x => x.Close).ToList();
        var ema1 = CalcEmaFromValues(close, p);
        var ema2 = CalcEmaFromValues(ema1, p);
        var ema3 = CalcEmaFromValues(ema2, p);
        for (int i = 0; i < c.Count; i++)
        {
            c[i].Dema20 = (2 * ema1[i]) - ema2[i];
            c[i].Tema20 = (3 * ema1[i]) - (3 * ema2[i]) + ema3[i];
            c[i].DemaTemaSignal = c[i].Dema20 > c[i].Tema20 ? "DEMA > TEMA" : c[i].Dema20 < c[i].Tema20 ? "TEMA > DEMA" : "Equal";
            c[i].DemaTemaBrush = c[i].Dema20 > c[i].Tema20 ? "#19C37D" : c[i].Dema20 < c[i].Tema20 ? "#FF4D4D" : "#93A4BD";
        }
    }

    private void ApplyAdx(List<Candle> c,int p){ decimal trS=0,pdmS=0,mdmS=0,adx=0; for(int i=1;i<c.Count;i++){ decimal up=c[i].High-c[i-1].High, down=c[i-1].Low-c[i].Low; decimal pdm=up>down&&up>0?up:0, mdm=down>up&&down>0?down:0; decimal tr=Math.Max(c[i].High-c[i].Low,Math.Max(Math.Abs(c[i].High-c[i-1].Close),Math.Abs(c[i].Low-c[i-1].Close))); trS=((trS*(p-1))+tr)/p; pdmS=((pdmS*(p-1))+pdm)/p; mdmS=((mdmS*(p-1))+mdm)/p; decimal pdi=trS>0?100*pdmS/trS:0, mdi=trS>0?100*mdmS/trS:0; decimal dx=(pdi+mdi)>0?100*Math.Abs(pdi-mdi)/(pdi+mdi):0; adx=((adx*(p-1))+dx)/p; c[i].PlusDi14=pdi; c[i].MinusDi14=mdi; c[i].Adx14=adx; } }
    private void ApplyBands(List<Candle> c,int p){ for(int i=p-1;i<c.Count;i++){ var list=c.Skip(i-p+1).Take(p).Select(x=>x.Close).ToList(); decimal avg=list.Average(); decimal sd=(decimal)Math.Sqrt(list.Average(v=>Math.Pow((double)(v-avg),2))); c[i].StdDev20=sd; c[i].BollMiddle=avg; c[i].BollUpper=avg+2*sd; c[i].BollLower=avg-2*sd; } }
    private void ApplyChannels(List<Candle> c,int p){ for(int i=p-1;i<c.Count;i++){ var list=c.Skip(i-p+1).Take(p); c[i].DonchianUpper=list.Max(x=>x.High); c[i].DonchianLower=list.Min(x=>x.Low); c[i].KeltnerUpper=c[i].Ema20+2*c[i].Atr14; c[i].KeltnerLower=c[i].Ema20-2*c[i].Atr14; } }
    private void ApplyRvol(List<Candle> c,int p){ for(int i=p-1;i<c.Count;i++){ decimal avg=c.Skip(i-p+1).Take(p).Average(x=>x.Volume); c[i].Rvol=avg>0?c[i].Volume/avg:0; } }
    private void ApplySuperTrend(List<Candle> c,int p,decimal m){ for(int i=0;i<c.Count;i++){ decimal mid=(c[i].High+c[i].Low)/2; c[i].SuperTrend=mid-m*c[i].Atr14; c[i].SuperTrendBullish=c[i].Close>=c[i].SuperTrend; } }
    private void ApplyVolumeProfile(List<Candle> c,int lookback){ var recent=c.TakeLast(Math.Min(lookback,c.Count)).ToList(); if(!recent.Any()) return; decimal poc=recent.GroupBy(x=>Math.Round(x.Close/10m)*10m).OrderByDescending(g=>g.Sum(x=>x.Volume)).First().Key; foreach(var x in c) x.VolumeProfilePoc=poc; }

    private void ApplyRoc(List<Candle> c, int p)
    {
        for (int i = p; i < c.Count; i++)
            c[i].Roc14 = c[i - p].Close == 0 ? 0 : ((c[i].Close - c[i - p].Close) / c[i - p].Close) * 100;
    }
    private void ApplyCci(List<Candle> c, int p)
    {
        for (int i = p - 1; i < c.Count; i++)
        {
            var tp = c.Skip(i - p + 1).Take(p).Select(x => (x.High + x.Low + x.Close) / 3m).ToList();
            decimal avg = tp.Average();
            decimal md = tp.Average(x => Math.Abs(x - avg));
            c[i].Cci20 = md == 0 ? 0 : (tp[^1] - avg) / (0.015m * md);
        }
    }
    private void ApplyStochastic(List<Candle> c, int p)
    {
        for (int i = p - 1; i < c.Count; i++)
        {
            var list = c.Skip(i - p + 1).Take(p).ToList();
            decimal high = list.Max(x => x.High);
            decimal low = list.Min(x => x.Low);
            c[i].StochasticK14 = high == low ? 0 : ((c[i].Close - low) / (high - low)) * 100;
        }
    }
    private void ApplyMfi(List<Candle> c, int p)
    {
        for (int i = p; i < c.Count; i++)
        {
            decimal pos = 0, neg = 0;
            for (int j = i - p + 1; j <= i; j++)
            {
                decimal tp = (c[j].High + c[j].Low + c[j].Close) / 3m;
                decimal prevTp = (c[j - 1].High + c[j - 1].Low + c[j - 1].Close) / 3m;
                decimal money = tp * c[j].Volume;
                if (tp > prevTp) pos += money;
                else if (tp < prevTp) neg += money;
            }
            c[i].Mfi14 = neg == 0 ? 100 : 100 - (100 / (1 + pos / neg));
        }
    }
    private void ApplyCmf(List<Candle> c, int p)
    {
        for (int i = p - 1; i < c.Count; i++)
        {
            decimal mfv = 0, vol = 0;
            foreach (var x in c.Skip(i - p + 1).Take(p))
            {
                decimal range = x.High - x.Low;
                if (range == 0) continue;
                decimal multiplier = ((x.Close - x.Low) - (x.High - x.Close)) / range;
                mfv += multiplier * x.Volume;
                vol += x.Volume;
            }
            c[i].Cmf20 = vol == 0 ? 0 : mfv / vol;
        }
    }
    private void ApplyObv(List<Candle> c)
    {
        decimal obv = 0;
        for (int i = 1; i < c.Count; i++)
        {
            if (c[i].Close > c[i - 1].Close) obv += c[i].Volume;
            else if (c[i].Close < c[i - 1].Close) obv -= c[i].Volume;
            c[i].Obv = obv;
        }
    }
    private void ApplyAdLine(List<Candle> c)
    {
        decimal ad = 0;
        foreach (var x in c)
        {
            decimal range = x.High - x.Low;
            if (range != 0)
            {
                decimal multiplier = ((x.Close - x.Low) - (x.High - x.Close)) / range;
                ad += multiplier * x.Volume;
            }
            x.AdLine = ad;
        }
    }
    private void ApplySmartFlow(List<Candle> c, int p)
    {
        for (int i = p - 1; i < c.Count; i++)
        {
            var list = c.Skip(i - p + 1).Take(p).ToList();
            decimal bull = list.Where(x => x.Close >= x.Open).Sum(x => x.Volume);
            decimal bear = list.Where(x => x.Close < x.Open).Sum(x => x.Volume);
            decimal total = bull + bear;
            c[i].SmartFlow = total == 0 ? 0 : ((bull - bear) / total) * 100;
        }
    }
    private void ApplyAbsorption(List<Candle> c, int p)
    {
        for (int i = p - 1; i < c.Count; i++)
        {
            decimal avgVol = c.Skip(i - p + 1).Take(p).Average(x => x.Volume);
            decimal range = c[i].High - c[i].Low;
            decimal body = Math.Abs(c[i].Close - c[i].Open);
            if (avgVol == 0 || range == 0) { c[i].AbsorptionScore = 0; continue; }
            decimal volRatio = c[i].Volume / avgVol;
            decimal bodyRatio = body / range;
            c[i].AbsorptionScore = volRatio >= 1.5m && bodyRatio <= 0.35m ? 80 : volRatio >= 1.2m && bodyRatio <= 0.50m ? 60 : 30;
        }
    }
    private void ApplyHistoricalVolatility(List<Candle> c, int p)
    {
        for (int i = p; i < c.Count; i++)
        {
            var returns = new List<double>();
            for (int j = i - p + 1; j <= i; j++)
            {
                if (c[j - 1].Close > 0)
                    returns.Add(Math.Log((double)(c[j].Close / c[j - 1].Close)));
            }
            if (returns.Count == 0) continue;
            double avg = returns.Average();
            double variance = returns.Average(x => Math.Pow(x - avg, 2));
            c[i].HistoricalVolatility20 = (decimal)(Math.Sqrt(variance) * Math.Sqrt(252) * 100);
        }
    }


    private static decimal Body(Candle x) => Math.Abs(x.Close - x.Open);
    private static decimal Range(Candle x) => Math.Max(0.0001m, x.High - x.Low);
    private static decimal UpperShadow(Candle x) => x.High - Math.Max(x.Open, x.Close);
    private static decimal LowerShadow(Candle x) => Math.Min(x.Open, x.Close) - x.Low;
    private static bool Bull(Candle x) => x.Close > x.Open;
    private static bool Bear(Candle x) => x.Close < x.Open;
    private static bool Near(decimal a, decimal b, decimal tolerance) => Math.Abs(a - b) <= tolerance;
    private static bool GapUp(Candle p, Candle c) => Math.Min(c.Open, c.Close) > Math.Max(p.Open, p.Close);
    private static bool GapDown(Candle p, Candle c) => Math.Max(c.Open, c.Close) < Math.Min(p.Open, p.Close);

    private void ApplyCandlestickPatterns(List<Candle> c)
    {
        if (c.Count < 3) return;
        for (int i = 2; i < c.Count; i++)
        {
            var patterns = DetectCandlestickPatterns(c, i);
            if (patterns.Count == 0)
            {
                c[i].CandlestickPattern = "-";
                c[i].CandlestickBias = "Neutral";
                c[i].CandlestickBrush = "#93A4BD";
                continue;
            }

            c[i].CandlestickPattern = string.Join(", ", patterns.Select(x => x.Name).Take(3));
            int bull = patterns.Count(x => x.Bias == "Bullish");
            int bear = patterns.Count(x => x.Bias == "Bearish");
            c[i].CandlestickBias = bull > bear ? "Bullish" : bear > bull ? "Bearish" : "Neutral";
            c[i].CandlestickBrush = c[i].CandlestickBias == "Bullish" ? "#19C37D" : c[i].CandlestickBias == "Bearish" ? "#FF4D4D" : "#FFC857";
        }
    }

    private List<(string Name, string Bias)> DetectCandlestickPatterns(List<Candle> c, int i)
    {
        var result = new List<(string, string)>();
        Candle a = c[i - 2], p = c[i - 1], x = c[i];
        decimal body = Body(x), range = Range(x), upper = UpperShadow(x), lower = LowerShadow(x);
        decimal avgBody = c.Skip(Math.Max(0, i - 10)).Take(Math.Min(10, i + 1)).Average(Body);
        bool smallBody = body <= range * 0.25m;
        bool longBody = body >= Math.Max(avgBody * 1.2m, range * 0.50m);
        bool doji = body <= range * 0.10m;
        bool longUpper = upper >= body * 2m && upper >= range * 0.35m;
        bool longLower = lower >= body * 2m && lower >= range * 0.35m;
        bool highClose = x.Close >= x.Low + range * 0.70m;
        bool lowClose = x.Close <= x.Low + range * 0.30m;
        decimal tol = Math.Max(0.05m, range * 0.07m);

        // 1 Doji
        if (doji) result.Add(("Doji", "Neutral"));
        // 2 Dragonfly Doji
        if (doji && lower >= range * 0.60m && upper <= range * 0.15m) result.Add(("Dragonfly Doji", "Bullish"));
        // 3 Gravestone Doji
        if (doji && upper >= range * 0.60m && lower <= range * 0.15m) result.Add(("Gravestone Doji", "Bearish"));
        // 4 Spinning Top
        if (!doji && smallBody && upper >= body && lower >= body) result.Add(("Spinning Top", "Neutral"));
        // 5 Hammer
        if (smallBody && longLower && upper <= range * 0.25m && highClose) result.Add(("Hammer", "Bullish"));
        // 6 Hanging Man
        if (smallBody && longLower && upper <= range * 0.25m && Bear(x)) result.Add(("Hanging Man", "Bearish"));
        // 7 Inverted Hammer
        if (smallBody && longUpper && lower <= range * 0.25m && highClose) result.Add(("Inverted Hammer", "Bullish"));
        // 8 Shooting Star
        if (smallBody && longUpper && lower <= range * 0.25m && lowClose) result.Add(("Shooting Star", "Bearish"));
        // 9 Bullish Marubozu
        if (Bull(x) && longBody && upper <= range * 0.08m && lower <= range * 0.08m) result.Add(("Bullish Marubozu", "Bullish"));
        // 10 Bearish Marubozu
        if (Bear(x) && longBody && upper <= range * 0.08m && lower <= range * 0.08m) result.Add(("Bearish Marubozu", "Bearish"));
        // 11 Bullish Engulfing
        if (Bear(p) && Bull(x) && x.Open <= p.Close && x.Close >= p.Open) result.Add(("Bullish Engulfing", "Bullish"));
        // 12 Bearish Engulfing
        if (Bull(p) && Bear(x) && x.Open >= p.Close && x.Close <= p.Open) result.Add(("Bearish Engulfing", "Bearish"));
        // 13 Piercing Line
        if (Bear(p) && Bull(x) && x.Open < p.Low && x.Close > (p.Open + p.Close) / 2m && x.Close < p.Open) result.Add(("Piercing Line", "Bullish"));
        // 14 Dark Cloud Cover
        if (Bull(p) && Bear(x) && x.Open > p.High && x.Close < (p.Open + p.Close) / 2m && x.Close > p.Open) result.Add(("Dark Cloud Cover", "Bearish"));
        // 15 Bullish Harami
        if (Bear(p) && Bull(x) && Math.Max(x.Open, x.Close) < p.Open && Math.Min(x.Open, x.Close) > p.Close) result.Add(("Bullish Harami", "Bullish"));
        // 16 Bearish Harami
        if (Bull(p) && Bear(x) && Math.Max(x.Open, x.Close) < p.Close && Math.Min(x.Open, x.Close) > p.Open) result.Add(("Bearish Harami", "Bearish"));
        // 17 Tweezer Bottom
        if (Bear(p) && Bull(x) && Near(p.Low, x.Low, tol)) result.Add(("Tweezer Bottom", "Bullish"));
        // 18 Tweezer Top
        if (Bull(p) && Bear(x) && Near(p.High, x.High, tol)) result.Add(("Tweezer Top", "Bearish"));
        // 19 Morning Star
        if (Bear(a) && smallBody && Bull(x) && p.Close < a.Close && x.Close > (a.Open + a.Close) / 2m) result.Add(("Morning Star", "Bullish"));
        // 20 Evening Star
        if (Bull(a) && smallBody && Bear(x) && p.Close > a.Close && x.Close < (a.Open + a.Close) / 2m) result.Add(("Evening Star", "Bearish"));
        // 21 Three White Soldiers
        if (i >= 2 && Bull(a) && Bull(p) && Bull(x) && a.Close < p.Close && p.Close < x.Close && Body(a) > 0 && Body(p) > 0 && Body(x) > 0) result.Add(("Three White Soldiers", "Bullish"));
        // 22 Three Black Crows
        if (i >= 2 && Bear(a) && Bear(p) && Bear(x) && a.Close > p.Close && p.Close > x.Close && Body(a) > 0 && Body(p) > 0 && Body(x) > 0) result.Add(("Three Black Crows", "Bearish"));
        // 23 Bullish Kicker
        if (Bear(p) && Bull(x) && GapUp(p, x) && longBody) result.Add(("Bullish Kicker", "Bullish"));
        // 24 Bearish Kicker
        if (Bull(p) && Bear(x) && GapDown(p, x) && longBody) result.Add(("Bearish Kicker", "Bearish"));
        // 25 Three Inside Up
        if (i >= 2 && Bear(a) && Bull(p) && Math.Max(p.Open, p.Close) < a.Open && Math.Min(p.Open, p.Close) > a.Close && Bull(x) && x.Close > a.Open) result.Add(("Three Inside Up", "Bullish"));
        // 26 Three Inside Down
        if (i >= 2 && Bull(a) && Bear(p) && Math.Max(p.Open, p.Close) < a.Close && Math.Min(p.Open, p.Close) > a.Open && Bear(x) && x.Close < a.Open) result.Add(("Three Inside Down", "Bearish"));
        // 27 Three Outside Up
        if (i >= 2 && Bear(a) && Bull(p) && p.Open <= a.Close && p.Close >= a.Open && Bull(x) && x.Close > p.Close) result.Add(("Three Outside Up", "Bullish"));
        // 28 Three Outside Down
        if (i >= 2 && Bull(a) && Bear(p) && p.Open >= a.Close && p.Close <= a.Open && Bear(x) && x.Close < p.Close) result.Add(("Three Outside Down", "Bearish"));
        // 29 Bullish Belt Hold
        if (Bull(x) && lower <= range * 0.05m && body >= range * 0.60m) result.Add(("Bullish Belt Hold", "Bullish"));
        // 30 Bearish Belt Hold
        if (Bear(x) && upper <= range * 0.05m && body >= range * 0.60m) result.Add(("Bearish Belt Hold", "Bearish"));
        // 31 Inside Bar
        if (x.High < p.High && x.Low > p.Low) result.Add(("Inside Bar", "Neutral"));

        return result;
    }


    private void ApplyAdvancedTrendSet(List<Candle> c)
    {
        ApplyEma(c, 3, (x, v) => x.Ema3 = v);
        ApplyVwma(c, 20);
        ApplyTema3VsTema20(c);
        ApplyTtmSqueeze(c, 20);
        ApplyVortex(c, 14);
        ApplyChandelier(c, 22, 3m);
        ApplyElderRay(c, 13);
        ApplyCamarilla(c);
        ApplyAroon(c, 14);
        ApplyPsar(c);
    }

    private void ApplyVwma(List<Candle> c, int p)
    {
        for (int i = p - 1; i < c.Count; i++)
        {
            var window = c.Skip(i - p + 1).Take(p).ToList();
            decimal vol = window.Sum(x => x.Volume);
            c[i].Vwma20 = vol == 0 ? 0 : window.Sum(x => x.Close * x.Volume) / vol;
        }
    }

    private void ApplyTema3VsTema20(List<Candle> c)
    {
        var close = c.Select(x => x.Close).ToList();
        var ema1_3 = CalcEmaFromValues(close, 3);
        var ema2_3 = CalcEmaFromValues(ema1_3, 3);
        var ema3_3 = CalcEmaFromValues(ema2_3, 3);
        for (int i = 0; i < c.Count; i++)
        {
            c[i].Tema3 = (3 * ema1_3[i]) - (3 * ema2_3[i]) + ema3_3[i];
            c[i].Tema3VsTema20Signal = c[i].Tema3 > c[i].Tema20 ? "TEMA3 > TEMA20" : c[i].Tema3 < c[i].Tema20 ? "TEMA3 < TEMA20" : "Equal";
            c[i].Tema3VsTema20Brush = c[i].Tema3 > c[i].Tema20 ? "#19C37D" : c[i].Tema3 < c[i].Tema20 ? "#FF4D4D" : "#93A4BD";
            c[i].PriceVsEma3Signal = c[i].Close > c[i].Ema3 ? "Price > EMA3" : c[i].Close < c[i].Ema3 ? "Price < EMA3" : "Equal";
            c[i].PriceVsEma3Brush = c[i].Close > c[i].Ema3 ? "#19C37D" : c[i].Close < c[i].Ema3 ? "#FF4D4D" : "#93A4BD";
        }
    }

    private void ApplyTtmSqueeze(List<Candle> c, int p)
    {
        for (int i = p - 1; i < c.Count; i++)
        {
            bool squeezeOn = c[i].BollUpper < c[i].KeltnerUpper && c[i].BollLower > c[i].KeltnerLower;
            bool squeezeOff = c[i].BollUpper > c[i].KeltnerUpper && c[i].BollLower < c[i].KeltnerLower;
            c[i].TtmSqueezeStatus = squeezeOn ? "Squeeze ON" : squeezeOff ? "Squeeze OFF" : "Neutral";
            c[i].TtmSqueezeBrush = squeezeOn ? "#FFC857" : squeezeOff ? "#19C37D" : "#93A4BD";
        }
    }

    private void ApplyVortex(List<Candle> c, int p)
    {
        for (int i = p; i < c.Count; i++)
        {
            decimal tr = 0, vmp = 0, vmm = 0;
            for (int j = i - p + 1; j <= i; j++)
            {
                decimal trueRange = Math.Max(c[j].High - c[j].Low, Math.Max(Math.Abs(c[j].High - c[j - 1].Close), Math.Abs(c[j].Low - c[j - 1].Close)));
                tr += trueRange;
                vmp += Math.Abs(c[j].High - c[j - 1].Low);
                vmm += Math.Abs(c[j].Low - c[j - 1].High);
            }
            c[i].VortexPlus14 = tr == 0 ? 0 : vmp / tr;
            c[i].VortexMinus14 = tr == 0 ? 0 : vmm / tr;
            c[i].VortexSignal = c[i].VortexPlus14 > c[i].VortexMinus14 ? "Bullish" : c[i].VortexPlus14 < c[i].VortexMinus14 ? "Bearish" : "Neutral";
            c[i].VortexBrush = c[i].VortexSignal == "Bullish" ? "#19C37D" : c[i].VortexSignal == "Bearish" ? "#FF4D4D" : "#93A4BD";
        }
    }

    private void ApplyChandelier(List<Candle> c, int p, decimal multiplier)
    {
        for (int i = p - 1; i < c.Count; i++)
        {
            var window = c.Skip(i - p + 1).Take(p).ToList();
            decimal high = window.Max(x => x.High);
            decimal low = window.Min(x => x.Low);
            c[i].ChandelierLong = high - multiplier * c[i].Atr14;
            c[i].ChandelierShort = low + multiplier * c[i].Atr14;
            c[i].ChandelierSignal = c[i].Close > c[i].ChandelierLong ? "Bullish" : c[i].Close < c[i].ChandelierShort ? "Bearish" : "Neutral";
            c[i].ChandelierBrush = c[i].ChandelierSignal == "Bullish" ? "#19C37D" : c[i].ChandelierSignal == "Bearish" ? "#FF4D4D" : "#93A4BD";
        }
    }

    private void ApplyElderRay(List<Candle> c, int p)
    {
        var ema = CalcEmaFromValues(c.Select(x => x.Close).ToList(), p);
        for (int i = 0; i < c.Count; i++)
        {
            c[i].ElderBullPower = c[i].High - ema[i];
            c[i].ElderBearPower = c[i].Low - ema[i];
            c[i].ElderRaySignal = c[i].ElderBullPower > 0 && c[i].ElderBearPower > 0 ? "Bull Control" : c[i].ElderBullPower < 0 && c[i].ElderBearPower < 0 ? "Bear Control" : "Mixed";
            c[i].ElderRayBrush = c[i].ElderRaySignal == "Bull Control" ? "#19C37D" : c[i].ElderRaySignal == "Bear Control" ? "#FF4D4D" : "#FFC857";
        }
    }

    private void ApplyCamarilla(List<Candle> c)
    {
        if (c.Count == 0) return;
        var grouped = c.GroupBy(x => x.Time.Date).OrderBy(g => g.Key).ToList();
        foreach (var dayGroup in grouped)
        {
            var prev = grouped.LastOrDefault(g => g.Key < dayGroup.Key)?.ToList();
            if (prev == null || prev.Count == 0) continue;
            decimal high = prev.Max(x => x.High), low = prev.Min(x => x.Low), close = prev.Last().Close;
            decimal range = high - low;
            decimal h3 = close + range * 1.1m / 4m;
            decimal h4 = close + range * 1.1m / 2m;
            decimal l3 = close - range * 1.1m / 4m;
            decimal l4 = close - range * 1.1m / 2m;
            foreach (var x in dayGroup)
            {
                if (x.Close > h4) { x.CamarillaZone = "Above H4 Breakout"; x.CamarillaBrush = "#19C37D"; }
                else if (x.Close > h3) { x.CamarillaZone = "H3-H4 Sell Zone"; x.CamarillaBrush = "#FFC857"; }
                else if (x.Close < l4) { x.CamarillaZone = "Below L4 Breakdown"; x.CamarillaBrush = "#FF4D4D"; }
                else if (x.Close < l3) { x.CamarillaZone = "L3-L4 Buy Zone"; x.CamarillaBrush = "#2DD4FF"; }
                else { x.CamarillaZone = "Inside L3-H3"; x.CamarillaBrush = "#93A4BD"; }
            }
        }
    }

    private void ApplyAroon(List<Candle> c, int p)
    {
        for (int i = p - 1; i < c.Count; i++)
        {
            var window = c.Skip(i - p + 1).Take(p).ToList();
            int highIndex = window.Select((x, idx) => new { x.High, idx }).OrderByDescending(x => x.High).First().idx;
            int lowIndex = window.Select((x, idx) => new { x.Low, idx }).OrderBy(x => x.Low).First().idx;
            int periodsSinceHigh = p - 1 - highIndex;
            int periodsSinceLow = p - 1 - lowIndex;
            c[i].AroonUp14 = ((decimal)(p - periodsSinceHigh) / p) * 100m;
            c[i].AroonDown14 = ((decimal)(p - periodsSinceLow) / p) * 100m;
            c[i].AroonSignal = c[i].AroonUp14 > c[i].AroonDown14 ? "Bullish" : c[i].AroonUp14 < c[i].AroonDown14 ? "Bearish" : "Neutral";
            c[i].AroonBrush = c[i].AroonSignal == "Bullish" ? "#19C37D" : c[i].AroonSignal == "Bearish" ? "#FF4D4D" : "#93A4BD";
        }
    }

    private void ApplyPsar(List<Candle> c)
    {
        if (c.Count < 2) return;
        bool upTrend = c[1].Close >= c[0].Close;
        decimal af = 0.02m, maxAf = 0.20m, ep = upTrend ? c[0].High : c[0].Low, sar = upTrend ? c[0].Low : c[0].High;
        for (int i = 1; i < c.Count; i++)
        {
            sar = sar + af * (ep - sar);
            if (upTrend)
            {
                if (c[i].Low < sar) { upTrend = false; sar = ep; ep = c[i].Low; af = 0.02m; }
                else if (c[i].High > ep) { ep = c[i].High; af = Math.Min(maxAf, af + 0.02m); }
            }
            else
            {
                if (c[i].High > sar) { upTrend = true; sar = ep; ep = c[i].High; af = 0.02m; }
                else if (c[i].Low < ep) { ep = c[i].Low; af = Math.Min(maxAf, af + 0.02m); }
            }
            c[i].Psar = sar;
            c[i].PsarSignal = c[i].Close > sar ? "Bullish" : "Bearish";
            c[i].PsarBrush = c[i].PsarSignal == "Bullish" ? "#19C37D" : "#FF4D4D";
        }
    }

    public TrendSnapshot BuildTrend(List<Candle> c)
    {
        var x=c.LastOrDefault(); if(x==null) return new TrendSnapshot();
        bool bullEma=x.Ema20>x.Ema50&&x.Ema50>x.Ema200, bullSma=x.Sma20>x.Sma50, aboveVwap=x.Close>x.Vwap;
        string band=x.Close>x.BollUpper?"Above Upper":x.Close<x.BollLower?"Below Lower":"Inside";
        string don=x.Close>=x.DonchianUpper?"Break High":x.Close<=x.DonchianLower?"Break Low":"Inside";
        string kel=x.Close>x.KeltnerUpper?"Above Upper":x.Close<x.KeltnerLower?"Below Lower":"Inside";
        return new TrendSnapshot
        {
            EmaTrend=bullEma?"Bullish":"Bearish/Flat",
            SmaTrend=bullSma?"Bullish":"Bearish/Flat",
            VwapStatus=aboveVwap?"Above":"Below",
            Atr=x.Atr14,
            Rsi=x.Rsi14,
            Macd=x.Macd,
            MacdSignal=x.MacdSignal,
            MacdStatus=x.Macd>x.MacdSignal?"Bullish":"Bearish",
            Adx=x.Adx14,
            AdxStatus=x.Adx14>=25?"Strong":"Weak",
            SuperTrend=x.SuperTrendBullish?"Buy":"Sell",
            BollingerStatus=band,
            DonchianStatus=don,
            KeltnerStatus=kel,
            Rvol=x.Rvol,
            VolumeProfilePoc=x.VolumeProfilePoc,
            Roc=x.Roc14,
            Cci=x.Cci20,
            Stochastic=x.StochasticK14,
            Mfi=x.Mfi14,
            Cmf=x.Cmf20,
            Obv=x.Obv,
            AdLine=x.AdLine,
            SmartFlow=x.SmartFlow,
            AbsorptionScore=x.AbsorptionScore,
            HistoricalVolatility=x.HistoricalVolatility20,
            StdDev20=x.StdDev20,
            Dema20=x.Dema20,
            Tema20=x.Tema20,
            DemaTemaSignal=x.DemaTemaSignal,
            Vwma20=x.Vwma20,
            TtmSqueezeStatus=x.TtmSqueezeStatus,
            VortexPlus=x.VortexPlus14,
            VortexMinus=x.VortexMinus14,
            VortexSignal=x.VortexSignal,
            ChandelierLong=x.ChandelierLong,
            ChandelierShort=x.ChandelierShort,
            ChandelierSignal=x.ChandelierSignal,
            ElderBullPower=x.ElderBullPower,
            ElderBearPower=x.ElderBearPower,
            ElderRaySignal=x.ElderRaySignal,
            Tema3=x.Tema3,
            Tema3VsTema20Signal=x.Tema3VsTema20Signal,
            PriceVsEma3Signal=x.PriceVsEma3Signal,
            CamarillaZone=x.CamarillaZone,
            AroonUp=x.AroonUp14,
            AroonDown=x.AroonDown14,
            AroonSignal=x.AroonSignal,
            Psar=x.Psar,
            PsarSignal=x.PsarSignal,
            CandlestickPattern=x.CandlestickPattern,
            CandlestickBias=x.CandlestickBias,
            CandlestickBrush=x.CandlestickBrush,
            TrendBias=bullEma&&aboveVwap&&x.Macd>x.MacdSignal?"Bullish":(!aboveVwap&&x.Macd<x.MacdSignal?"Bearish":"Neutral"),
            EmaBrush=bullEma?"#19C37D":"#FF4D4D",
            SmaBrush=bullSma?"#19C37D":"#FF4D4D",
            VwapBrush=aboveVwap?"#19C37D":"#FF4D4D",
            RsiBrush=x.Rsi14>=70?"#FFC857":x.Rsi14<=30?"#2DD4FF":"#E7EEFB",
            MacdBrush=x.Macd>x.MacdSignal?"#19C37D":"#FF4D4D",
            AdxBrush=x.Adx14>=25?"#FFC857":"#93A4BD",
            SuperTrendBrush=x.SuperTrendBullish?"#19C37D":"#FF4D4D",
            RvolBrush=x.Rvol>=1.5m?"#FFC857":x.Rvol>=1.1m?"#2DD4FF":"#93A4BD",
            BollingerBrush=band=="Above Upper"?"#19C37D":band=="Below Lower"?"#FF4D4D":"#93A4BD",
            DonchianBrush=don=="Break High"?"#19C37D":don=="Break Low"?"#FF4D4D":"#93A4BD",
            KeltnerBrush=kel=="Above Upper"?"#19C37D":kel=="Below Lower"?"#FF4D4D":"#93A4BD",
            RocBrush=x.Roc14>0?"#19C37D":x.Roc14<0?"#FF4D4D":"#93A4BD",
            CciBrush=x.Cci20>=100?"#19C37D":x.Cci20<=-100?"#FF4D4D":"#FFC857",
            StochasticBrush=x.StochasticK14>=80?"#FFC857":x.StochasticK14<=20?"#2DD4FF":x.StochasticK14>=50?"#19C37D":"#FF4D4D",
            MfiBrush=x.Mfi14>=80?"#FFC857":x.Mfi14<=20?"#2DD4FF":x.Mfi14>=50?"#19C37D":"#FF4D4D",
            CmfBrush=x.Cmf20>0?"#19C37D":x.Cmf20<0?"#FF4D4D":"#93A4BD",
            ObvBrush=x.Obv>=0?"#19C37D":"#FF4D4D",
            AdLineBrush=x.AdLine>=0?"#19C37D":"#FF4D4D",
            SmartFlowBrush=x.SmartFlow>=0?"#19C37D":"#FF4D4D",
            AbsorptionBrush=x.AbsorptionScore>=60?"#19C37D":x.AbsorptionScore>=30?"#FFC857":"#93A4BD",
            HistoricalVolatilityBrush=x.HistoricalVolatility20>=40?"#FF4D4D":x.HistoricalVolatility20>=20?"#FFC857":"#19C37D",
            StdDevBrush=x.StdDev20>=x.Atr14?"#FFC857":"#93A4BD",
            DemaBrush=x.Close>=x.Dema20?"#19C37D":"#FF4D4D",
            TemaBrush=x.Close>=x.Tema20?"#19C37D":"#FF4D4D",
            DemaTemaBrush=x.DemaTemaBrush,
            VwmaBrush=x.Close>=x.Vwma20?"#19C37D":"#FF4D4D",
            TtmSqueezeBrush=x.TtmSqueezeBrush,
            VortexBrush=x.VortexBrush,
            ChandelierBrush=x.ChandelierBrush,
            ElderRayBrush=x.ElderRayBrush,
            Tema3VsTema20Brush=x.Tema3VsTema20Brush,
            PriceVsEma3Brush=x.PriceVsEma3Brush,
            CamarillaBrush=x.CamarillaBrush,
            AroonBrush=x.AroonBrush,
            PsarBrush=x.PsarBrush
        };
    }
}
