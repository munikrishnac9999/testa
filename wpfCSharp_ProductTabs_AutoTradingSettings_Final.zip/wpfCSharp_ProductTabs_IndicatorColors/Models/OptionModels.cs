namespace wpfCSharp_LiveOnly_WPF.Models;
public sealed class OptionLeg
{
    public string Symbol { get; set; } = string.Empty;
    public string Side { get; set; } = string.Empty;
    public decimal Strike { get; set; }
    public decimal Ltp { get; set; }
    public decimal Oi { get; set; }
    public decimal OiChange { get; set; }
    public decimal Volume { get; set; }
    public decimal Iv { get; set; }
    public decimal Delta { get; set; }
    public decimal Gamma { get; set; }
    public decimal Theta { get; set; }
    public decimal Vega { get; set; }
    public decimal PriceChange { get; set; }
    public string Signal { get; set; } = "Neutral";
    public string SignalBrush { get; set; } = "#93A4BD";
    public string PriceBrush { get; set; } = "#E7EEFB";
    public string IvBrush { get; set; } = "#E7EEFB";
    public string OiChangeBrush { get; set; } = "#93A4BD";
    public string DeltaBrush { get; set; } = "#93A4BD";
    public string GammaBrush { get; set; } = "#93A4BD";
    public string ThetaBrush { get; set; } = "#93A4BD";
    public string VegaBrush { get; set; } = "#93A4BD";
}
public sealed class OptionChainRow
{
    public decimal Strike { get; set; }
    public bool IsAtm { get; set; }
    public OptionLeg? CE { get; set; }
    public OptionLeg? PE { get; set; }
    public string StrikeBrush { get; set; } = "#E7EEFB";
}
