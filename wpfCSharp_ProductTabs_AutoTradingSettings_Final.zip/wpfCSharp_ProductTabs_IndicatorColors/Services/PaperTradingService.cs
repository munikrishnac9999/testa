using System.Collections.ObjectModel;
using wpfCSharp_LiveOnly_WPF.Models;

namespace wpfCSharp_LiveOnly_WPF.Services;

public sealed class PaperTradingService
{
    private int _tradeId;
    public ObservableCollection<PaperTrade> Trades { get; } = new();
    public PaperTradingSummary Summary { get; } = new();

    public bool IsEnabled { get; set; } = true;
    public decimal Quantity { get; set; } = 1;

    public void ProcessSignal(string symbol, decimal spot, SmartMoneySnapshot score)
    {
        Summary.Enabled = IsEnabled;
        Summary.Quantity = Quantity;

        if (!IsEnabled || spot <= 0)
        {
            UpdateOpenPnl(spot);
            RefreshSummary("Paper trading disabled");
            return;
        }

        UpdateOpenPnl(spot);
        CloseByStopOrTarget(spot);

        string signal = score.Signal ?? string.Empty;

        if (signal.Contains("BUY", StringComparison.OrdinalIgnoreCase))
        {
            CloseOpposite(PaperTradeSide.Sell, spot, "Direction changed to BUY");
            OpenIfNone(symbol, PaperTradeSide.Buy, spot, score);
        }
        else if (signal.Contains("SELL", StringComparison.OrdinalIgnoreCase))
        {
            CloseOpposite(PaperTradeSide.Buy, spot, "Direction changed to SELL");
            OpenIfNone(symbol, PaperTradeSide.Sell, spot, score);
        }
        else
        {
            RefreshSummary("WAIT signal. Existing paper position monitored.");
        }

        UpdateOpenPnl(spot);
        RefreshSummary(Summary.LastAction);
    }

    private void OpenIfNone(string symbol, PaperTradeSide side, decimal spot, SmartMoneySnapshot score)
    {
        if (Trades.Any(t => t.Status == PaperTradeStatus.Open && t.Side == side))
        {
            Summary.LastAction = $"Holding {side}";
            return;
        }

        var trade = new PaperTrade
        {
            Id = ++_tradeId,
            Symbol = symbol,
            Side = side,
            Quantity = Quantity,
            EntryPrice = spot,
            StopLoss = score.StopLoss,
            Target1 = score.Target1,
            Target2 = score.Target2,
            EntryReason = score.Reason,
            EntryTime = DateTime.Now,
            Status = PaperTradeStatus.Open
        };

        Trades.Insert(0, trade);
        Summary.LastAction = $"OPEN {trade.SideText} {trade.Quantity} @ {trade.EntryPrice:0.00}";
    }

    private void CloseOpposite(PaperTradeSide sideToClose, decimal price, string reason)
    {
        foreach (var trade in Trades.Where(t => t.Status == PaperTradeStatus.Open && t.Side == sideToClose).ToList())
            CloseTrade(trade, price, reason);
    }

    private void CloseByStopOrTarget(decimal spot)
    {
        foreach (var trade in Trades.Where(t => t.Status == PaperTradeStatus.Open).ToList())
        {
            if (trade.Side == PaperTradeSide.Buy)
            {
                if (trade.StopLoss > 0 && spot <= trade.StopLoss) CloseTrade(trade, spot, "SL hit");
                else if (trade.Target2 > 0 && spot >= trade.Target2) CloseTrade(trade, spot, "Target 2 hit");
                else if (trade.Target1 > 0 && spot >= trade.Target1) CloseTrade(trade, spot, "Target 1 hit");
            }
            else
            {
                if (trade.StopLoss > 0 && spot >= trade.StopLoss) CloseTrade(trade, spot, "SL hit");
                else if (trade.Target2 > 0 && spot <= trade.Target2) CloseTrade(trade, spot, "Target 2 hit");
                else if (trade.Target1 > 0 && spot <= trade.Target1) CloseTrade(trade, spot, "Target 1 hit");
            }
        }
    }

    private void CloseTrade(PaperTrade trade, decimal exitPrice, string reason)
    {
        if (trade.Status == PaperTradeStatus.Closed) return;

        trade.ExitPrice = exitPrice;
        trade.ExitTime = DateTime.Now;
        trade.RealizedPnl = CalculatePnl(trade, exitPrice);
        trade.UnrealizedPnl = 0;
        trade.ExitReason = reason;
        trade.Status = PaperTradeStatus.Closed;
        Summary.LastAction = $"CLOSE {trade.SideText} #{trade.Id} @ {exitPrice:0.00} | PnL {trade.RealizedPnl:0.00} | {reason}";
    }

    private void UpdateOpenPnl(decimal spot)
    {
        foreach (var trade in Trades.Where(t => t.Status == PaperTradeStatus.Open))
            trade.UnrealizedPnl = CalculatePnl(trade, spot);
    }

    private static decimal CalculatePnl(PaperTrade trade, decimal currentPrice)
    {
        return trade.Side == PaperTradeSide.Buy
            ? (currentPrice - trade.EntryPrice) * trade.Quantity
            : (trade.EntryPrice - currentPrice) * trade.Quantity;
    }

    private void RefreshSummary(string action)
    {
        Summary.TotalTrades = Trades.Count;
        Summary.OpenTrades = Trades.Count(t => t.Status == PaperTradeStatus.Open);
        Summary.ClosedTrades = Trades.Count(t => t.Status == PaperTradeStatus.Closed);
        Summary.TotalProfit = Trades.Where(t => t.Status == PaperTradeStatus.Closed && t.RealizedPnl > 0).Sum(t => t.RealizedPnl);
        Summary.TotalLoss = Trades.Where(t => t.Status == PaperTradeStatus.Closed && t.RealizedPnl < 0).Sum(t => Math.Abs(t.RealizedPnl));
        Summary.NetPnl = Summary.TotalProfit - Summary.TotalLoss;
        Summary.OpenPnl = Trades.Where(t => t.Status == PaperTradeStatus.Open).Sum(t => t.UnrealizedPnl);
        Summary.CurrentPosition = Trades.FirstOrDefault(t => t.Status == PaperTradeStatus.Open)?.SideText ?? "None";
        if (!string.IsNullOrWhiteSpace(action)) Summary.LastAction = action;
    }
}
