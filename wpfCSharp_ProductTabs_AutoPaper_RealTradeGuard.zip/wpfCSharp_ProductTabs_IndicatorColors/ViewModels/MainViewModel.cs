using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using System.Windows.Threading;
using wpfCSharp_LiveOnly_WPF.Models;
using wpfCSharp_LiveOnly_WPF.Services;
namespace wpfCSharp_LiveOnly_WPF.ViewModels;
public sealed class MainViewModel : INotifyPropertyChanged
{
    private readonly FyersApiClient _api = new();
    private readonly FyersAuthService _auth = new();
    private readonly IndicatorService _ind = new();
    private readonly SmartMoneyService _smart = new();
    private readonly PaperTradingService _paper = new();
    private readonly IBrokerOrderService _brokerOrders = new RealOrderDisabledService();
    private FyersHistoryService? _history;
    private FyersOptionChainService? _chain;
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(2) };
    private string _lastCandlestickAlertKey = string.Empty;
    private string _lastDemaTemaAlertKey = string.Empty;
    private string _lastAdvancedIndicatorAlertKey = string.Empty;
    private string _lastSmcAlertKey = string.Empty;
    private string _lastOrderBlockAlertKey = string.Empty;
    private string _lastSuperTrendAlertKey = string.Empty;
    public ObservableCollection<Candle> Candles { get; } = new();
    public ObservableCollection<OptionChainRow> OptionRows { get; } = new();
    public ObservableCollection<OptionChainRow> LongBuildRows { get; } = new();
    public ObservableCollection<OptionChainRow> ShortBuildRows { get; } = new();
    public ObservableCollection<OptionChainRow> LongUnwindRows { get; } = new();
    public ObservableCollection<OptionChainRow> ShortCoverRows { get; } = new();
    public ObservableCollection<AlertMessage> Alerts { get; } = new();
    public ObservableCollection<string> TradingModes { get; } = new() { "Paper Trading", "Manual Trading", "Real Trading" };
    public ObservableCollection<PaperTrade> PaperTrades => _paper.Trades;
    public PaperTradingSummary PaperSummary => _paper.Summary;

    private string _selectedTradingMode = "Paper Trading";
    public string SelectedTradingMode
    {
        get => _selectedTradingMode;
        set
        {
            if (string.IsNullOrWhiteSpace(value)) return;
            _selectedTradingMode = value;
            ApplyTradingMode(value, announce: true);
            OnPropertyChanged();
            OnPropertyChanged(nameof(IsPaperTradingSelected));
            OnPropertyChanged(nameof(IsManualTradingSelected));
            OnPropertyChanged(nameof(IsRealTradingSelected));
            OnPropertyChanged(nameof(TradingModeDescription));
        }
    }

    public bool IsPaperTradingSelected
    {
        get => SelectedTradingMode == "Paper Trading";
        set { if (value) SelectedTradingMode = "Paper Trading"; }
    }

    public bool IsManualTradingSelected
    {
        get => SelectedTradingMode == "Manual Trading";
        set { if (value) SelectedTradingMode = "Manual Trading"; }
    }

    public bool IsRealTradingSelected
    {
        get => SelectedTradingMode == "Real Trading";
        set { if (value) SelectedTradingMode = "Real Trading"; }
    }

    private string _tradingStatus = "Paper Trading active. No broker order execution.";
    public string TradingStatus { get => _tradingStatus; set { _tradingStatus = value; OnPropertyChanged(); } }

    private string _tradingStatusBrush = "#19C37D";
    public string TradingStatusBrush { get => _tradingStatusBrush; set { _tradingStatusBrush = value; OnPropertyChanged(); } }

    private bool _realTradingConfirmed;
    public bool RealTradingConfirmed { get => _realTradingConfirmed; set { _realTradingConfirmed = value; OnPropertyChanged(); } }

    public bool BrokerOrderServiceConnected => _brokerOrders.IsConnected;

    private string _lastRealOrderStatus = "No real order attempted.";
    public string LastRealOrderStatus { get => _lastRealOrderStatus; set { _lastRealOrderStatus = value; OnPropertyChanged(); } }

    private string _lastRealOrderStatusBrush = "#93A4BD";
    public string LastRealOrderStatusBrush { get => _lastRealOrderStatusBrush; set { _lastRealOrderStatusBrush = value; OnPropertyChanged(); } }

    private decimal _realTradeQuantity = 1;
    public decimal RealTradeQuantity
    {
        get => _realTradeQuantity;
        set { _realTradeQuantity = value <= 0 ? 1 : value; OnPropertyChanged(); }
    }

    private int _realTradeBuyThreshold = 75;
    public int RealTradeBuyThreshold
    {
        get => _realTradeBuyThreshold;
        set { _realTradeBuyThreshold = Math.Max(1, Math.Min(100, value)); OnPropertyChanged(); }
    }

    private int _realTradeSellThreshold = 35;
    public int RealTradeSellThreshold
    {
        get => _realTradeSellThreshold;
        set { _realTradeSellThreshold = Math.Max(0, Math.Min(99, value)); OnPropertyChanged(); }
    }

    public string TradingModeDescription => SelectedTradingMode switch
    {
        "Paper Trading" => "Auto paper trades, paper PnL, trade journal and alerts only.",
        "Manual Trading" => "Manual simulated trades only. No broker API order is sent.",
        "Real Trading" => "Real Trading requires confirmation. Current build keeps broker execution locked and uses preview status only.",
        _ => "Select a trading mode."
    };
    public ICommand LoginCommand { get; }
    public ICommand StartCommand { get; }
    public ICommand StopCommand { get; }
    public ICommand TimeframeCommand { get; }
    public ICommand TradingModeCommand { get; }
    public string AppId { get => _api.AppId; set { _api.AppId = value; OnPropertyChanged(); } }
    private string _appSecret = string.Empty; public string AppSecret { get => _appSecret; set { _appSecret = value; OnPropertyChanged(); } }
    private string _authCode = string.Empty; public string AuthCode { get => _authCode; set { _authCode = value; OnPropertyChanged(); } }
    private string _symbol = "NSE:NIFTY50-INDEX"; public string Symbol { get => _symbol; set { _symbol = value; OnPropertyChanged(); } }
    private string _resolution = "5";
    public string Resolution
    {
        get => _resolution;
        set
        {
            _resolution = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(TimeframeLabel));
        }
    }
    public string TimeframeLabel => Resolution switch
    {
        "60" => "1h",
        "120" => "120m",
        "180" => "180m",
        "240" => "240m",
        "280" => "280m",
        _ => string.IsNullOrWhiteSpace(Resolution) ? "-" : Resolution + "m"
    };
    // 50 gives a much broader current-expiry scan. Use 0 to request all current-expiry strikes if FYERS returns it.
    private int _strikeCount = 50; public int StrikeCount { get => _strikeCount; set { _strikeCount = value; OnPropertyChanged(); } }
    private string _status = "Not logged in"; public string Status { get => _status; set { _status = value; OnPropertyChanged(); } }
    private decimal _spot; public decimal Spot { get => _spot; set { _spot = value; OnPropertyChanged(); } }
    private string _expiry = "-"; public string Expiry { get => _expiry; set { _expiry = value; OnPropertyChanged(); } }
    private TrendSnapshot _trend = new(); public TrendSnapshot Trend { get => _trend; set { _trend = value; OnPropertyChanged(); } }
    private SmartMoneySnapshot _score = new(); public SmartMoneySnapshot Score { get => _score; set { _score = value; OnPropertyChanged(); } }
    private bool _enablePaperTrading = true;
    public bool EnablePaperTrading
    {
        get => _enablePaperTrading;
        set
        {
            _enablePaperTrading = value;
            _paper.IsEnabled = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(PaperSummary));
        }
    }
    public bool EnableAutoPaperTrade
    {
        get => EnablePaperTrading;
        set
        {
            EnablePaperTrading = value;
            OnPropertyChanged(nameof(EnableAutoPaperTrade));
            if (value)
            {
                SelectedTradingMode = "Paper Trading";
                TradingStatus = "Auto Paper Trade enabled. Paper simulation active.";
                TradingStatusBrush = "#19C37D";
            }
            else if (SelectedTradingMode == "Paper Trading")
            {
                TradingStatus = "Auto Paper Trade disabled. Paper simulation paused.";
                TradingStatusBrush = "#FFC857";
            }
        }
    }

    private bool _enableRealTrade;
    public bool EnableRealTrade
    {
        get => _enableRealTrade;
        set
        {
            _enableRealTrade = value;
            OnPropertyChanged();
            if (value)
            {
                SelectedTradingMode = "Real Trading";
                TradingStatus = RealTradingConfirmed
                    ? "Real Trade enabled and confirmed. Execution remains locked until broker order service is implemented."
                    : "Real Trade enabled. Confirmation required before any real-trade workflow can be armed.";
                TradingStatusBrush = "#FFC857";
                AddAlert("Enable Real Trade selected. Confirmation is required. No broker order API is connected.", "#FFC857");
            }
            else
            {
                RealTradingConfirmed = false;
                if (SelectedTradingMode == "Real Trading") SelectedTradingMode = "Paper Trading";
                TradingStatus = "Real Trade disabled. Returned to safe paper/simulation mode.";
                TradingStatusBrush = "#19C37D";
                AddAlert("Real Trade disabled. Safe simulation mode active.", "#19C37D");
            }
        }
    }

    private decimal _paperQuantity = 1;
    public decimal PaperQuantity
    {
        get => _paperQuantity;
        set
        {
            _paperQuantity = value <= 0 ? 1 : value;
            _paper.Quantity = _paperQuantity;
            OnPropertyChanged();
            OnPropertyChanged(nameof(PaperSummary));
        }
    }
    public MainViewModel()
    {
        LoginCommand = new RelayCommand(LoginAsync);
        StartCommand = new RelayCommand(async _ => { _timer.Start(); await RefreshAsync(); Status = "LIVE"; });
        StopCommand = new RelayCommand(_ => { _timer.Stop(); Status = "Stopped"; });
        TimeframeCommand = new RelayCommand(SetTimeframeAsync);
        TradingModeCommand = new RelayCommand(p => { if (p != null) SelectedTradingMode = p.ToString() ?? "Paper Trading"; });
        ApplyTradingMode(SelectedTradingMode, announce: false);
        _timer.Tick += async (_, _) => await RefreshAsync();
    }


    private void ApplyTradingMode(string mode, bool announce)
    {
        if (mode == "Paper Trading")
        {
            EnablePaperTrading = true;
            _enableRealTrade = false;
            OnPropertyChanged(nameof(EnableRealTrade));
            RealTradingConfirmed = false;
            TradingStatus = "Paper Trading active. Auto paper simulation enabled.";
            TradingStatusBrush = "#19C37D";
        }
        else if (mode == "Manual Trading")
        {
            EnablePaperTrading = false;
            _enableRealTrade = false;
            OnPropertyChanged(nameof(EnableRealTrade));
            RealTradingConfirmed = false;
            TradingStatus = "Manual Trading selected. Simulation only. No broker order execution.";
            TradingStatusBrush = "#2DD4FF";
        }
        else
        {
            EnablePaperTrading = false;
            _enableRealTrade = true;
            OnPropertyChanged(nameof(EnableRealTrade));
            RealTradingConfirmed = false;
            TradingStatus = "Real Trading selected. Enable Real Trade is ON. Confirmation required. Broker execution is locked in this build.";
            TradingStatusBrush = "#FFC857";
        }

        if (announce)
            AddAlert($"Trading mode changed to {mode}. {TradingModeDescription}", TradingStatusBrush);
    }

    public void ConfirmRealTradingPreview()
    {
        if (SelectedTradingMode != "Real Trading")
        {
            AddAlert("Real trading confirmation ignored because Real Trading mode is not selected.", "#FFC857");
            return;
        }

        _enableRealTrade = true;
        OnPropertyChanged(nameof(EnableRealTrade));
        RealTradingConfirmed = true;
        TradingStatus = BrokerOrderServiceConnected
            ? "Enable Real Trade confirmed. Broker service connected state detected."
            : "Enable Real Trade confirmed. Broker execution remains blocked because order API is not connected.";
        TradingStatusBrush = "#FFC857";
        AddAlert("REAL TRADING CONFIRMED: Real order workflow is armed, but broker execution is blocked unless broker order service is connected.", "#FFC857");
    }


    private async Task EvaluateAutomaticTradingAsync()
    {
        if (SelectedTradingMode != "Real Trading" || !EnableRealTrade)
        {
            LastRealOrderStatus = "Real trade automation inactive.";
            LastRealOrderStatusBrush = "#93A4BD";
            return;
        }

        if (!RealTradingConfirmed)
        {
            LastRealOrderStatus = "Real trade automation waiting for confirmation.";
            LastRealOrderStatusBrush = "#FFC857";
            return;
        }

        string side = string.Empty;
        if (Score.FinalScore >= RealTradeBuyThreshold && Score.Signal.Contains("BUY", StringComparison.OrdinalIgnoreCase))
            side = "BUY";
        else if (Score.FinalScore <= RealTradeSellThreshold && Score.Signal.Contains("SELL", StringComparison.OrdinalIgnoreCase))
            side = "SELL";

        if (string.IsNullOrWhiteSpace(side))
        {
            LastRealOrderStatus = $"No real order signal. Score {Score.FinalScore}, Signal {Score.Signal}.";
            LastRealOrderStatusBrush = "#93A4BD";
            return;
        }

        var request = new BrokerOrderRequest
        {
            Symbol = Symbol,
            Side = side,
            Quantity = RealTradeQuantity,
            Price = Spot,
            FinalScore = Score.FinalScore,
            Signal = Score.Signal,
            TradingMode = SelectedTradingMode
        };

        var preview = await _brokerOrders.PreviewOrderAsync(request);
        AddAlert("REAL PREVIEW: " + preview.Message, "#FFC857");

        var result = await _brokerOrders.PlaceOrderAsync(request);
        LastRealOrderStatus = result.Message;
        LastRealOrderStatusBrush = result.Success ? "#19C37D" : "#FF4D4D";
        AddAlert("REAL ORDER: " + result.Message, result.Success ? "#19C37D" : "#FF4D4D");
    }

    private async Task SetTimeframeAsync(object? parameter)
    {
        string? tf = parameter?.ToString();
        if (string.IsNullOrWhiteSpace(tf)) return;
        Resolution = tf;
        AddAlert($"Timeframe changed to {TimeframeLabel}", "#2DD4FF");
        if (_history != null && _chain != null)
            await RefreshAsync();
    }

    private async Task LoginAsync(object? _)
    {
        _api.AccessToken = await _auth.ExchangeAuthCodeAsync(_api.RawHttpClient, AppId, AppSecret, AuthCode);
        _history = new FyersHistoryService(_api); _chain = new FyersOptionChainService(_api);
        Status = "Logged in. Click Start Live.";
        AddAlert("Login success. Live-only mode enabled.", "#19C37D");
    }
    private async Task RefreshAsync()
    {
        if (_history == null || _chain == null) return;
        try
        {
            var candles = await _history.GetCandlesAsync(Symbol, Resolution, 5); _ind.ApplyAll(candles);
            Candles.Clear(); foreach (var c in candles.TakeLast(120)) Candles.Add(c);
            Trend = _ind.BuildTrend(candles);
            RaiseCandlestickAlertIfNeeded(candles);
            RaiseDemaTemaAlertIfNeeded(candles);
            RaiseAdvancedIndicatorAlertIfNeeded(candles);
            RaiseSmcAlertIfNeeded(candles);
            RaiseOrderBlockAlertIfNeeded(candles);
            RaiseSuperTrendAlertIfNeeded(candles);
            var rows = await _chain.GetRowsAsync(Symbol, StrikeCount);
            OptionRows.Clear(); foreach (var r in rows) OptionRows.Add(r);
            UpdateBuildTabs(rows);
            Spot = _chain.CurrentSpot; Expiry = _chain.CurrentExpiry;
            Score = _smart.Build(Trend, rows, Spot);
            _paper.IsEnabled = EnablePaperTrading;
            _paper.Quantity = PaperQuantity;
            string beforeAction = PaperSummary.LastAction;
            _paper.ProcessSignal(Symbol, Spot, Score);
            OnPropertyChanged(nameof(PaperSummary));
            if (beforeAction != PaperSummary.LastAction)
                AddAlert("PAPER: " + PaperSummary.LastAction, PaperSummary.NetPnl >= 0 ? "#19C37D" : "#FF4D4D");
            await EvaluateAutomaticTradingAsync();
            AddAlert($"{Score.Signal} | Score {Score.FinalScore} | {Score.Reason}", Score.Signal.StartsWith("BUY") ? "#19C37D" : Score.Signal.StartsWith("SELL") ? "#FF4D4D" : "#FFC857");
            TradingStatus = $"{SelectedTradingMode} | {Score.Signal} | Score {Score.FinalScore} | Spot {Spot:0.00} | TF {TimeframeLabel} | {DateTime.Now:HH:mm:ss}";
            if (SelectedTradingMode == "Real Trading") TradingStatus += EnableRealTrade ? (RealTradingConfirmed ? $" | RealToggle ON | Confirmed | BrokerConnected {BrokerOrderServiceConnected}" : " | RealToggle ON | Awaiting Confirmation") : " | RealToggle OFF";
            if (SelectedTradingMode == "Paper Trading") TradingStatus += EnableAutoPaperTrade ? " | AutoPaper ON" : " | AutoPaper OFF";
            TradingStatusBrush = Score.Signal.StartsWith("BUY") ? "#19C37D" : Score.Signal.StartsWith("SELL") ? "#FF4D4D" : "#FFC857";
            Status = "LIVE " + DateTime.Now.ToString("HH:mm:ss");
        }
        catch (Exception ex) { Status = "Error"; AddAlert(ex.Message, "#FF4D4D"); }
    }

    private void RaiseCandlestickAlertIfNeeded(List<Candle> candles)
    {
        var last = candles.LastOrDefault();
        if (last == null) return;
        if (string.IsNullOrWhiteSpace(last.CandlestickPattern) || last.CandlestickPattern == "-") return;

        string key = $"{last.Time:yyyyMMddHHmm}_{last.CandlestickPattern}";
        if (key == _lastCandlestickAlertKey) return;

        _lastCandlestickAlertKey = key;
        string brush = last.CandlestickBias == "Bullish" ? "#19C37D" : last.CandlestickBias == "Bearish" ? "#FF4D4D" : "#FFC857";
        AddAlert($"CANDLE: {last.CandlestickPattern} | {last.CandlestickBias} | TF {TimeframeLabel} | {last.Time:HH:mm}", brush);
    }

    private void RaiseDemaTemaAlertIfNeeded(List<Candle> candles)
    {
        var last = candles.LastOrDefault();
        if (last == null) return;
        if (string.IsNullOrWhiteSpace(last.DemaTemaSignal) || last.DemaTemaSignal == "Equal") return;

        string key = $"{last.Time:yyyyMMddHHmm}_{last.DemaTemaSignal}";
        if (key == _lastDemaTemaAlertKey) return;

        _lastDemaTemaAlertKey = key;
        string brush = last.DemaTemaSignal.StartsWith("DEMA") ? "#19C37D" : "#FF4D4D";
        AddAlert($"DEMA/TEMA: {last.DemaTemaSignal} | TF {TimeframeLabel} | DEMA {last.Dema20:0.00} | TEMA {last.Tema20:0.00}", brush);
    }


    private void RaiseAdvancedIndicatorAlertIfNeeded(List<Candle> candles)
    {
        var last = candles.LastOrDefault();
        if (last == null) return;

        string key = $"{last.Time:yyyyMMddHHmm}_{last.TtmSqueezeStatus}_{last.VortexSignal}_{last.PsarSignal}_{last.AroonSignal}_{last.CamarillaZone}";
        if (key == _lastAdvancedIndicatorAlertKey) return;

        _lastAdvancedIndicatorAlertKey = key;
        string brush = last.PsarSignal == "Bullish" && last.VortexSignal == "Bullish" ? "#19C37D" :
                       last.PsarSignal == "Bearish" && last.VortexSignal == "Bearish" ? "#FF4D4D" : "#FFC857";
        AddAlert($"ADV: TTM {last.TtmSqueezeStatus} | Vortex {last.VortexSignal} | PSAR {last.PsarSignal} | Aroon {last.AroonSignal} | {last.CamarillaZone}", brush);
    }

    private void RaiseSmcAlertIfNeeded(List<Candle> candles)
    {
        var last = candles.LastOrDefault();
        if (last == null) return;
        if (string.IsNullOrWhiteSpace(last.SmartMoneyStructureSignal) || last.SmartMoneyStructureSignal == "Neutral") return;

        string key = $"{last.Time:yyyyMMddHHmm}_{last.BosSignal}_{last.LiquiditySignal}_{last.OrderBlockSignal}_{last.FvgSignal}_{last.SmartMoneyStructureSignal}";
        if (key == _lastSmcAlertKey) return;

        _lastSmcAlertKey = key;
        string brush = last.SmartMoneyStructureSignal.Contains("Buy") ? "#19C37D" : "#FF4D4D";
        AddAlert($"SMC: {last.SmartMoneyStructureSignal} | BOS {last.BosSignal} | Liq {last.LiquiditySignal} | OB {last.OrderBlockSignal} | FVG {last.FvgSignal} | TF {TimeframeLabel}", brush);
    }

    private void RaiseOrderBlockAlertIfNeeded(List<Candle> candles)
    {
        var last = candles.LastOrDefault();
        if (last == null) return;
        if (string.IsNullOrWhiteSpace(last.OrderBlockSignal) || last.OrderBlockSignal == "None") return;

        string key = $"{last.Time:yyyyMMddHHmm}_{last.OrderBlockSignal}_{last.OrderBlockHigh:0.00}_{last.OrderBlockLow:0.00}";
        if (key == _lastOrderBlockAlertKey) return;

        _lastOrderBlockAlertKey = key;
        string brush = last.OrderBlockSignal == "Bullish OB" ? "#19C37D" : "#FF4D4D";
        AddAlert($"OB: {last.OrderBlockSignal} | Zone {last.OrderBlockLow:0.00}-{last.OrderBlockHigh:0.00} | TF {TimeframeLabel}", brush);
    }

    private void RaiseSuperTrendAlertIfNeeded(List<Candle> candles)
    {
        var last = candles.LastOrDefault();
        if (last == null) return;

        string signal = last.SuperTrendBullish ? "Buy" : "Sell";
        string key = $"{last.Time:yyyyMMddHHmm}_{signal}_{TimeframeLabel}";
        if (key == _lastSuperTrendAlertKey) return;

        _lastSuperTrendAlertKey = key;
        string brush = last.SuperTrendBullish ? "#19C37D" : "#FF4D4D";
        AddAlert($"SuperTrend: {signal} | Score {(last.SuperTrendBullish ? 80 : 25)} | TF {TimeframeLabel} | ST {last.SuperTrend:0.00}", brush);
    }

    private void UpdateBuildTabs(List<OptionChainRow> rows)
    {
        LongBuildRows.Clear();
        ShortBuildRows.Clear();
        LongUnwindRows.Clear();
        ShortCoverRows.Clear();

        foreach (var row in rows)
        {
            if (row.CE?.Signal == "Long Build" || row.PE?.Signal == "Long Build") LongBuildRows.Add(row);
            if (row.CE?.Signal == "Short Build" || row.PE?.Signal == "Short Build") ShortBuildRows.Add(row);
            if (row.CE?.Signal == "Long Unwind" || row.PE?.Signal == "Long Unwind") LongUnwindRows.Add(row);
            if (row.CE?.Signal == "Short Cover" || row.PE?.Signal == "Short Cover") ShortCoverRows.Add(row);
        }
    }

    private void AddAlert(string text, string brush)
    {
        Alerts.Insert(0, new AlertMessage { Text = text, Brush = brush });
        while (Alerts.Count > 50) Alerts.RemoveAt(Alerts.Count - 1);
    }
    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? n = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
}
