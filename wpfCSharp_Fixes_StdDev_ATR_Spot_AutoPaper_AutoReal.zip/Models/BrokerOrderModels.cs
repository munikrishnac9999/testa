namespace wpfCSharp_LiveOnly_WPF.Models;

public sealed class BrokerOrderRequest
{
    public string Symbol { get; set; } = string.Empty;
    public string Side { get; set; } = "BUY";
    public string OrderType { get; set; } = "MARKET";
    public string ProductType { get; set; } = "INTRADAY";
    public int Quantity { get; set; }
    public decimal Price { get; set; }
    public string StrategyName { get; set; } = string.Empty;
    public int FinalScore { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.Now;
}

public sealed class BrokerOrderResult
{
    public bool Success { get; set; }
    public string OrderId { get; set; } = string.Empty;
    public string Status { get; set; } = "Blocked";
    public string Message { get; set; } = string.Empty;
    public DateTime Time { get; set; } = DateTime.Now;
}

public sealed class RiskLimits
{
    public bool EnableRealTrade { get; set; }
    public bool EnableAutoRealTrade { get; set; }
    public bool RealTradingConfirmed { get; set; }
    public int MinimumBuyScore { get; set; } = 75;
    public int MinimumSellScore { get; set; } = 35;
    public int MaximumQuantity { get; set; } = 50;
    public int MaxTradesPerDay { get; set; } = 5;
    public decimal MaxDailyLoss { get; set; } = 2000;
    public decimal DailyPnl { get; set; }
    public int TradesTakenToday { get; set; }
}

public sealed class TrackedOrder
{
    public string OrderId { get; set; } = string.Empty;
    public DateTime Time { get; set; } = DateTime.Now;
    public string Symbol { get; set; } = string.Empty;
    public string Side { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public decimal Price { get; set; }
    public string Status { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public string StrategyName { get; set; } = string.Empty;
    public int FinalScore { get; set; }
}
