// Add these members to MainViewModel.cs and call EvaluateAutoPaperTradingAsync/EvaluateAutoRealTradingAsync after Score refresh.

public string LogFilePath => AppLogger.GetLogPath();

private int _paperBuyThreshold = 75;
public int PaperBuyThreshold { get => _paperBuyThreshold; set { _paperBuyThreshold = Math.Clamp(value, 1, 100); OnPropertyChanged(); } }

private int _paperSellThreshold = 35;
public int PaperSellThreshold { get => _paperSellThreshold; set { _paperSellThreshold = Math.Clamp(value, 0, 99); OnPropertyChanged(); } }

private decimal _paperTradeQuantity = 1;
public decimal PaperTradeQuantity { get => _paperTradeQuantity; set { _paperTradeQuantity = value <= 0 ? 1 : value; OnPropertyChanged(); } }

private string _paperTradeStatus = "Auto paper waiting.";
public string PaperTradeStatus { get => _paperTradeStatus; set { _paperTradeStatus = value; OnPropertyChanged(); } }

public ObservableCollection<TrackedOrder> RealOrderHistory { get; } = new();
private readonly IBrokerOrderService _brokerOrderService = new DisabledBrokerOrderService();
private readonly RiskManagerService _riskManager = new();
private readonly OrderTrackingService _orderTracker = new();

private async Task EvaluateAutoPaperTradingAsync()
{
    AppLogger.Info($"Paper check: Enabled={EnableAutoPaperTrade}, Score={Score?.FinalScore}, Signal={Score?.Signal}, Spot={Spot}, BuyTH={PaperBuyThreshold}, SellTH={PaperSellThreshold}, Qty={PaperTradeQuantity}");
    if (!EnableAutoPaperTrade) { PaperTradeStatus = "Auto paper OFF."; return; }
    if (Score == null) { PaperTradeStatus = "Score null."; return; }
    if (Spot <= 0) { PaperTradeStatus = "Spot is zero."; return; }

    _paper.IsEnabled = EnableAutoPaperTrade;
    _paper.Quantity = PaperTradeQuantity;
    _paper.BuyThreshold = PaperBuyThreshold;   // Add this property in PaperTradingService
    _paper.SellThreshold = PaperSellThreshold; // Add this property in PaperTradingService

    string before = PaperSummary.LastAction;
    _paper.ProcessSignal(Symbol, Spot, Score);

    if (before != PaperSummary.LastAction)
    {
        PaperTradeStatus = "PAPER: " + PaperSummary.LastAction;
        AppLogger.Info(PaperTradeStatus);
        AddAlert(PaperTradeStatus, PaperSummary.NetPnl >= 0 ? "#19C37D" : "#FF4D4D");
    }
    OnPropertyChanged(nameof(PaperSummary));
    OnPropertyChanged(nameof(PaperTrades));
}

private async Task EvaluateAutoRealTradingAsync()
{
    AppLogger.Info($"Real check: Mode={SelectedTradingMode}, Real={EnableRealTrade}, AutoReal={EnableAutoRealTrade}, Confirmed={RealTradingConfirmed}, Score={Score?.FinalScore}, Spot={Spot}");
    if (SelectedTradingMode != "Real Trading" || !EnableRealTrade || !EnableAutoRealTrade || !RealTradingConfirmed || Score == null || Spot <= 0) return;

    bool buy = Score.FinalScore >= RealTradeBuyThreshold && Score.Signal.Contains("BUY", StringComparison.OrdinalIgnoreCase);
    bool sell = Score.FinalScore <= RealTradeSellThreshold && Score.Signal.Contains("SELL", StringComparison.OrdinalIgnoreCase);
    if (!buy && !sell) return;

    var request = new BrokerOrderRequest
    {
        Symbol = Symbol,
        Side = buy ? "BUY" : "SELL",
        Quantity = (int)RealTradeQuantity,
        Price = Spot,
        StrategyName = Score.StrategyName,
        FinalScore = Score.FinalScore,
        ProductType = "INTRADAY",
        OrderType = "MARKET"
    };

    var limits = new RiskLimits
    {
        EnableRealTrade = EnableRealTrade,
        EnableAutoRealTrade = EnableAutoRealTrade,
        RealTradingConfirmed = RealTradingConfirmed,
        MinimumBuyScore = RealTradeBuyThreshold,
        MinimumSellScore = RealTradeSellThreshold,
        MaximumQuantity = 100,
        MaxTradesPerDay = 5,
        MaxDailyLoss = 2000
    };

    var risk = _riskManager.Validate(request, limits);
    if (!risk.Success) { LastRealOrderStatus = risk.Message; return; }

    var preview = await _brokerOrderService.PreviewOrderAsync(request);
    _orderTracker.Add(request, preview);
    RealOrderHistory.Clear();
    foreach (var order in _orderTracker.Orders) RealOrderHistory.Add(order);
    LastRealOrderStatus = preview.Message;
}

// Refresh integration after Score = _smart.Build(...):
// Spot = SpotResolverPatch.ResolveSpot(_chain.CurrentSpot, Candles.ToList());
// Trend.StdDev20 = IndicatorExtraCalculations.CalculateStdDev(candles, 20);
// Trend.Atr14 = IndicatorExtraCalculations.CalculateAtr(candles, 14);
// await EvaluateAutoPaperTradingAsync();
// await EvaluateAutoRealTradingAsync();
