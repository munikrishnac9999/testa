using System.Collections.ObjectModel;
using wpfCSharp_LiveOnly_WPF.Models;

namespace wpfCSharp_LiveOnly_WPF.Services;

public interface IBrokerOrderService
{
    Task<BrokerOrderResult> PreviewOrderAsync(BrokerOrderRequest request);
    Task<BrokerOrderResult> PlaceOrderAsync(BrokerOrderRequest request);
}

public sealed class DisabledBrokerOrderService : IBrokerOrderService
{
    public Task<BrokerOrderResult> PreviewOrderAsync(BrokerOrderRequest request)
    {
        AppLogger.Info("Broker preview requested.");
        AppLogger.Json("Broker preview request", request);
        return Task.FromResult(new BrokerOrderResult
        {
            Success = true,
            Status = "Preview",
            Message = $"Preview: {request.Side} {request.Symbol}, Qty {request.Quantity}, Price {request.Price:0.00}, Score {request.FinalScore}"
        });
    }

    public Task<BrokerOrderResult> PlaceOrderAsync(BrokerOrderRequest request)
    {
        AppLogger.Warn("Real broker order blocked. No order sent.");
        AppLogger.Json("Blocked broker order", request);
        return Task.FromResult(new BrokerOrderResult
        {
            Success = false,
            Status = "Blocked",
            Message = "Real broker order execution is disabled. No order was sent."
        });
    }
}

public sealed class RiskManagerService
{
    public BrokerOrderResult Validate(BrokerOrderRequest request, RiskLimits limits)
    {
        AppLogger.Info("Risk validation started.");
        AppLogger.Json("Risk request", request);
        AppLogger.Json("Risk limits", limits);

        if (!limits.EnableRealTrade) return Block("Enable Real Trade is OFF.");
        if (!limits.EnableAutoRealTrade) return Block("Enable Auto Real Trade is OFF.");
        if (!limits.RealTradingConfirmed) return Block("Real Trading confirmation is not accepted.");
        if (request.Quantity <= 0) return Block("Quantity must be greater than zero.");
        if (request.Quantity > limits.MaximumQuantity) return Block($"Quantity {request.Quantity} exceeds max quantity {limits.MaximumQuantity}.");
        if (limits.TradesTakenToday >= limits.MaxTradesPerDay) return Block("Maximum trades per day reached.");
        if (limits.DailyPnl <= -Math.Abs(limits.MaxDailyLoss)) return Block("Daily loss limit reached.");
        if (request.Side == "BUY" && request.FinalScore < limits.MinimumBuyScore) return Block($"BUY score {request.FinalScore} below threshold {limits.MinimumBuyScore}.");
        if (request.Side == "SELL" && request.FinalScore > limits.MinimumSellScore) return Block($"SELL score {request.FinalScore} above sell threshold {limits.MinimumSellScore}.");

        AppLogger.Info("Risk validation passed.");
        return new BrokerOrderResult { Success = true, Status = "Risk Passed", Message = "Risk checks passed." };
    }

    private BrokerOrderResult Block(string reason)
    {
        AppLogger.Warn("Risk blocked: " + reason);
        return new BrokerOrderResult { Success = false, Status = "Blocked", Message = reason };
    }
}

public sealed class OrderTrackingService
{
    public ObservableCollection<TrackedOrder> Orders { get; } = new();

    public void Add(BrokerOrderRequest request, BrokerOrderResult result)
    {
        AppLogger.Info($"Order tracking: {result.Status} {request.Side} {request.Symbol}");
        Orders.Insert(0, new TrackedOrder
        {
            OrderId = result.OrderId,
            Time = result.Time,
            Symbol = request.Symbol,
            Side = request.Side,
            Quantity = request.Quantity,
            Price = request.Price,
            Status = result.Status,
            Message = result.Message,
            StrategyName = request.StrategyName,
            FinalScore = request.FinalScore
        });
    }
}

public static class FyersOrderMapper
{
    public static object ToFyersPayload(BrokerOrderRequest request)
    {
        int side = request.Side.Equals("BUY", StringComparison.OrdinalIgnoreCase) ? 1 : -1;
        int orderType = request.OrderType.Equals("MARKET", StringComparison.OrdinalIgnoreCase) ? 2 : 1;
        return new
        {
            symbol = request.Symbol,
            qty = request.Quantity,
            type = orderType,
            side,
            productType = request.ProductType,
            limitPrice = request.OrderType.Equals("LIMIT", StringComparison.OrdinalIgnoreCase) ? request.Price : 0,
            stopPrice = 0,
            validity = "DAY",
            disclosedQty = 0,
            offlineOrder = false
        };
    }
}

public sealed class FyersBrokerOrderService : IBrokerOrderService
{
    private readonly FyersApiClient _api;
    public FyersBrokerOrderService(FyersApiClient api) => _api = api;

    public Task<BrokerOrderResult> PreviewOrderAsync(BrokerOrderRequest request)
    {
        AppLogger.Info("FYERS preview requested.");
        AppLogger.Json("FYERS payload preview", FyersOrderMapper.ToFyersPayload(request));
        return Task.FromResult(new BrokerOrderResult
        {
            Success = true,
            Status = "Preview",
            Message = $"FYERS preview ready: {request.Side} {request.Symbol}, Qty {request.Quantity}."
        });
    }

    public Task<BrokerOrderResult> PlaceOrderAsync(BrokerOrderRequest request)
    {
        AppLogger.Warn("FYERS live order send blocked in scaffold.");
        AppLogger.Json("FYERS blocked payload", FyersOrderMapper.ToFyersPayload(request));
        return Task.FromResult(new BrokerOrderResult
        {
            Success = false,
            Status = "Blocked",
            Message = "FYERS broker scaffold present, but live order send is disabled."
        });
    }
}
