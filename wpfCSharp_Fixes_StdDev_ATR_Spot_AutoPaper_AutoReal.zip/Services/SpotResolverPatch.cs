using Newtonsoft.Json.Linq;
using wpfCSharp_LiveOnly_WPF.Models;

namespace wpfCSharp_LiveOnly_WPF.Services;

public static class SpotResolverPatch
{
    public static decimal ResolveSpot(decimal chainSpot, IReadOnlyCollection<Candle> candles)
    {
        if (chainSpot > 0) return chainSpot;
        decimal lastClose = candles?.LastOrDefault()?.Close ?? 0;
        if (lastClose > 0) return lastClose;
        return 0;
    }

    // Add this inside FyersOptionChainService.cs if CurrentSpot is still showing 0.
    public static decimal ExtractSpotFromOptionChainResponse(JObject root, string symbol)
    {
        JToken? data = root["data"];
        decimal spot = GetDec(data, "underlyingValue", "underlying_value", "underlying_price", "underlyingPrice", "spot", "spot_price", "spotPrice", "ltp", "lp");
        if (spot > 0) return spot;

        spot = GetDec(data?["underlying"], "ltp", "lp", "last_price", "lastPrice", "spot", "spotPrice");
        if (spot > 0) return spot;

        JArray chain = data?["optionsChain"] as JArray ?? data?["options_chain"] as JArray ?? new JArray();
        foreach (JToken item in chain)
        {
            string itemSymbol = GetStr(item, "symbol", "n");
            if (!string.IsNullOrWhiteSpace(itemSymbol) && itemSymbol.Equals(symbol, StringComparison.OrdinalIgnoreCase))
            {
                spot = GetDec(item, "ltp", "lp", "last_price", "lastPrice", "spot");
                if (spot > 0) return spot;
            }

            spot = GetDec(item, "underlyingValue", "underlying_price", "underlyingPrice", "spot", "spotPrice");
            if (spot > 0) return spot;
        }

        return 0;
    }

    private static decimal GetDec(JToken? t, params string[] names)
    {
        if (t == null) return 0;
        foreach (string n in names)
            if (decimal.TryParse(t[n]?.ToString(), out var d)) return d;
        return 0;
    }

    private static string GetStr(JToken? t, params string[] names)
    {
        if (t == null) return string.Empty;
        foreach (string n in names)
        {
            string? v = t[n]?.ToString();
            if (!string.IsNullOrWhiteSpace(v)) return v;
        }
        return string.Empty;
    }
}
