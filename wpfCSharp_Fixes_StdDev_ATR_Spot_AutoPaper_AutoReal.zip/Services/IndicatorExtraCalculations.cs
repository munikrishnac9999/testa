using wpfCSharp_LiveOnly_WPF.Models;

namespace wpfCSharp_LiveOnly_WPF.Services;

public static class IndicatorExtraCalculations
{
    public static decimal CalculateStdDev(List<Candle> candles, int period = 20)
    {
        if (candles == null || candles.Count < period) return 0;
        var closes = candles.TakeLast(period).Select(x => x.Close).ToList();
        decimal avg = closes.Average();
        decimal variance = closes.Average(x => (x - avg) * (x - avg));
        return Math.Round((decimal)Math.Sqrt((double)variance), 2);
    }

    public static decimal CalculateAtr(List<Candle> candles, int period = 14)
    {
        if (candles == null || candles.Count < period + 1) return 0;
        List<decimal> trueRanges = new();
        for (int i = 1; i < candles.Count; i++)
        {
            decimal highLow = candles[i].High - candles[i].Low;
            decimal highPrevClose = Math.Abs(candles[i].High - candles[i - 1].Close);
            decimal lowPrevClose = Math.Abs(candles[i].Low - candles[i - 1].Close);
            trueRanges.Add(Math.Max(highLow, Math.Max(highPrevClose, lowPrevClose)));
        }
        return Math.Round(trueRanges.TakeLast(period).Average(), 2);
    }
}
