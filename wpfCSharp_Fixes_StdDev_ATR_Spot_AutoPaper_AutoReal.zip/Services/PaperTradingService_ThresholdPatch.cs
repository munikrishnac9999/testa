// Add these properties into PaperTradingService.cs
public int BuyThreshold { get; set; } = 75;
public int SellThreshold { get; set; } = 35;

// In ProcessSignal(...), replace hardcoded 75/35 with:
// string signal = score.Signal?.Trim().ToUpperInvariant() ?? string.Empty;
// bool buySignal = score.FinalScore >= BuyThreshold && (signal.Contains("BUY") || signal.Contains("BULLISH"));
// bool sellSignal = score.FinalScore <= SellThreshold && (signal.Contains("SELL") || signal.Contains("BEARISH"));
