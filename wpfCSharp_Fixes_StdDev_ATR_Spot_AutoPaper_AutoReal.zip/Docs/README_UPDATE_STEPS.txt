This update patch includes:
1. StdDev and ATR calculation helpers.
2. Spot fallback resolver.
3. Auto paper trading using frontend thresholds, not hardcoded values.
4. Auto real trading guarded workflow.
5. AppLogger and logs for paper, real, risk, broker preview and order tracking.
6. Settings page ScrollViewer XAML snippet.
7. Broker service scaffold and FYERS payload mapper.

Main integration points:
- Copy Models/*.cs to Models.
- Copy Services/*.cs to Services.
- Add ViewModels/MainViewModel_UpdateSnippet.cs members/methods into MainViewModel.cs.
- Add BuyThreshold and SellThreshold to PaperTradingService.cs.
- Replace hardcoded 75/35 in PaperTradingService.ProcessSignal with BuyThreshold/SellThreshold.
- After Score = _smart.Build(...), call:
    Spot = SpotResolverPatch.ResolveSpot(_chain.CurrentSpot, Candles.ToList());
    Trend.StdDev20 = IndicatorExtraCalculations.CalculateStdDev(candles, 20);
    Trend.Atr14 = IndicatorExtraCalculations.CalculateAtr(candles, 14);
    await EvaluateAutoPaperTradingAsync();
    await EvaluateAutoRealTradingAsync();
- Replace Settings tab or wrap existing Settings with XamlSnippets/Settings_Trading_WithScroll_ATR_StdDev.xaml.
