namespace wpfCSharp_LiveOnly_WPF.Models;


public sealed class CandlePatternPrediction
{
    public string CurrentPattern { get; set; } = "-";
    public string CurrentBias { get; set; } = "Neutral";
    public string NextCandleBias { get; set; } = "WAIT";
    public string SuggestedAction { get; set; } = "Wait for next candle confirmation";
    public int Confidence { get; set; }
    public decimal ExpectedOpen { get; set; }
    public decimal ExpectedHigh { get; set; }
    public decimal ExpectedLow { get; set; }
    public decimal ExpectedClose { get; set; }
    public decimal BreakoutAbove { get; set; }
    public decimal BreakdownBelow { get; set; }
    public string Reason { get; set; } = "Run live chart to detect latest candle pattern.";
    public string Brush { get; set; } = "#FFC857";
    public string PatternBrush { get; set; } = "#93A4BD";
}

public sealed class SupportResistanceLevels
{
    public string Name { get; set; } = string.Empty;
    public DateTime From { get; set; }
    public DateTime To { get; set; }
    public decimal Pivot { get; set; }
    public decimal R1 { get; set; }
    public decimal R2 { get; set; }
    public decimal R3 { get; set; }
    public decimal S1 { get; set; }
    public decimal S2 { get; set; }
    public decimal S3 { get; set; }
    public string RangeText => From == DateTime.MinValue ? "-" : $"{From:dd-MMM} to {To:dd-MMM}";
    public string PivotBrush => "#2DD4FF";
    public string ResistanceBrush => "#FF4D4D";
    public string SupportBrush => "#19C37D";
}

public sealed class ChartPriceLevel
{
    public string Label { get; set; } = string.Empty;
    public decimal Value { get; set; }
    public string Brush { get; set; } = "#93A4BD";
    public bool IsResistance { get; set; }
}

public sealed class TrendSnapshot
{
    public decimal Ema20 { get; set; }
    public decimal Ema50 { get; set; }
    public decimal Ema200 { get; set; }
    public decimal Hma20 { get; set; }
    public string HmaBrush { get; set; } = "#93A4BD";
    public decimal StochRsi { get; set; }
    public string StochRsiBrush { get; set; } = "#93A4BD";
    public decimal WilliamsR { get; set; }
    public decimal Pvt { get; set; }
    public decimal InstitutionalFlow { get; set; }
    public decimal SwingHigh { get; set; }
    public decimal SwingLow { get; set; }
    public bool HigherHigh { get; set; }
    public bool HigherLow { get; set; }
    public bool LowerHigh { get; set; }
    public bool LowerLow { get; set; }

    public string EmaTrend { get; set; } = "-";
    public string SmaTrend { get; set; } = "-";
    public string VwapStatus { get; set; } = "-";
    public decimal Atr { get; set; }
    public decimal Rsi { get; set; }
    public string MacdStatus { get; set; } = "-";
    public decimal Macd { get; set; }
    public decimal MacdSignal { get; set; }
    public decimal Adx { get; set; }
    public string AdxStatus { get; set; } = "-";
    public string SuperTrend { get; set; } = "-";
    public int SuperTrendScore { get; set; }
    public string BollingerStatus { get; set; } = "-";
    public string DonchianStatus { get; set; } = "-";
    public string KeltnerStatus { get; set; } = "-";
    public decimal Rvol { get; set; }
    public decimal Rvol10 { get; set; }
    public decimal Rvol20 { get; set; }
    public decimal VolumeProfilePoc { get; set; }
    public string TrendBias { get; set; } = "Neutral";
    public string EmaBrush { get; set; } = "#93A4BD";
    public string SmaBrush { get; set; } = "#93A4BD";
    public string VwapBrush { get; set; } = "#93A4BD";
    public string RsiBrush { get; set; } = "#93A4BD";
    public string MacdBrush { get; set; } = "#93A4BD";
    public string AdxBrush { get; set; } = "#93A4BD";
    public string SuperTrendBrush { get; set; } = "#93A4BD";
    public string RvolBrush { get; set; } = "#93A4BD";
    public string Rvol10Brush { get; set; } = "#93A4BD";
    public string Rvol20Brush { get; set; } = "#93A4BD";
    public string BollingerBrush { get; set; } = "#93A4BD";
    public string DonchianBrush { get; set; } = "#93A4BD";
    public string KeltnerBrush { get; set; } = "#93A4BD";

    public decimal Roc { get; set; }
    public decimal Cci { get; set; }
    public decimal Stochastic { get; set; }
    public decimal Mfi { get; set; }
    public decimal Cmf { get; set; }
    public decimal Obv { get; set; }
    public decimal AdLine { get; set; }
    public decimal SmartFlow { get; set; }
    public decimal AbsorptionScore { get; set; }
    public decimal HistoricalVolatility { get; set; }
    public decimal StdDev20 { get; set; }
    public decimal Dema20 { get; set; }
    public decimal Tema20 { get; set; }
    public string DemaTemaSignal { get; set; } = "Neutral";
    public decimal Vwma20 { get; set; }
    public string TtmSqueezeStatus { get; set; } = "-";
    public decimal VortexPlus { get; set; }
    public decimal VortexMinus { get; set; }
    public string VortexSignal { get; set; } = "Neutral";
    public decimal ChandelierLong { get; set; }
    public decimal ChandelierShort { get; set; }
    public string ChandelierSignal { get; set; } = "Neutral";
    public decimal ElderBullPower { get; set; }
    public decimal ElderBearPower { get; set; }
    public string ElderRaySignal { get; set; } = "Neutral";
    public decimal Tema3 { get; set; }
    public string Tema3VsTema20Signal { get; set; } = "Neutral";
    public string PriceVsEma3Signal { get; set; } = "Neutral";
    public string CamarillaZone { get; set; } = "-";
    public decimal AroonUp { get; set; }
    public decimal AroonDown { get; set; }
    public string AroonSignal { get; set; } = "Neutral";
    public decimal Psar { get; set; }
    public string PsarSignal { get; set; } = "Neutral";
    public string BosSignal { get; set; } = "Neutral";
    public string LiquiditySignal { get; set; } = "None";
    public string OrderFlowSignal { get; set; } = "Neutral Flow";
    public string OrderBlockSignal { get; set; } = "None";
    public decimal OrderBlockHigh { get; set; }
    public decimal OrderBlockLow { get; set; }
    public string FvgSignal { get; set; } = "None";
    public decimal FvgHigh { get; set; }
    public decimal FvgLow { get; set; }
    public string FvgZone { get; set; } = "-";
    public string SmartMoneyStructureSignal { get; set; } = "Neutral";
    public int SmartMoneyStructureScore { get; set; }

    public string RocBrush { get; set; } = "#93A4BD";
    public string CciBrush { get; set; } = "#93A4BD";
    public string StochasticBrush { get; set; } = "#93A4BD";
    public string MfiBrush { get; set; } = "#93A4BD";
    public string CmfBrush { get; set; } = "#93A4BD";
    public string ObvBrush { get; set; } = "#93A4BD";
    public string AdLineBrush { get; set; } = "#93A4BD";
    public string SmartFlowBrush { get; set; } = "#93A4BD";
    public string AbsorptionBrush { get; set; } = "#93A4BD";
    public string HistoricalVolatilityBrush { get; set; } = "#93A4BD";
    public string StdDevBrush { get; set; } = "#93A4BD";
    public string DemaBrush { get; set; } = "#93A4BD";
    public string TemaBrush { get; set; } = "#93A4BD";
    public string DemaTemaBrush { get; set; } = "#93A4BD";
    public string VwmaBrush { get; set; } = "#93A4BD";
    public string TtmSqueezeBrush { get; set; } = "#93A4BD";
    public string VortexBrush { get; set; } = "#93A4BD";
    public string ChandelierBrush { get; set; } = "#93A4BD";
    public string ElderRayBrush { get; set; } = "#93A4BD";
    public string Tema3VsTema20Brush { get; set; } = "#93A4BD";
    public string PriceVsEma3Brush { get; set; } = "#93A4BD";
    public string CamarillaBrush { get; set; } = "#93A4BD";
    public string AroonBrush { get; set; } = "#93A4BD";
    public string PsarBrush { get; set; } = "#93A4BD";
    public string BosBrush { get; set; } = "#93A4BD";
    public string LiquidityBrush { get; set; } = "#93A4BD";
    public string OrderFlowBrush { get; set; } = "#93A4BD";
    public string OrderBlockBrush { get; set; } = "#93A4BD";
    public string FvgBrush { get; set; } = "#93A4BD";
    public string SmartMoneyStructureBrush { get; set; } = "#93A4BD";

    public string CandlestickPattern { get; set; } = "-";
    public string CandlestickBias { get; set; } = "Neutral";
    public string CandlestickBrush { get; set; } = "#93A4BD";
}
public sealed class SmartMoneySnapshot
{
    public int TrendScore { get; set; }
    public int OiScore { get; set; }
    public int VolumeScore { get; set; }
    public int IvScore { get; set; }
    public int MomentumScore { get; set; }
    public int MoneyFlowScore { get; set; }
    public int SmcScore { get; set; }
    public int PatternScore { get; set; }
    public decimal CeUnwindScore { get; set; }
    public decimal PeUnwindScore { get; set; }
    public int FinalScore { get; set; }
    public string Bias { get; set; } = "Neutral";
    public string Signal { get; set; } = "WAIT";
    public decimal StopLoss { get; set; }
    public decimal Target1 { get; set; }
    public decimal Target2 { get; set; }
    public string StrategyName { get; set; } = "No Strategy";
    public decimal Support { get; set; }
    public decimal Resistance { get; set; }
    public decimal PcrOi { get; set; }
    public decimal PcrVolume { get; set; }
    public decimal AverageIv { get; set; }
    public int BuyScore { get; set; }
    public int SellScore { get; set; }

    public decimal MaxPain { get; set; }
    public decimal CeBuildScore { get; set; }
    public decimal PeBuildScore { get; set; }
    public decimal IvRank { get; set; }
    public string PcrBrush => PcrOi >= 1 ? "#19C37D" : PcrOi > 0 ? "#FF4D4D" : "#93A4BD";
    public string MaxPainBrush => MaxPain > 0 ? "#FFC857" : "#93A4BD";
    public string CeBuildBrush => CeBuildScore > 0 ? "#FF4D4D" : "#93A4BD";
    public string PeBuildBrush => PeBuildScore > 0 ? "#19C37D" : "#93A4BD";
    public string IvRankBrush => IvRank >= 25 ? "#FF4D4D" : IvRank >= 15 ? "#FFC857" : "#93A4BD";
    public string Reason { get; set; } = string.Empty;
    public string SignalBrush => Signal.StartsWith("BUY") ? "#19C37D" : Signal.StartsWith("SELL") ? "#FF4D4D" : "#FFC857";
}
public sealed class SignalPopupInfo
{
    public string Title { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public string Brush { get; set; } = "#FFC857";
}

public sealed class AlertMessage
{
    public DateTime Time { get; set; } = DateTime.Now;
    public string Text { get; set; } = string.Empty;
    public string Brush { get; set; } = "#E7EEFB";
}

public sealed class StrategyThresholdSettings
{
    public int FinalBuyThreshold { get; set; } = 75;
    public int FinalSellThreshold { get; set; } = 35;
    public int TrendBuyThreshold { get; set; } = 65;
    public int TrendSellThreshold { get; set; } = 35;
    public int MomentumBuyThreshold { get; set; } = 65;
    public int MomentumSellThreshold { get; set; } = 35;
    public int MoneyFlowBuyThreshold { get; set; } = 65;
    public int MoneyFlowSellThreshold { get; set; } = 35;
    public int OptionBuyThreshold { get; set; } = 65;
    public int OptionSellThreshold { get; set; } = 35;
    public int SmcBuyThreshold { get; set; } = 65;
    public int SmcSellThreshold { get; set; } = 35;
    public int PatternBuyThreshold { get; set; } = 65;
    public int PatternSellThreshold { get; set; } = 35;
    public int MinBuyConfirmations { get; set; } = 4;
    public int MinSellConfirmations { get; set; } = 4;
}
