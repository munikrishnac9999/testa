# MOLA Professional Engine

WPF .NET 8 live-only FYERS strategy engine with dashboard indicators, option chain, stock scanner, MOLA Studio, MOLA Query, Telegram alerts, Excel/CSV export, frontend thresholds, and option paper trading.

## Build

```bash
dotnet restore
dotnet build
```

## Notes

- Real broker order placement is intentionally blocked by `RealOrderDisabledService`.
- `StocksWatchlist.json` is copied to output and used by the stock scanner.
- MOLA Query uses the existing internal `MOLA...` class/property names for compatibility, while visible UI labels are renamed to MOLA.


## Option Signal Popups

When the live strategy score generates a BUY or SELL option signal:

- BUY signal shows a popup to buy ATM CE
- SELL signal shows a popup to buy ATM PE
- Popup includes option symbol, strike, entry rate, Target 1, Target 2, Stop Loss, and risk amount/percent
- Same signal is also inserted into the Alerts tab


## Client Dashboard Update

The project now opens with a client-focused dashboard:

- Market watchlist
- Live strategy snapshot
- Best Trade Now card
- option entry rate, Target 1, Target 2, Stop Loss, Risk and Risk %
- MOLA Studio / MOLA Query visible branding
- option signal popup and Alerts tab integration
