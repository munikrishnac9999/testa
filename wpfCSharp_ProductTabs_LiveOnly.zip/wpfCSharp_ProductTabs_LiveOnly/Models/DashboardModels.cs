namespace wpfCSharp_LiveOnly_WPF.Models;
public sealed class TrendSnapshot
{
    public string EmaTrend { get; set; } = "-";
    public string VwapStatus { get; set; } = "-";
    public decimal Rsi { get; set; }
    public string MacdStatus { get; set; } = "-";
    public decimal Adx { get; set; }
    public string SuperTrend { get; set; } = "-";
    public decimal Rvol { get; set; }
    public string TrendBias { get; set; } = "Neutral";
}
public sealed class SmartMoneySnapshot
{
    public int TrendScore { get; set; }
    public int OiScore { get; set; }
    public int VolumeScore { get; set; }
    public int IvScore { get; set; }
    public int FinalScore { get; set; }
    public string Bias { get; set; } = "Neutral";
    public string Signal { get; set; } = "WAIT";
    public decimal StopLoss { get; set; }
    public decimal Target1 { get; set; }
    public decimal Target2 { get; set; }
    public string Reason { get; set; } = string.Empty;
}
public sealed class AlertMessage
{
    public DateTime Time { get; set; } = DateTime.Now;
    public string Text { get; set; } = string.Empty;
    public string Brush { get; set; } = "#E7EEFB";
}
