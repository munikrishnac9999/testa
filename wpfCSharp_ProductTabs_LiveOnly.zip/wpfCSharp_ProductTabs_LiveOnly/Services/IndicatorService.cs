using wpfCSharp_LiveOnly_WPF.Models;
namespace wpfCSharp_LiveOnly_WPF.Services;
public sealed class IndicatorService
{
    public void ApplyAll(List<Candle> c)
    {
        ApplyEma(c, 20, (x, v) => x.Ema20 = v); ApplyEma(c, 50, (x, v) => x.Ema50 = v); ApplyEma(c, 200, (x, v) => x.Ema200 = v);
        ApplySma(c, 20, (x, v) => x.Sma20 = v); ApplyVwap(c); ApplyAtr(c, 14); ApplyRsi(c, 14); ApplyBands(c, 20); ApplyChannels(c, 20); ApplyRvol(c, 20); ApplySuperTrend(c, 10, 3m);
    }
    private void ApplyEma(List<Candle> c, int p, Action<Candle, decimal> set) { decimal k = 2m / (p + 1); decimal ema = 0; for (int i = 0; i < c.Count; i++) { ema = i == 0 ? c[i].Close : c[i].Close * k + ema * (1 - k); set(c[i], ema); } }
    private void ApplySma(List<Candle> c, int p, Action<Candle, decimal> set) { for (int i = 0; i < c.Count; i++) set(c[i], i + 1 < p ? 0 : c.Skip(i - p + 1).Take(p).Average(x => x.Close)); }
    private void ApplyVwap(List<Candle> c) { decimal pv = 0, vol = 0; DateTime day = DateTime.MinValue; foreach (var x in c) { if (x.Time.Date != day) { day = x.Time.Date; pv = 0; vol = 0; } decimal typical = (x.High + x.Low + x.Close) / 3; pv += typical * x.Volume; vol += x.Volume; x.Vwap = vol > 0 ? pv / vol : 0; } }
    private void ApplyAtr(List<Candle> c, int p) { decimal atr = 0; for (int i = 0; i < c.Count; i++) { decimal prev = i == 0 ? c[i].Close : c[i - 1].Close; decimal tr = Math.Max(c[i].High - c[i].Low, Math.Max(Math.Abs(c[i].High - prev), Math.Abs(c[i].Low - prev))); atr = i == 0 ? tr : ((atr * (p - 1)) + tr) / p; c[i].Atr14 = atr; } }
    private void ApplyRsi(List<Candle> c, int p) { decimal gain = 0, loss = 0; for (int i = 1; i < c.Count; i++) { decimal ch = c[i].Close - c[i - 1].Close; gain = ((gain * (p - 1)) + Math.Max(0, ch)) / p; loss = ((loss * (p - 1)) + Math.Max(0, -ch)) / p; c[i].Rsi14 = loss == 0 ? 100 : 100 - (100 / (1 + gain / loss)); } }
    private void ApplyBands(List<Candle> c, int p) { for (int i = p - 1; i < c.Count; i++) { var list = c.Skip(i - p + 1).Take(p).Select(x => x.Close).ToList(); decimal avg = list.Average(); decimal sd = (decimal)Math.Sqrt(list.Average(v => Math.Pow((double)(v - avg), 2))); c[i].BollUpper = avg + 2 * sd; c[i].BollLower = avg - 2 * sd; } }
    private void ApplyChannels(List<Candle> c, int p) { for (int i = p - 1; i < c.Count; i++) { var list = c.Skip(i - p + 1).Take(p); c[i].DonchianUpper = list.Max(x => x.High); c[i].DonchianLower = list.Min(x => x.Low); c[i].KeltnerUpper = c[i].Ema20 + 2 * c[i].Atr14; c[i].KeltnerLower = c[i].Ema20 - 2 * c[i].Atr14; } }
    private void ApplyRvol(List<Candle> c, int p) { for (int i = p - 1; i < c.Count; i++) { decimal avg = c.Skip(i - p + 1).Take(p).Average(x => x.Volume); c[i].Rvol = avg > 0 ? c[i].Volume / avg : 0; } }
    private void ApplySuperTrend(List<Candle> c, int p, decimal m) { for (int i = 0; i < c.Count; i++) { decimal mid = (c[i].High + c[i].Low) / 2; c[i].SuperTrend = mid - m * c[i].Atr14; c[i].SuperTrendBullish = c[i].Close >= c[i].SuperTrend; } }
    public TrendSnapshot BuildTrend(List<Candle> c)
    {
        var x = c.LastOrDefault(); if (x == null) return new TrendSnapshot();
        bool bullEma = x.Ema20 > x.Ema50 && x.Ema50 > x.Ema200, aboveVwap = x.Close > x.Vwap;
        return new TrendSnapshot { EmaTrend = bullEma ? "Bullish" : "Bearish/Flat", VwapStatus = aboveVwap ? "Above" : "Below", Rsi = x.Rsi14, MacdStatus = x.Ema20 > x.Ema50 ? "Bullish" : "Bearish", Adx = 0, SuperTrend = x.SuperTrendBullish ? "Buy" : "Sell", Rvol = x.Rvol, TrendBias = bullEma && aboveVwap ? "Bullish" : (!aboveVwap ? "Bearish" : "Neutral") };
    }
}
