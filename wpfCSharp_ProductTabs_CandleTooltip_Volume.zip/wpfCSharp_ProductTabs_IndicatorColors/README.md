# wpfCSharp_LiveOnly_WPF

Live-only FYERS WPF dashboard. No mock data is included.

## What is included

- AuthCode -> AccessToken FYERS login flow
- Live History API candles
- Live Option Chain API
- Live Quotes API
- WPF chart engine with candles, EMA20/50/200, VWAP, SuperTrend, volume and RVOL
- Option chain grid with CE/PE signal, IV, OI, OI Change, Volume and Greeks
- Smart Money Score panel
- Buy/Sell bias with SL/Target
- Live alerts panel

## Required before running

1. Install .NET 8 SDK on Windows.
2. Open this folder in Visual Studio.
3. Restore NuGet packages.
4. Enter:
   - FYERS AppId
   - FYERS AppSecret
   - Fresh auth_code from FYERS redirect URL
   - Symbol, for example `NSE:NIFTY50-INDEX`
5. Click Login, then Start Live.

## Important

This app does not generate or simulate market data. If FYERS API permission, token, F&O access, or network access is missing, the app shows an error in the alerts panel.
