using wpfCSharp_LiveOnly_WPF.Models;
namespace wpfCSharp_LiveOnly_WPF.Services;
public sealed class SmartMoneyService
{
    public SmartMoneySnapshot Build(TrendSnapshot t, List<OptionChainRow> rows, decimal spot)
    {
        decimal ceChg = rows.Sum(x => x.CE?.OiChange ?? 0), peChg = rows.Sum(x => x.PE?.OiChange ?? 0);
        int trend = t.TrendBias == "Bullish" ? 80 : t.TrendBias == "Bearish" ? 25 : 50;
        int oi = peChg > ceChg ? 80 : ceChg > peChg ? 25 : 50;
        int vol = t.Rvol >= 1.5m ? 80 : t.Rvol >= 1.1m ? 60 : 45;
        int iv = 60;
        int final = (trend + oi + vol + iv) / 4;
        string signal = final >= 70 ? "BUY Bias" : final <= 35 ? "SELL Bias" : "WAIT";
        decimal atr = rows.Count > 0 ? Math.Max(20, Math.Abs(rows[0].Strike - rows[^1].Strike) / Math.Max(1, rows.Count)) : 50;
        return new SmartMoneySnapshot { TrendScore = trend, OiScore = oi, VolumeScore = vol, IvScore = iv, FinalScore = final, Bias = final >= 70 ? "Bullish" : final <= 35 ? "Bearish" : "Neutral", Signal = signal, StopLoss = signal.StartsWith("BUY") ? spot - atr : spot + atr, Target1 = signal.StartsWith("BUY") ? spot + atr : spot - atr, Target2 = signal.StartsWith("BUY") ? spot + atr * 2 : spot - atr * 2, Reason = $"Trend={t.TrendBias}, PE OIChg={peChg:0}, CE OIChg={ceChg:0}, RVOL={t.Rvol:0.00}" };
    }
}
