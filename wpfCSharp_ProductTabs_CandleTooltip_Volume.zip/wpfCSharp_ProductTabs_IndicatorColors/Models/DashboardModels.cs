namespace wpfCSharp_LiveOnly_WPF.Models;
public sealed class TrendSnapshot
{
    public string EmaTrend { get; set; } = "-";
    public string SmaTrend { get; set; } = "-";
    public string VwapStatus { get; set; } = "-";
    public decimal Atr { get; set; }
    public decimal Rsi { get; set; }
    public string MacdStatus { get; set; } = "-";
    public decimal Macd { get; set; }
    public decimal MacdSignal { get; set; }
    public decimal Adx { get; set; }
    public string AdxStatus { get; set; } = "-";
    public string SuperTrend { get; set; } = "-";
    public string BollingerStatus { get; set; } = "-";
    public string DonchianStatus { get; set; } = "-";
    public string KeltnerStatus { get; set; } = "-";
    public decimal Rvol { get; set; }
    public decimal VolumeProfilePoc { get; set; }
    public string TrendBias { get; set; } = "Neutral";
    public string EmaBrush { get; set; } = "#93A4BD";
    public string SmaBrush { get; set; } = "#93A4BD";
    public string VwapBrush { get; set; } = "#93A4BD";
    public string RsiBrush { get; set; } = "#93A4BD";
    public string MacdBrush { get; set; } = "#93A4BD";
    public string AdxBrush { get; set; } = "#93A4BD";
    public string SuperTrendBrush { get; set; } = "#93A4BD";
    public string RvolBrush { get; set; } = "#93A4BD";
    public string BollingerBrush { get; set; } = "#93A4BD";
    public string DonchianBrush { get; set; } = "#93A4BD";
    public string KeltnerBrush { get; set; } = "#93A4BD";
}
public sealed class SmartMoneySnapshot
{
    public int TrendScore { get; set; }
    public int OiScore { get; set; }
    public int VolumeScore { get; set; }
    public int IvScore { get; set; }
    public int FinalScore { get; set; }
    public string Bias { get; set; } = "Neutral";
    public string Signal { get; set; } = "WAIT";
    public decimal StopLoss { get; set; }
    public decimal Target1 { get; set; }
    public decimal Target2 { get; set; }
    public string Reason { get; set; } = string.Empty;
}
public sealed class AlertMessage
{
    public DateTime Time { get; set; } = DateTime.Now;
    public string Text { get; set; } = string.Empty;
    public string Brush { get; set; } = "#E7EEFB";
}
