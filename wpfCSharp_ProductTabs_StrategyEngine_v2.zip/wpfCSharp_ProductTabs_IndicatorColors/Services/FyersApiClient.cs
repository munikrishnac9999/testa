using Newtonsoft.Json.Linq;
namespace wpfCSharp_LiveOnly_WPF.Services;
public sealed class FyersApiClient
{
    private readonly HttpClient _client = new() { Timeout = TimeSpan.FromSeconds(30) };
    public string AppId { get; set; } = "ED88TMB033-100";
    public string AccessToken { get; set; } = string.Empty;
    public string CompositeToken => $"{AppId}:{AccessToken}";
    public async Task<string> GetAsync(string url)
    {
        if (string.IsNullOrWhiteSpace(AccessToken)) throw new InvalidOperationException("Login first. Access token is empty.");
        using var req = new HttpRequestMessage(HttpMethod.Get, url);
        req.Headers.TryAddWithoutValidation("Authorization", CompositeToken);
        req.Headers.Accept.ParseAdd("application/json");
        using HttpResponseMessage res = await _client.SendAsync(req);
        string body = await res.Content.ReadAsStringAsync();
        if (!res.IsSuccessStatusCode) throw new Exception($"GET failed: {(int)res.StatusCode} {res.ReasonPhrase}\nURL: {url}\n{body}");
        JObject root = JObject.Parse(body);
        if (string.Equals(root["s"]?.ToString(), "error", StringComparison.OrdinalIgnoreCase))
            throw new Exception($"FYERS error. URL: {url}\nCode: {root["code"]}\nMessage: {root["message"]}\n{body}");
        return body;
    }
    public HttpClient RawHttpClient => _client;
}
