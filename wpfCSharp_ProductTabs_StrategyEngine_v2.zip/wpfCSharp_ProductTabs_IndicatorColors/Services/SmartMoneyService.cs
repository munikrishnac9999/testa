using wpfCSharp_LiveOnly_WPF.Models;

namespace wpfCSharp_LiveOnly_WPF.Services;

public sealed class SmartMoneyService
{
    public SmartMoneySnapshot Build(TrendSnapshot t, List<OptionChainRow> rows, decimal spot)
    {
        if (rows.Count == 0 || spot <= 0)
            return new SmartMoneySnapshot { Signal = "WAIT", Bias = "Neutral", Reason = "No live option-chain rows or spot price available." };

        decimal ceOi = rows.Sum(x => x.CE?.Oi ?? 0);
        decimal peOi = rows.Sum(x => x.PE?.Oi ?? 0);
        decimal ceChg = rows.Sum(x => x.CE?.OiChange ?? 0);
        decimal peChg = rows.Sum(x => x.PE?.OiChange ?? 0);
        decimal ceVol = rows.Sum(x => x.CE?.Volume ?? 0);
        decimal peVol = rows.Sum(x => x.PE?.Volume ?? 0);
        decimal avgIv = rows.SelectMany(x => new[] { x.CE?.Iv ?? 0, x.PE?.Iv ?? 0 }).Where(x => x > 0).DefaultIfEmpty(0).Average();

        decimal pcrOi = ceOi > 0 ? peOi / ceOi : 0;
        decimal pcrVol = ceVol > 0 ? peVol / ceVol : 0;

        OptionChainRow? supportRow = rows.Where(x => x.PE != null).OrderByDescending(x => x.PE!.OiChange).FirstOrDefault();
        OptionChainRow? resistanceRow = rows.Where(x => x.CE != null).OrderByDescending(x => x.CE!.OiChange).FirstOrDefault();
        decimal support = supportRow?.Strike ?? 0;
        decimal resistance = resistanceRow?.Strike ?? 0;

        int buyScore = 0;
        int sellScore = 0;
        var buyReasons = new List<string>();
        var sellReasons = new List<string>();

        AddCondition(t.EmaTrend == "Bullish", 12, buyReasons, "EMA trend bullish", ref buyScore);
        AddCondition(t.EmaTrend != "Bullish", 8, sellReasons, "EMA trend bearish/flat", ref sellScore);
        AddCondition(t.VwapStatus == "Above", 12, buyReasons, "Price above VWAP", ref buyScore);
        AddCondition(t.VwapStatus == "Below", 12, sellReasons, "Price below VWAP", ref sellScore);
        AddCondition(t.MacdStatus == "Bullish", 10, buyReasons, "MACD bullish", ref buyScore);
        AddCondition(t.MacdStatus == "Bearish", 10, sellReasons, "MACD bearish", ref sellScore);
        AddCondition(t.SuperTrend == "Buy", 10, buyReasons, "SuperTrend buy", ref buyScore);
        AddCondition(t.SuperTrend == "Sell", 10, sellReasons, "SuperTrend sell", ref sellScore);
        AddCondition(t.Adx >= 20, 6, buyReasons, "ADX trend strength", ref buyScore);
        AddCondition(t.Adx >= 20, 6, sellReasons, "ADX trend strength", ref sellScore);
        AddCondition(t.Rvol >= 1.2m, 6, buyReasons, "Relative volume elevated", ref buyScore);
        AddCondition(t.Rvol >= 1.2m, 6, sellReasons, "Relative volume elevated", ref sellScore);

        AddCondition(peChg > ceChg, 18, buyReasons, "PE OI change stronger than CE", ref buyScore);
        AddCondition(ceChg > peChg, 18, sellReasons, "CE OI change stronger than PE", ref sellScore);
        AddCondition(pcrOi >= 1.05m, 8, buyReasons, $"PCR OI bullish ({pcrOi:0.00})", ref buyScore);
        AddCondition(pcrOi <= 0.95m && pcrOi > 0, 8, sellReasons, $"PCR OI bearish ({pcrOi:0.00})", ref sellScore);
        AddCondition(support > 0 && support <= spot, 6, buyReasons, $"Support below/near spot {support:0}", ref buyScore);
        AddCondition(resistance > 0 && resistance >= spot, 6, sellReasons, $"Resistance above/near spot {resistance:0}", ref sellScore);

        int trendScore = ScoreTrend(t);
        int oiScore = peChg > ceChg ? 80 : ceChg > peChg ? 25 : 50;
        int volumeScore = t.Rvol >= 1.5m ? 85 : t.Rvol >= 1.2m ? 70 : t.Rvol >= 1.0m ? 55 : 40;
        int ivScore = avgIv == 0 ? 50 : avgIv <= 17 ? 55 : avgIv <= 25 ? 70 : 45;

        string strategyName;
        string signal;
        string bias;
        int finalScore;
        List<string> reasons;

        if (buyScore >= 62 && buyScore >= sellScore + 10)
        {
            strategyName = StrategyNameForBuy(t, rows);
            signal = "BUY Bias";
            bias = "Bullish";
            finalScore = Math.Min(100, buyScore);
            reasons = buyReasons;
        }
        else if (sellScore >= 62 && sellScore >= buyScore + 10)
        {
            strategyName = StrategyNameForSell(t, rows);
            signal = "SELL Bias";
            bias = "Bearish";
            finalScore = Math.Min(100, sellScore);
            reasons = sellReasons;
        }
        else
        {
            strategyName = "No Trade - Wait For Confluence";
            signal = "WAIT";
            bias = "Neutral";
            finalScore = Math.Max(35, Math.Min(60, Math.Max(buyScore, sellScore)));
            reasons = buyScore >= sellScore ? buyReasons : sellReasons;
        }

        decimal atr = t.Atr > 0 ? t.Atr : Math.Max(20, Math.Abs(rows.First().Strike - rows.Last().Strike) / Math.Max(1, rows.Count));
        decimal stopLoss = 0;
        decimal target1 = 0;
        decimal target2 = 0;

        if (signal.StartsWith("BUY"))
        {
            stopLoss = support > 0 && support < spot ? support - atr * 0.25m : spot - atr;
            target1 = resistance > spot ? resistance : spot + atr * 1.5m;
            target2 = target1 + atr;
        }
        else if (signal.StartsWith("SELL"))
        {
            stopLoss = resistance > spot ? resistance + atr * 0.25m : spot + atr;
            target1 = support > 0 && support < spot ? support : spot - atr * 1.5m;
            target2 = target1 - atr;
        }

        return new SmartMoneySnapshot
        {
            TrendScore = trendScore,
            OiScore = oiScore,
            VolumeScore = volumeScore,
            IvScore = ivScore,
            FinalScore = finalScore,
            Bias = bias,
            Signal = signal,
            StrategyName = strategyName,
            StopLoss = stopLoss,
            Target1 = target1,
            Target2 = target2,
            Support = support,
            Resistance = resistance,
            PcrOi = pcrOi,
            PcrVolume = pcrVol,
            AverageIv = avgIv,
            BuyScore = buyScore,
            SellScore = sellScore,
            Reason = string.Join(" | ", reasons.Take(6))
        };
    }

    private static void AddCondition(bool condition, int points, List<string> reasons, string reason, ref int score)
    {
        if (!condition) return;
        score += points;
        reasons.Add(reason);
    }

    private static int ScoreTrend(TrendSnapshot t)
    {
        int score = 40;
        if (t.EmaTrend == "Bullish") score += 15; else score -= 10;
        if (t.VwapStatus == "Above") score += 15; else score -= 15;
        if (t.MacdStatus == "Bullish") score += 10; else score -= 10;
        if (t.SuperTrend == "Buy") score += 10; else score -= 10;
        if (t.Adx >= 20) score += 10;
        return Math.Max(0, Math.Min(100, score));
    }

    private static string StrategyNameForBuy(TrendSnapshot t, List<OptionChainRow> rows)
    {
        bool hasPeLongBuild = rows.Any(x => x.PE?.Signal == "Long Build");
        bool hasCeShortCover = rows.Any(x => x.CE?.Signal == "Short Cover");

        if (t.VwapStatus == "Above" && t.SuperTrend == "Buy" && hasPeLongBuild)
            return "BUY Strategy 1 - Trend + PE Writing Continuation";
        if (hasCeShortCover)
            return "BUY Strategy 2 - Short Covering Reversal";
        return "BUY Strategy 3 - VWAP Trend Continuation";
    }

    private static string StrategyNameForSell(TrendSnapshot t, List<OptionChainRow> rows)
    {
        bool hasCeShortBuild = rows.Any(x => x.CE?.Signal == "Short Build");
        bool hasPeLongUnwind = rows.Any(x => x.PE?.Signal == "Long Unwind");

        if (t.VwapStatus == "Below" && t.SuperTrend == "Sell" && hasCeShortBuild)
            return "SELL Strategy 1 - Trend + CE Writing Continuation";
        if (hasPeLongUnwind)
            return "SELL Strategy 2 - PE Long Unwinding Breakdown";
        return "SELL Strategy 3 - VWAP Breakdown Continuation";
    }
}
