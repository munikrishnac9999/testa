# wpfCSharp_LiveOnly_WPF

Live-only FYERS WPF dashboard. No mock data is included.

## What is included

- AuthCode -> AccessToken FYERS login flow
- Live History API candles
- Live Option Chain API
- Live Quotes API
- WPF chart engine with candles, EMA20/50/200, VWAP, SuperTrend, volume and RVOL
- Option chain grid with CE/PE signal, IV, OI, OI Change, Volume and Greeks
- Smart Money Score panel
- Buy/Sell bias with SL/Target
- Live alerts panel

## Required before running

1. Install .NET 8 SDK on Windows.
2. Open this folder in Visual Studio.
3. Restore NuGet packages.
4. Enter:
   - FYERS AppId
   - FYERS AppSecret
   - Fresh auth_code from FYERS redirect URL
   - Symbol, for example `NSE:NIFTY50-INDEX`
5. Click Login, then Start Live.

## Important

This app does not generate or simulate market data. If FYERS API permission, token, F&O access, or network access is missing, the app shows an error in the alerts panel.

## Strategy Engine Update

This version adds a strategy engine for paper trading.

### Strategy logic included

- BUY Strategy 1: Trend + PE Writing Continuation
- BUY Strategy 2: Short Covering Reversal
- BUY Strategy 3: VWAP Trend Continuation
- SELL Strategy 1: Trend + CE Writing Continuation
- SELL Strategy 2: PE Long Unwinding Breakdown
- SELL Strategy 3: VWAP Breakdown Continuation

### Paper trading

Paper trading is local simulation only. It uses FYERS live data for signals and PnL calculation, but it does not place real broker orders.

### Risk note

This project is for development, testing and paper trading. Validate strategy output with live market observation before any real trade implementation.

## Latest Requested Upgrade

Planned/Integrated Architecture:
- Header symbol price, change, change % display
- MFI, CMF, CCI, ROC, DEMA, VWMA strategy inputs
- Automatic paper trading engine
- Manual order entry screen design
- Auto trade configuration section
- Buy/Sell scoring model
- Strategy dashboard
- Trade journal and PnL tracking

Note:
Real order placement should remain disabled until strategy validation is completed.
