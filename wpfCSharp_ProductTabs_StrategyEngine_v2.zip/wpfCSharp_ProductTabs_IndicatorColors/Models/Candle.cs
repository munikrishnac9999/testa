namespace wpfCSharp_LiveOnly_WPF.Models;
public sealed class Candle
{
    public DateTime Time { get; set; }
    public decimal Open { get; set; }
    public decimal High { get; set; }
    public decimal Low { get; set; }
    public decimal Close { get; set; }
    public decimal Volume { get; set; }
    public decimal Ema20 { get; set; }
    public decimal Ema50 { get; set; }
    public decimal Ema200 { get; set; }
    public decimal Sma20 { get; set; }
    public decimal Sma50 { get; set; }
    public decimal Vwap { get; set; }
    public decimal Atr14 { get; set; }
    public decimal Rsi14 { get; set; }
    public decimal Macd { get; set; }
    public decimal MacdSignal { get; set; }
    public decimal MacdHistogram { get; set; }
    public decimal Adx14 { get; set; }
    public decimal PlusDi14 { get; set; }
    public decimal MinusDi14 { get; set; }
    public decimal Rvol { get; set; }
    public decimal BollUpper { get; set; }
    public decimal BollMiddle { get; set; }
    public decimal BollLower { get; set; }
    public decimal DonchianUpper { get; set; }
    public decimal DonchianLower { get; set; }
    public decimal KeltnerUpper { get; set; }
    public decimal KeltnerLower { get; set; }
    public decimal SuperTrend { get; set; }
    public bool SuperTrendBullish { get; set; }
    public decimal VolumeProfilePoc { get; set; }
}
