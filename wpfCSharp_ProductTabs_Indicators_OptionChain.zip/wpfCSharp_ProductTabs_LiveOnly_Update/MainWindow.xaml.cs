using System.Collections.Specialized;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;
using wpfCSharp_LiveOnly_WPF.Models;
using wpfCSharp_LiveOnly_WPF.ViewModels;
namespace wpfCSharp_LiveOnly_WPF;
public partial class MainWindow : Window
{
    private readonly MainViewModel _vm = new();
    public MainWindow()
    {
        InitializeComponent();
        DataContext = _vm;
        _vm.Candles.CollectionChanged += Candles_CollectionChanged;
    }
    private void Candles_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) => DrawCharts();
    private void ChartCanvas_SizeChanged(object sender, SizeChangedEventArgs e) => DrawCharts();
    private void DrawCharts()
    {
        ChartCanvas.Children.Clear(); VolumeCanvas.Children.Clear();
        var candles = _vm.Candles.ToList(); if (candles.Count < 2 || ChartCanvas.ActualWidth <= 0 || ChartCanvas.ActualHeight <= 0) return;
        decimal max = candles.Max(x => Math.Max(x.High, Math.Max(x.BollUpper, Math.Max(x.DonchianUpper, x.KeltnerUpper))));
        decimal min = candles.Min(x => { var vals = new[] { x.Low, x.BollLower == 0 ? x.Low : x.BollLower, x.DonchianLower == 0 ? x.Low : x.DonchianLower, x.KeltnerLower == 0 ? x.Low : x.KeltnerLower }; return vals.Min(); });
        if (max <= min) return;
        double w = ChartCanvas.ActualWidth / candles.Count; double h = ChartCanvas.ActualHeight;
        double Y(decimal v) => h - (double)((v - min) / (max - min)) * h;
        DrawLine(candles.Select((c, i) => (i * w + w / 2, Y(c.Ema20))).ToList(), Brushes.Gold, 1.2);
        DrawLine(candles.Select((c, i) => (i * w + w / 2, Y(c.Ema50))).ToList(), Brushes.Orange, 1.2);
        DrawLine(candles.Select((c, i) => (i * w + w / 2, Y(c.Ema200))).ToList(), Brushes.White, 1.0);
        DrawLine(candles.Where(c => c.Vwap > 0).Select((c, i) => (i * w + w / 2, Y(c.Vwap))).ToList(), Brushes.DeepSkyBlue, 1.4);
        DrawLine(candles.Where(c => c.SuperTrend > 0).Select((c, i) => (i * w + w / 2, Y(c.SuperTrend))).ToList(), Brushes.LimeGreen, 1.0);
        for (int i = 0; i < candles.Count; i++)
        {
            Candle c = candles[i]; double x = i * w + w / 2; Brush brush = c.Close >= c.Open ? Brushes.LimeGreen : Brushes.Red;
            ChartCanvas.Children.Add(new Line { X1 = x, X2 = x, Y1 = Y(c.High), Y2 = Y(c.Low), Stroke = brush, StrokeThickness = 1 });
            double top = Y(Math.Max(c.Open, c.Close)); double bot = Y(Math.Min(c.Open, c.Close));
            var rect = new Rectangle { Width = Math.Max(2, w * .65), Height = Math.Max(2, bot - top), Fill = brush, Opacity = .85 };
            Canvas.SetLeft(rect, x - rect.Width / 2); Canvas.SetTop(rect, top); ChartCanvas.Children.Add(rect);
        }
        decimal maxVol = candles.Max(x => x.Volume); if (maxVol > 0)
        {
            double vh = VolumeCanvas.ActualHeight;
            for (int i = 0; i < candles.Count; i++)
            {
                Candle c = candles[i]; double barH = (double)(c.Volume / maxVol) * vh; Brush brush = c.Close >= c.Open ? Brushes.LimeGreen : Brushes.Red;
                var r = new Rectangle { Width = Math.Max(2, w * .65), Height = barH, Fill = brush, Opacity = c.Rvol >= 1.5m ? .95 : .45 };
                Canvas.SetLeft(r, i * w + (w - r.Width) / 2); Canvas.SetTop(r, vh - barH); VolumeCanvas.Children.Add(r);
            }
        }
    }
    private void DrawLine(List<(double x, double y)> points, Brush brush, double thickness)
    {
        if (points.Count < 2) return;
        var geo = new StreamGeometry(); using (var ctx = geo.Open()) { ctx.BeginFigure(new Point(points[0].x, points[0].y), false, false); ctx.PolyLineTo(points.Skip(1).Select(p => new Point(p.x, p.y)).ToList(), true, false); }
        ChartCanvas.Children.Add(new Path { Data = geo, Stroke = brush, StrokeThickness = thickness, Opacity = .9 });
    }
}
