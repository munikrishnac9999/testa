using wpfCSharp_LiveOnly_WPF.Models;
namespace wpfCSharp_LiveOnly_WPF.Services;
public sealed class IndicatorService
{
    public void ApplyAll(List<Candle> c)
    {
        ApplyEma(c, 12, null); ApplyEma(c, 20, (x, v) => x.Ema20 = v); ApplyEma(c, 26, null); ApplyEma(c, 50, (x, v) => x.Ema50 = v); ApplyEma(c, 200, (x, v) => x.Ema200 = v);
        ApplySma(c, 20, (x, v) => x.Sma20 = v); ApplySma(c, 50, (x, v) => x.Sma50 = v);
        ApplyVwap(c); ApplyAtr(c, 14); ApplyRsi(c, 14); ApplyMacd(c); ApplyAdx(c, 14); ApplyBands(c, 20); ApplyChannels(c, 20); ApplyRvol(c, 20); ApplySuperTrend(c, 10, 3m); ApplyVolumeProfile(c, 80);
    }
    private List<decimal> CalcEmaValues(List<Candle> c, int p){ var list=new List<decimal>(); decimal k=2m/(p+1), ema=0; for(int i=0;i<c.Count;i++){ema=i==0?c[i].Close:c[i].Close*k+ema*(1-k); list.Add(ema);} return list; }
    private void ApplyEma(List<Candle> c, int p, Action<Candle, decimal>? set){var values=CalcEmaValues(c,p); if(set!=null) for(int i=0;i<c.Count;i++) set(c[i],values[i]);}
    private void ApplySma(List<Candle> c, int p, Action<Candle, decimal> set){ for(int i=0;i<c.Count;i++) set(c[i], i+1<p?0:c.Skip(i-p+1).Take(p).Average(x=>x.Close)); }
    private void ApplyVwap(List<Candle> c){ decimal pv=0,vol=0; DateTime day=DateTime.MinValue; foreach(var x in c){ if(x.Time.Date!=day){day=x.Time.Date; pv=0; vol=0;} decimal typical=(x.High+x.Low+x.Close)/3; pv+=typical*x.Volume; vol+=x.Volume; x.Vwap=vol>0?pv/vol:0; } }
    private void ApplyAtr(List<Candle> c,int p){ decimal atr=0; for(int i=0;i<c.Count;i++){ decimal prev=i==0?c[i].Close:c[i-1].Close; decimal tr=Math.Max(c[i].High-c[i].Low,Math.Max(Math.Abs(c[i].High-prev),Math.Abs(c[i].Low-prev))); atr=i==0?tr:((atr*(p-1))+tr)/p; c[i].Atr14=atr; } }
    private void ApplyRsi(List<Candle> c,int p){ decimal gain=0,loss=0; for(int i=1;i<c.Count;i++){ decimal ch=c[i].Close-c[i-1].Close; gain=((gain*(p-1))+Math.Max(0,ch))/p; loss=((loss*(p-1))+Math.Max(0,-ch))/p; c[i].Rsi14=loss==0?100:100-(100/(1+gain/loss)); } }
    private void ApplyMacd(List<Candle> c){ var ema12=CalcEmaValues(c,12); var ema26=CalcEmaValues(c,26); var macd=ema12.Select((v,i)=>v-ema26[i]).ToList(); decimal k=2m/(9+1), sig=0; for(int i=0;i<c.Count;i++){ sig=i==0?macd[i]:macd[i]*k+sig*(1-k); c[i].Macd=macd[i]; c[i].MacdSignal=sig; c[i].MacdHistogram=macd[i]-sig; } }
    private void ApplyAdx(List<Candle> c,int p){ decimal trS=0,pdmS=0,mdmS=0,adx=0; for(int i=1;i<c.Count;i++){ decimal up=c[i].High-c[i-1].High, down=c[i-1].Low-c[i].Low; decimal pdm=up>down&&up>0?up:0, mdm=down>up&&down>0?down:0; decimal tr=Math.Max(c[i].High-c[i].Low,Math.Max(Math.Abs(c[i].High-c[i-1].Close),Math.Abs(c[i].Low-c[i-1].Close))); trS=((trS*(p-1))+tr)/p; pdmS=((pdmS*(p-1))+pdm)/p; mdmS=((mdmS*(p-1))+mdm)/p; decimal pdi=trS>0?100*pdmS/trS:0, mdi=trS>0?100*mdmS/trS:0; decimal dx=(pdi+mdi)>0?100*Math.Abs(pdi-mdi)/(pdi+mdi):0; adx=((adx*(p-1))+dx)/p; c[i].PlusDi14=pdi; c[i].MinusDi14=mdi; c[i].Adx14=adx; } }
    private void ApplyBands(List<Candle> c,int p){ for(int i=p-1;i<c.Count;i++){ var list=c.Skip(i-p+1).Take(p).Select(x=>x.Close).ToList(); decimal avg=list.Average(); decimal sd=(decimal)Math.Sqrt(list.Average(v=>Math.Pow((double)(v-avg),2))); c[i].BollMiddle=avg; c[i].BollUpper=avg+2*sd; c[i].BollLower=avg-2*sd; } }
    private void ApplyChannels(List<Candle> c,int p){ for(int i=p-1;i<c.Count;i++){ var list=c.Skip(i-p+1).Take(p); c[i].DonchianUpper=list.Max(x=>x.High); c[i].DonchianLower=list.Min(x=>x.Low); c[i].KeltnerUpper=c[i].Ema20+2*c[i].Atr14; c[i].KeltnerLower=c[i].Ema20-2*c[i].Atr14; } }
    private void ApplyRvol(List<Candle> c,int p){ for(int i=p-1;i<c.Count;i++){ decimal avg=c.Skip(i-p+1).Take(p).Average(x=>x.Volume); c[i].Rvol=avg>0?c[i].Volume/avg:0; } }
    private void ApplySuperTrend(List<Candle> c,int p,decimal m){ for(int i=0;i<c.Count;i++){ decimal mid=(c[i].High+c[i].Low)/2; c[i].SuperTrend=mid-m*c[i].Atr14; c[i].SuperTrendBullish=c[i].Close>=c[i].SuperTrend; } }
    private void ApplyVolumeProfile(List<Candle> c,int lookback){ var recent=c.TakeLast(Math.Min(lookback,c.Count)).ToList(); if(!recent.Any()) return; decimal poc=recent.GroupBy(x=>Math.Round(x.Close/10m)*10m).OrderByDescending(g=>g.Sum(x=>x.Volume)).First().Key; foreach(var x in c) x.VolumeProfilePoc=poc; }
    public TrendSnapshot BuildTrend(List<Candle> c)
    {
        var x=c.LastOrDefault(); if(x==null) return new TrendSnapshot();
        bool bullEma=x.Ema20>x.Ema50&&x.Ema50>x.Ema200, bullSma=x.Sma20>x.Sma50, aboveVwap=x.Close>x.Vwap;
        string band=x.Close>x.BollUpper?"Above Upper":x.Close<x.BollLower?"Below Lower":"Inside";
        string don=x.Close>=x.DonchianUpper?"Break High":x.Close<=x.DonchianLower?"Break Low":"Inside";
        string kel=x.Close>x.KeltnerUpper?"Above Upper":x.Close<x.KeltnerLower?"Below Lower":"Inside";
        return new TrendSnapshot{ EmaTrend=bullEma?"Bullish":"Bearish/Flat", SmaTrend=bullSma?"Bullish":"Bearish/Flat", VwapStatus=aboveVwap?"Above":"Below", Atr=x.Atr14, Rsi=x.Rsi14, Macd=x.Macd, MacdSignal=x.MacdSignal, MacdStatus=x.Macd>x.MacdSignal?"Bullish":"Bearish", Adx=x.Adx14, AdxStatus=x.Adx14>=25?"Strong":"Weak", SuperTrend=x.SuperTrendBullish?"Buy":"Sell", BollingerStatus=band, DonchianStatus=don, KeltnerStatus=kel, Rvol=x.Rvol, VolumeProfilePoc=x.VolumeProfilePoc, TrendBias=bullEma&&aboveVwap&&x.Macd>x.MacdSignal?"Bullish":(!aboveVwap&&x.Macd<x.MacdSignal?"Bearish":"Neutral")};
    }
}
