namespace wpfCSharp_LiveOnly_WPF.Models;

public sealed class BrokerOrderRequest
{
    public string Symbol { get; set; } = string.Empty;
    public string Side { get; set; } = "BUY";
    public string ProductType { get; set; } = "INTRADAY";
    public string OrderType { get; set; } = "MARKET";
    public decimal Quantity { get; set; }
    public decimal Price { get; set; }
    public decimal FinalScore { get; set; }
    public string Signal { get; set; } = string.Empty;
    public string TradingMode { get; set; } = string.Empty;
}

public sealed class BrokerOrderResult
{
    public bool Success { get; set; }
    public bool IsBlocked { get; set; }
    public string OrderId { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public DateTime Time { get; set; } = DateTime.Now;
}
