using Newtonsoft.Json.Linq;
using wpfCSharp_LiveOnly_WPF.Models;
namespace wpfCSharp_LiveOnly_WPF.Services;
public sealed class FyersOptionChainService
{
    private readonly FyersApiClient _api;
    private readonly Dictionary<string, OptionLeg> _previous = new(StringComparer.OrdinalIgnoreCase);
    public decimal CurrentSpot { get; private set; }
    public string CurrentExpiry { get; private set; } = "Nearest / Current";
    public FyersOptionChainService(FyersApiClient api) => _api = api;
    public async Task<List<OptionChainRow>> GetRowsAsync(string symbol, int strikeCount)
    {
        string strikeParam = strikeCount <= 0 ? string.Empty : $"&strikecount={strikeCount}";
        string url = "https://api-t1.fyers.in/data/options-chain-v3" + $"?symbol={Uri.EscapeDataString(symbol)}{strikeParam}&timestamp=&greeks=1";
        string json = await _api.GetAsync(url);
        var rows = ParseOptionChain(json);
        await ApplyQuotesAsync(rows);
        CalculateSignals(rows);
        SaveSnapshot(rows);
        return rows;
    }
    private List<OptionChainRow> ParseOptionChain(string json)
    {
        JObject root = JObject.Parse(json);
        JArray chain = root["data"]?["optionsChain"] as JArray ?? new JArray();
        CurrentSpot = GetDec(root["data"], "underlyingValue", "underlying_value", "ltp", "spot");
        JArray? expiryData = root["data"]?["expiryData"] as JArray;
        if (expiryData != null && expiryData.Count > 0) CurrentExpiry = GetStr(expiryData[0], "date", "expiry", "label");
        var map = new Dictionary<decimal, OptionChainRow>();
        foreach (JToken item in chain)
        {
            decimal strike = GetDec(item, "strike_price", "strikePrice", "strike");
            if (strike <= 0) continue;
            if (!map.ContainsKey(strike)) map[strike] = new OptionChainRow { Strike = strike };
            string type = GetStr(item, "option_type", "optionType", "type", "symbol");
            if (type.Contains("CE", StringComparison.OrdinalIgnoreCase)) map[strike].CE = ParseLeg(item, "CE", strike);
            if (type.Contains("PE", StringComparison.OrdinalIgnoreCase)) map[strike].PE = ParseLeg(item, "PE", strike);
            if (item["CE"] != null) map[strike].CE = ParseLeg(item["CE"]!, "CE", strike);
            if (item["PE"] != null) map[strike].PE = ParseLeg(item["PE"]!, "PE", strike);
        }
        var rows = map.Values.OrderBy(x => x.Strike).ToList();
        if (rows.Count > 0)
        {
            decimal atm = rows.OrderBy(x => Math.Abs(x.Strike - CurrentSpot)).First().Strike;
            foreach (var row in rows)
            {
                row.IsAtm = row.Strike == atm;
                row.StrikeBrush = row.IsAtm ? "#2DD4FF" : "#E7EEFB";
            }
        }
        CalculateGreeks(rows);
        return rows;
    }
    private OptionLeg ParseLeg(JToken t, string side, decimal strike) => new()
    {
        Symbol = GetStr(t, "symbol", "n"), Side = side, Strike = strike,
        Ltp = GetDec(t, "ltp", "lp", "last_price", "lastPrice"),
        BidPrice = GetDec(t, "bid", "bid_price", "bidPrice", "bp1", "best_bid_price"),
        AskPrice = GetDec(t, "ask", "ask_price", "askPrice", "ap1", "best_ask_price"),
        Oi = GetDec(t, "oi", "open_interest", "openInterest"),
        OiChange = GetDec(t, "oich", "oi_change", "oiChange", "change_oi", "changeOi"), Volume = GetDec(t, "volume", "vol", "v"),
        Iv = GetIv(t), Delta = GetGreek(t, "delta"), Gamma = GetGreek(t, "gamma"), Theta = GetGreek(t, "theta"), Vega = GetGreek(t, "vega")
    };
    private async Task ApplyQuotesAsync(List<OptionChainRow> rows)
    {
        var symbols = rows.SelectMany(x => new[] { x.CE?.Symbol, x.PE?.Symbol }).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().Take(50).ToList();
        if (symbols.Count == 0) return;
        string url = "https://api-t1.fyers.in/data/quotes?symbols=" + Uri.EscapeDataString(string.Join(",", symbols));
        string json = await _api.GetAsync(url);
        JObject root = JObject.Parse(json);
        var map = new Dictionary<string, JToken>(StringComparer.OrdinalIgnoreCase);
        foreach (JToken q in root["d"] as JArray ?? new JArray())
        {
            string s = GetStr(q, "n", "symbol");
            if (!string.IsNullOrWhiteSpace(s)) map[s] = q["v"] ?? q;
        }
        foreach (var leg in rows.SelectMany(x => new[] { x.CE, x.PE }).Where(x => x != null).Cast<OptionLeg>())
        {
            if (!map.TryGetValue(leg.Symbol, out JToken? v)) continue;
            decimal lp = GetDec(v, "lp", "ltp"); if (lp > 0) leg.Ltp = lp;
            decimal bid = GetDec(v, "bid", "bid_price", "bidPrice", "bp1", "best_bid_price"); if (bid > 0) leg.BidPrice = bid;
            decimal ask = GetDec(v, "ask", "ask_price", "askPrice", "ap1", "best_ask_price"); if (ask > 0) leg.AskPrice = ask;
            leg.Volume = Math.Max(leg.Volume, GetDec(v, "volume", "vol", "v"));
            leg.PriceChange = GetDec(v, "ch", "change");
        }
    }
    private void CalculateSignals(List<OptionChainRow> rows)
    {
        foreach (var leg in rows.SelectMany(x => new[] { x.CE, x.PE }).Where(x => x != null).Cast<OptionLeg>())
        {
            decimal oiDiff, priceDiff;
            if (_previous.TryGetValue($"{leg.Strike}_{leg.Side}", out var prev)) { oiDiff = leg.Oi - prev.Oi; priceDiff = leg.Ltp - prev.Ltp; }
            else { oiDiff = leg.OiChange; priceDiff = leg.PriceChange; }
            leg.Signal = BuildSignal(oiDiff, priceDiff);
            leg.SignalBrush = BrushForSignal(leg.Signal, leg.Side);
            leg.PriceBrush = PriceBrush(leg.PriceChange);
            leg.IvBrush = IvBrush(leg.Iv);
            leg.OiChangeBrush = OiChangeBrush(leg.OiChange, leg.Side);
            leg.DeltaBrush = DeltaBrush(leg.Delta, leg.Side);
            leg.GammaBrush = leg.Gamma != 0 ? "#2DD4FF" : "#93A4BD";
            leg.ThetaBrush = leg.Theta < 0 ? "#FF4D4D" : leg.Theta > 0 ? "#19C37D" : "#93A4BD";
            leg.VegaBrush = leg.Vega != 0 ? "#C084FC" : "#93A4BD";
        }
    }
    private static string BuildSignal(decimal oi, decimal price)
    {
        if (oi > 0 && price > 0) return "Long Build";
        if (oi > 0 && price < 0) return "Short Build";
        if (oi < 0 && price < 0) return "Long Unwind";
        if (oi < 0 && price > 0) return "Short Cover";
        if (oi > 0) return "OI Added";
        if (oi < 0) return "OI Reduced";
        return "Neutral";
    }
    private static string BrushForSignal(string signal, string side) => signal switch
    {
        "Long Build" => "#19C37D", "Short Build" => "#FF4D4D", "Short Cover" => "#2DD4FF", "Long Unwind" => "#FFC857",
        "OI Added" => side == "CE" ? "#D94B4B" : "#36C983", "OI Reduced" => "#B59B3B", _ => "#93A4BD"
    };

    private static string PriceBrush(decimal priceChange)
    {
        if (priceChange > 0) return "#19C37D";
        if (priceChange < 0) return "#FF4D4D";
        return "#E7EEFB";
    }
    private static string IvBrush(decimal iv)
    {
        if (iv >= 25) return "#FFC857";
        if (iv >= 18) return "#E7EEFB";
        return "#93A4BD";
    }
    private static string OiChangeBrush(decimal oiChange, string side)
    {
        if (oiChange == 0) return "#93A4BD";
        if (side == "CE") return oiChange > 0 ? "#FF4D4D" : "#2DD4FF";
        return oiChange > 0 ? "#19C37D" : "#FFC857";
    }
    private static string DeltaBrush(decimal delta, string side)
    {
        if (delta == 0) return "#93A4BD";
        if (side == "CE") return delta > 0 ? "#19C37D" : "#FFC857";
        return delta < 0 ? "#FF4D4D" : "#FFC857";
    }
    private void SaveSnapshot(List<OptionChainRow> rows)
    {
        foreach (var leg in rows.SelectMany(x => new[] { x.CE, x.PE }).Where(x => x != null).Cast<OptionLeg>())
            _previous[$"{leg.Strike}_{leg.Side}"] = new OptionLeg { Symbol = leg.Symbol, Side = leg.Side, Strike = leg.Strike, Ltp = leg.Ltp, BidPrice = leg.BidPrice, AskPrice = leg.AskPrice, Oi = leg.Oi };
    }
    private void CalculateGreeks(List<OptionChainRow> rows)
    {
        if (CurrentSpot <= 0) return;

        double t = Math.Max(1.0 / 365.0, 7.0 / 365.0);
        double r = 0.06;

        foreach (var leg in rows.SelectMany(x => new[] { x.CE, x.PE }).Where(x => x != null).Cast<OptionLeg>())
        {
            double s = (double)CurrentSpot;
            double k = (double)leg.Strike;
            double sqrtT = Math.Sqrt(t);

            double sigma = leg.Iv > 0 ? (double)leg.Iv / 100.0 : 0;

            if (sigma <= 0 && leg.Ltp > 0)
                sigma = EstimateImpliedVolatility((double)leg.Ltp, s, k, t, r, leg.Side == "CE");

            // Final fallback so dashboard never shows IV as zero when FYERS does not send IV.
            if (sigma <= 0)
                sigma = 0.20;

            leg.Iv = Math.Round((decimal)(sigma * 100.0), 2);

            double d1 = (Math.Log(s / k) + (r + 0.5 * sigma * sigma) * t) / (sigma * sqrtT);
            double d2 = d1 - sigma * sqrtT;
            double pdf = Math.Exp(-0.5 * d1 * d1) / Math.Sqrt(2 * Math.PI);
            double cdf = N(d1);

            leg.Delta = (decimal)(leg.Side == "CE" ? cdf : cdf - 1);
            leg.Gamma = (decimal)(pdf / (s * sigma * sqrtT));
            leg.Theta = (decimal)((-(s * pdf * sigma) / (2 * sqrtT)) / 365.0);
            leg.Vega = (decimal)(s * pdf * sqrtT / 100.0);
        }
    }

    private static double EstimateImpliedVolatility(double marketPrice, double s, double k, double t, double r, bool isCall)
    {
        if (marketPrice <= 0 || s <= 0 || k <= 0 || t <= 0) return 0;

        double intrinsic = isCall ? Math.Max(0, s - k) : Math.Max(0, k - s);
        if (marketPrice <= intrinsic) return 0;

        double low = 0.01;
        double high = 3.00;

        for (int i = 0; i < 80; i++)
        {
            double mid = (low + high) / 2;
            double price = BlackScholesPrice(s, k, t, r, mid, isCall);

            if (price > marketPrice)
                high = mid;
            else
                low = mid;
        }

        return (low + high) / 2;
    }

    private static double BlackScholesPrice(double s, double k, double t, double r, double sigma, bool isCall)
    {
        double sqrtT = Math.Sqrt(t);
        double d1 = (Math.Log(s / k) + (r + 0.5 * sigma * sigma) * t) / (sigma * sqrtT);
        double d2 = d1 - sigma * sqrtT;

        return isCall
            ? s * N(d1) - k * Math.Exp(-r * t) * N(d2)
            : k * Math.Exp(-r * t) * N(-d2) - s * N(-d1);
    }

    private static double N(double x) { double sign = x < 0 ? -1 : 1; x = Math.Abs(x) / Math.Sqrt(2); double t = 1 / (1 + 0.3275911 * x); double y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - .284496736) * t + .254829592) * t * Math.Exp(-x * x); return .5 * (1 + sign * y); }

    private static decimal GetDec(JToken? t, params string[] names) { if (t == null) return 0; foreach (string n in names) if (decimal.TryParse(t[n]?.ToString(), out var d)) return d; return 0; }
    private static string GetStr(JToken? t, params string[] names) { if (t == null) return string.Empty; foreach (string n in names) { string? v = t[n]?.ToString(); if (!string.IsNullOrWhiteSpace(v)) return v; } return string.Empty; }
    private static decimal GetGreek(JToken t, string n) => GetDec(t, n) != 0 ? GetDec(t, n) : GetDec(t["greeks"], n);

    private static decimal GetIv(JToken t)
    {
        decimal iv = GetDec(t, "iv", "implied_volatility", "impliedVolatility", "impliedVolatilityPercent", "ivp");
        if (iv == 0) iv = GetDec(t["greeks"], "iv", "implied_volatility", "impliedVolatility", "impliedVolatilityPercent");
        if (iv > 0 && iv <= 1) iv *= 100; // API sometimes sends 0.18 instead of 18.
        return iv;
    }
}
