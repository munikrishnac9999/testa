using System.Windows.Input;
namespace wpfCSharp_LiveOnly_WPF.ViewModels;
public sealed class RelayCommand : ICommand
{
    private readonly Func<object?, Task>? _async; private readonly Action<object?>? _sync; private readonly Func<object?, bool>? _can;
    public RelayCommand(Action<object?> sync, Func<object?, bool>? can = null) { _sync = sync; _can = can; }
    public RelayCommand(Func<object?, Task> async, Func<object?, bool>? can = null) { _async = async; _can = can; }
    public bool CanExecute(object? parameter) => _can?.Invoke(parameter) ?? true;
    public async void Execute(object? parameter) { if (_async != null) await _async(parameter); else _sync?.Invoke(parameter); }
    public event EventHandler? CanExecuteChanged { add { CommandManager.RequerySuggested += value; } remove { CommandManager.RequerySuggested -= value; } }
}
