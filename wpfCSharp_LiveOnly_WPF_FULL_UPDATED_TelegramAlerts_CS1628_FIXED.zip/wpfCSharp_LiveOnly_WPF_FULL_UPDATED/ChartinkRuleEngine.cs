using wpfCSharp_LiveOnly_WPF.Models;

namespace wpfCSharp_LiveOnly_WPF.Services;

public sealed class ChartinkRuleEngine
{
    public List<StockScanResult> Apply(IEnumerable<StockScanResult> rows, IEnumerable<ChartinkFilterRule> rules)
    {
        var ruleList = rules.ToList();
        if (ruleList.Count == 0)
            return rows.OrderByDescending(x => x.FinalScore).ToList();

        return rows.Where(row => EvaluateRow(row, ruleList))
            .OrderByDescending(x => x.FinalScore)
            .ThenByDescending(x => Math.Max(x.Rvol10, x.Rvol20))
            .ToList();
    }

    public ChartinkFilterRule? ParseMagicFilter(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return null;
        string normalized = text.Trim().ToLowerInvariant();

        string field = normalized switch
        {
            var x when x.Contains("rsi") => "Rsi",
            var x when x.Contains("rvol") || x.Contains("volume") => "Rvol20",
            var x when x.Contains("score") => "FinalScore",
            var x when x.Contains("mfi") => "Mfi",
            var x when x.Contains("cmf") => "Cmf",
            var x when x.Contains("change") => "ChangePercent",
            _ => "FinalScore"
        };

        string op = normalized switch
        {
            var x when x.Contains("below") || x.Contains("less") || x.Contains("<") => "<",
            var x when x.Contains("equal") || x.Contains("=") => ">=",
            _ => ">"
        };

        decimal value = ExtractFirstNumber(normalized) ?? (field == "Rvol20" ? 1.5m : field == "Rsi" ? 60m : 70m);
        return new ChartinkFilterRule { Field = field, Operator = op, Value = value, Join = "AND" };
    }

    private static bool EvaluateRow(StockScanResult row, IReadOnlyList<ChartinkFilterRule> rules)
    {
        bool result = true;
        bool first = true;

        foreach (var rule in rules)
        {
            bool current = Compare(GetFieldValue(row, rule.Field), rule.Operator, rule.Value);
            if (first)
            {
                result = current;
                first = false;
                continue;
            }

            result = rule.Join.Equals("OR", StringComparison.OrdinalIgnoreCase)
                ? result || current
                : result && current;
        }

        return result;
    }

    private static decimal GetFieldValue(StockScanResult row, string field)
    {
        return field switch
        {
            "FinalScore" => row.FinalScore,
            "BuyScore" => row.BuyScore,
            "SellScore" => row.SellScore,
            "Rsi" => row.Rsi,
            "Roc" => row.Roc,
            "Cci" => row.Cci,
            "Mfi" => row.Mfi,
            "Cmf" => row.Cmf,
            "Rvol10" => row.Rvol10,
            "Rvol20" => row.Rvol20,
            "Atr" => row.Atr,
            "ChangePercent" => row.ChangePercent,
            "SuperTrendScore" => row.SuperTrendScore,
            "SmcScore" => row.SmcScore,
            _ => row.FinalScore
        };
    }

    private static bool Compare(decimal left, string op, decimal right)
    {
        return op switch
        {
            ">" => left > right,
            ">=" => left >= right,
            "<" => left < right,
            "<=" => left <= right,
            "=" => left == right,
            "!=" => left != right,
            _ => left >= right
        };
    }

    private static decimal? ExtractFirstNumber(string text)
    {
        string token = new string(text.Select(ch => char.IsDigit(ch) || ch == '.' ? ch : ' ').ToArray())
            .Split(' ', StringSplitOptions.RemoveEmptyEntries)
            .FirstOrDefault() ?? string.Empty;

        return decimal.TryParse(token, out decimal value) ? value : null;
    }
}
