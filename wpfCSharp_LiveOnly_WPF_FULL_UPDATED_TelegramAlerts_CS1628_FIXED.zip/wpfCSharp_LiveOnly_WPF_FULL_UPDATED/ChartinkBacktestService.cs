using wpfCSharp_LiveOnly_WPF.Models;

namespace wpfCSharp_LiveOnly_WPF.Services;

public sealed class ChartinkBacktestService
{
    public ChartinkBacktestResult Summarize(string scannerName, IEnumerable<StockScanResult> rows)
    {
        var list = rows.ToList();
        if (list.Count == 0)
        {
            return new ChartinkBacktestResult
            {
                ScannerName = scannerName,
                Summary = "No matching signals for selected scanner."
            };
        }

        int bullish = list.Count(x => x.Signal.StartsWith("BUY", StringComparison.OrdinalIgnoreCase) || x.FinalScore >= 60);
        int bearish = list.Count(x => x.Signal.StartsWith("SELL", StringComparison.OrdinalIgnoreCase) || x.FinalScore <= 40);
        decimal avgScore = list.Average(x => (decimal)x.FinalScore);
        decimal avgRvol = list.Average(x => Math.Max(x.Rvol10, x.Rvol20));
        decimal avgChange = list.Average(x => x.ChangePercent);

        return new ChartinkBacktestResult
        {
            ScannerName = scannerName,
            SignalCount = list.Count,
            BullishCount = bullish,
            BearishCount = bearish,
            AverageScore = avgScore,
            AverageRvol = avgRvol,
            AverageChangePercent = avgChange,
            Summary = $"Signals={list.Count}, Bullish={bullish}, Bearish={bearish}, AvgScore={avgScore:0.00}, AvgRVOL={avgRvol:0.00}, AvgChange={avgChange:0.00}%"
        };
    }
}
