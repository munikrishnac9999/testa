using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
namespace wpfCSharp_LiveOnly_WPF.Services;
public sealed class FyersAuthService
{
    private const string ValidateAuthUrl = "https://api-t1.fyers.in/api/v3/validate-authcode";
    public static string Sha256Hex(string input)
    {
        byte[] hash = SHA256.HashData(Encoding.UTF8.GetBytes(input));
        return Convert.ToHexString(hash).ToLowerInvariant();
    }
    public async Task<string> ExchangeAuthCodeAsync(HttpClient client, string appId, string appSecret, string authCode)
    {
        if (string.IsNullOrWhiteSpace(appId)) throw new InvalidOperationException("AppId is required.");
        if (string.IsNullOrWhiteSpace(appSecret)) throw new InvalidOperationException("AppSecret is required. No mock mode is available.");
        if (string.IsNullOrWhiteSpace(authCode)) throw new InvalidOperationException("Fresh auth code is required.");
        var payload = new { grant_type = "authorization_code", appIdHash = Sha256Hex($"{appId}:{appSecret}"), code = authCode.Trim() };
        using var req = new HttpRequestMessage(HttpMethod.Post, ValidateAuthUrl);
        req.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
        using HttpResponseMessage res = await client.SendAsync(req);
        string body = await res.Content.ReadAsStringAsync();
        if (!res.IsSuccessStatusCode) throw new Exception($"validate-authcode failed: {(int)res.StatusCode} {res.ReasonPhrase}\n{body}");
        using JsonDocument doc = JsonDocument.Parse(body);
        if (!doc.RootElement.TryGetProperty("access_token", out JsonElement tokenEl)) throw new Exception("access_token missing in FYERS response:\n" + body);
        return tokenEl.GetString() ?? throw new Exception("access_token empty.");
    }
}
