using System.Collections.ObjectModel;

namespace wpfCSharp_LiveOnly_WPF.Models;

public sealed class ChartinkFilterRule
{
    public string Field { get; set; } = "FinalScore";
    public string Operator { get; set; } = ">=";
    public decimal Value { get; set; } = 70;
    public string Join { get; set; } = "AND";
    public string Display => $"{Field} {Operator} {Value:0.##} ({Join})";
}

public sealed class ChartinkScanTemplate
{
    public string Name { get; set; } = "My Scanner";
    public string Description { get; set; } = string.Empty;
    public ObservableCollection<ChartinkFilterRule> Rules { get; set; } = new();
}

public sealed class ChartinkBacktestResult
{
    public string ScannerName { get; set; } = string.Empty;
    public int SignalCount { get; set; }
    public int BullishCount { get; set; }
    public int BearishCount { get; set; }
    public decimal AverageScore { get; set; }
    public decimal AverageRvol { get; set; }
    public decimal AverageChangePercent { get; set; }
    public string Summary { get; set; } = string.Empty;
}
