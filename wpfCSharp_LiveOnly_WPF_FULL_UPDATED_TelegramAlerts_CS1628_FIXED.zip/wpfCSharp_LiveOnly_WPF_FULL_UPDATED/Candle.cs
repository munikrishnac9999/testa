namespace wpfCSharp_LiveOnly_WPF.Models;
public sealed class Candle
{
    public DateTime Time { get; set; }
    public decimal Open { get; set; }
    public decimal High { get; set; }
    public decimal Low { get; set; }
    public decimal Close { get; set; }
    public decimal Volume { get; set; }
    public decimal Ema3 { get; set; }
    public decimal Ema20 { get; set; }
    public decimal Ema50 { get; set; }
    public decimal Ema200 { get; set; }
    public decimal Sma20 { get; set; }
    public decimal Sma50 { get; set; }
    public decimal Vwap { get; set; }
    public decimal Atr14 { get; set; }
    public decimal Rsi14 { get; set; }
    public decimal Macd { get; set; }
    public decimal MacdSignal { get; set; }
    public decimal MacdHistogram { get; set; }
    public decimal Adx14 { get; set; }
    public decimal PlusDi14 { get; set; }
    public decimal MinusDi14 { get; set; }
    public decimal Rvol { get; set; }
    public decimal Rvol10 { get; set; }
    public decimal Rvol20 { get; set; }
    public decimal BollUpper { get; set; }
    public decimal BollMiddle { get; set; }
    public decimal BollLower { get; set; }
    public decimal DonchianUpper { get; set; }
    public decimal DonchianLower { get; set; }
    public decimal KeltnerUpper { get; set; }
    public decimal KeltnerLower { get; set; }
    public decimal SuperTrend { get; set; }
    public bool SuperTrendBullish { get; set; }
    public decimal VolumeProfilePoc { get; set; }

    public decimal Roc14 { get; set; }
    public decimal Cci20 { get; set; }
    public decimal StochasticK14 { get; set; }
    public decimal Mfi14 { get; set; }
    public decimal Cmf20 { get; set; }
    public decimal Obv { get; set; }
    public decimal AdLine { get; set; }
    public decimal SmartFlow { get; set; }
    public decimal AbsorptionScore { get; set; }
    public decimal HistoricalVolatility20 { get; set; }
    public decimal StdDev20 { get; set; }
    public decimal Dema20 { get; set; }
    public decimal Tema20 { get; set; }
    public string DemaTemaSignal { get; set; } = "Neutral";
    public string DemaTemaBrush { get; set; } = "#93A4BD";
    public decimal Vwma20 { get; set; }
    public string TtmSqueezeStatus { get; set; } = "-";
    public string TtmSqueezeBrush { get; set; } = "#93A4BD";
    public decimal VortexPlus14 { get; set; }
    public decimal VortexMinus14 { get; set; }
    public string VortexSignal { get; set; } = "Neutral";
    public string VortexBrush { get; set; } = "#93A4BD";
    public decimal ChandelierLong { get; set; }
    public decimal ChandelierShort { get; set; }
    public string ChandelierSignal { get; set; } = "Neutral";
    public string ChandelierBrush { get; set; } = "#93A4BD";
    public decimal ElderBullPower { get; set; }
    public decimal ElderBearPower { get; set; }
    public string ElderRaySignal { get; set; } = "Neutral";
    public string ElderRayBrush { get; set; } = "#93A4BD";
    public decimal Tema3 { get; set; }
    public string Tema3VsTema20Signal { get; set; } = "Neutral";
    public string Tema3VsTema20Brush { get; set; } = "#93A4BD";
    public string PriceVsEma3Signal { get; set; } = "Neutral";
    public string PriceVsEma3Brush { get; set; } = "#93A4BD";
    public string CamarillaZone { get; set; } = "-";
    public string CamarillaBrush { get; set; } = "#93A4BD";
    public decimal AroonUp14 { get; set; }
    public decimal AroonDown14 { get; set; }
    public string AroonSignal { get; set; } = "Neutral";
    public string AroonBrush { get; set; } = "#93A4BD";
    public decimal Psar { get; set; }
    public string PsarSignal { get; set; } = "Neutral";
    public string PsarBrush { get; set; } = "#93A4BD";
    public string BosSignal { get; set; } = "Neutral";
    public string BosBrush { get; set; } = "#93A4BD";
    public string LiquiditySignal { get; set; } = "None";
    public string LiquidityBrush { get; set; } = "#93A4BD";
    public string OrderFlowSignal { get; set; } = "Neutral Flow";
    public string OrderFlowBrush { get; set; } = "#93A4BD";
    public string OrderBlockSignal { get; set; } = "None";
    public decimal OrderBlockHigh { get; set; }
    public decimal OrderBlockLow { get; set; }
    public string OrderBlockBrush { get; set; } = "#93A4BD";
    public string FvgSignal { get; set; } = "None";
    public decimal FvgHigh { get; set; }
    public decimal FvgLow { get; set; }
    public string FvgBrush { get; set; } = "#93A4BD";
    public string SmartMoneyStructureSignal { get; set; } = "Neutral";
    public int SmartMoneyStructureScore { get; set; }
    public string SmartMoneyStructureBrush { get; set; } = "#93A4BD";

    public string CandlestickPattern { get; set; } = "-";
    public string CandlestickBias { get; set; } = "Neutral";
    public string CandlestickBrush { get; set; } = "#93A4BD";
}
