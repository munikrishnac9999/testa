namespace wpfCSharp_LiveOnly_WPF.Models;

public enum PaperTradeSide
{
    Buy,
    Sell
}

public enum PaperTradeStatus
{
    Open,
    Closed
}

public sealed class PaperTrade
{
    public int Id { get; set; }
    public DateTime EntryTime { get; set; } = DateTime.Now;
    public DateTime? ExitTime { get; set; }
    public string Symbol { get; set; } = string.Empty;
    public PaperTradeSide Side { get; set; }
    public decimal Quantity { get; set; }
    public decimal EntryPrice { get; set; }
    public decimal ExitPrice { get; set; }
    public decimal StopLoss { get; set; }
    public decimal Target1 { get; set; }
    public decimal Target2 { get; set; }
    public decimal RealizedPnl { get; set; }
    public decimal UnrealizedPnl { get; set; }
    public PaperTradeStatus Status { get; set; } = PaperTradeStatus.Open;
    public string EntryReason { get; set; } = string.Empty;
    public string ExitReason { get; set; } = string.Empty;
    public string SideText => Side == PaperTradeSide.Buy ? "BUY" : "SELL";
    public string StatusText => Status == PaperTradeStatus.Open ? "OPEN" : "CLOSED";
    public string PnlBrush => (Status == PaperTradeStatus.Open ? UnrealizedPnl : RealizedPnl) >= 0 ? "#19C37D" : "#FF4D4D";
}

public sealed class PaperTradingSummary
{
    public bool Enabled { get; set; }
    public decimal Quantity { get; set; }
    public int TotalTrades { get; set; }
    public int OpenTrades { get; set; }
    public int ClosedTrades { get; set; }
    public decimal TotalProfit { get; set; }
    public decimal TotalLoss { get; set; }
    public decimal NetPnl { get; set; }
    public decimal OpenPnl { get; set; }
    public decimal WinRate { get; set; }
    public decimal ProfitFactor { get; set; }
    public decimal MaxDrawdown { get; set; }
    public string CurrentPosition { get; set; } = "None";
    public string LastAction { get; set; } = "-";
    public string NetPnlBrush => NetPnl >= 0 ? "#19C37D" : "#FF4D4D";
}
