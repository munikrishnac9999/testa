using System.Collections.ObjectModel;
using wpfCSharp_LiveOnly_WPF.Models;

namespace wpfCSharp_LiveOnly_WPF.Services;

public sealed class PaperTradingService
{
    private int _tradeId;
    public ObservableCollection<PaperTrade> Trades { get; } = new();
    public PaperTradingSummary Summary { get; } = new();

    public bool IsEnabled { get; set; } = true;
    public decimal Quantity { get; set; }
    public int BuyThreshold { get; set; }
    public int SellThreshold { get; set; }

    public void ProcessSignal(string symbol, decimal spot, SmartMoneySnapshot score)
    {
        ProcessSignal(symbol, spot, score, null);
    }

    public void ProcessSignal(string symbol, decimal spot, SmartMoneySnapshot score, IReadOnlyList<OptionChainRow>? optionRows)
    {
        Summary.Enabled = IsEnabled;
        Summary.Quantity = Quantity;

        OptionLeg? selectedLeg = SelectOptionLeg(score, optionRows);
        decimal tradePrice = selectedLeg?.Ltp > 0 ? selectedLeg.Ltp : spot;
        string tradeSymbol = !string.IsNullOrWhiteSpace(selectedLeg?.Symbol) ? selectedLeg!.Symbol : symbol;
        string optionSide = selectedLeg?.Side ?? "FUT";

        if (!IsEnabled || tradePrice <= 0)
        {
            UpdateOpenPnl(optionRows, tradePrice);
            RefreshSummary("Paper trading disabled");
            return;
        }

        if (Quantity <= 0 || BuyThreshold <= 0 || SellThreshold <= 0)
        {
            UpdateOpenPnl(optionRows, tradePrice);
            RefreshSummary("Set paper Quantity, Buy Threshold and Sell Threshold in the UI before option paper trading.");
            return;
        }

        UpdateOpenPnl(optionRows, tradePrice);
        CloseByStopOrTarget(optionRows, tradePrice);

        string signal = score.Signal ?? string.Empty;
        bool buySignal = BuyThreshold > 0 && score.FinalScore >= BuyThreshold && signal.Contains("BUY", StringComparison.OrdinalIgnoreCase);
        bool sellSignal = SellThreshold > 0 && score.FinalScore <= SellThreshold && signal.Contains("SELL", StringComparison.OrdinalIgnoreCase);

        if (buySignal || sellSignal)
        {
            // Options paper trading: BUY signal buys ATM CE. SELL signal buys ATM PE.
            // This avoids futures paper positions and tracks option LTP PnL.
            CloseOtherOpenOptions(tradeSymbol, optionRows, tradePrice, $"Signal changed to {optionSide}");
            OpenOptionIfNone(tradeSymbol, tradePrice, score, optionSide);
        }
        else
        {
            RefreshSummary($"WAIT/threshold not met. Score {score.FinalScore}, BuyTH {BuyThreshold}, SellTH {SellThreshold}.");
        }

        UpdateOpenPnl(optionRows, tradePrice);
        RefreshSummary(Summary.LastAction);
    }

    private static OptionLeg? SelectOptionLeg(SmartMoneySnapshot score, IReadOnlyList<OptionChainRow>? rows)
    {
        if (rows == null || rows.Count == 0) return null;
        string signal = score.Signal ?? string.Empty;
        bool buy = score.FinalScore >= 50 && signal.Contains("BUY", StringComparison.OrdinalIgnoreCase);
        bool sell = signal.Contains("SELL", StringComparison.OrdinalIgnoreCase);
        decimal atmStrike = rows.FirstOrDefault(x => x.IsAtm)?.Strike ?? rows.OrderBy(r => Math.Abs(r.Strike)).First().Strike;
        var ordered = rows.OrderByDescending(r => r.IsAtm).ThenBy(r => Math.Abs(r.Strike - atmStrike)).ToList();
        if (buy)
            return ordered.Select(r => r.CE).FirstOrDefault(l => l != null && l.Ltp > 0);
        if (sell)
            return ordered.Select(r => r.PE).FirstOrDefault(l => l != null && l.Ltp > 0);
        return null;
    }

    private decimal GetOptionPrice(string symbol, IReadOnlyList<OptionChainRow>? rows, decimal fallback)
    {
        if (rows == null || string.IsNullOrWhiteSpace(symbol)) return fallback;
        foreach (var leg in rows.SelectMany(r => new[] { r.CE, r.PE }).Where(l => l != null).Cast<OptionLeg>())
        {
            if (string.Equals(leg.Symbol, symbol, StringComparison.OrdinalIgnoreCase) && leg.Ltp > 0)
                return leg.Ltp;
        }
        return fallback;
    }

    private void CloseOtherOpenOptions(string symbolToKeep, IReadOnlyList<OptionChainRow>? rows, decimal fallbackPrice, string reason)
    {
        foreach (var trade in Trades.Where(t => t.Status == PaperTradeStatus.Open && !string.Equals(t.Symbol, symbolToKeep, StringComparison.OrdinalIgnoreCase)).ToList())
            CloseTrade(trade, GetOptionPrice(trade.Symbol, rows, fallbackPrice), reason);
    }

    private void OpenOptionIfNone(string symbol, decimal price, SmartMoneySnapshot score, string optionSide)
    {
        if (Trades.Any(t => t.Status == PaperTradeStatus.Open && string.Equals(t.Symbol, symbol, StringComparison.OrdinalIgnoreCase)))
        {
            Summary.LastAction = $"Holding OPTION {optionSide} {symbol}";
            return;
        }

        var trade = new PaperTrade
        {
            Id = ++_tradeId,
            Symbol = symbol,
            Side = PaperTradeSide.Buy,
            Quantity = Quantity,
            EntryPrice = price,
            StopLoss = Math.Round(price * 0.75m, 2),
            Target1 = Math.Round(price * 1.35m, 2),
            Target2 = Math.Round(price * 1.75m, 2),
            EntryReason = $"OPTION {optionSide} | {score.Reason}",
            EntryTime = DateTime.Now,
            Status = PaperTradeStatus.Open
        };

        Trades.Insert(0, trade);
        Summary.LastAction = $"OPEN OPTION {optionSide} {trade.Quantity} {trade.Symbol} @ {trade.EntryPrice:0.00}";
    }

    private void OpenIfNone(string symbol, PaperTradeSide side, decimal spot, SmartMoneySnapshot score)
    {
        if (Trades.Any(t => t.Status == PaperTradeStatus.Open && t.Side == side))
        {
            Summary.LastAction = $"Holding {side}";
            return;
        }

        var trade = new PaperTrade
        {
            Id = ++_tradeId,
            Symbol = symbol,
            Side = side,
            Quantity = Quantity,
            EntryPrice = spot,
            StopLoss = score.StopLoss,
            Target1 = score.Target1,
            Target2 = score.Target2,
            EntryReason = score.Reason,
            EntryTime = DateTime.Now,
            Status = PaperTradeStatus.Open
        };

        Trades.Insert(0, trade);
        Summary.LastAction = $"OPEN {trade.SideText} {trade.Quantity} @ {trade.EntryPrice:0.00}";
    }

    private void CloseOpposite(PaperTradeSide sideToClose, decimal price, string reason)
    {
        foreach (var trade in Trades.Where(t => t.Status == PaperTradeStatus.Open && t.Side == sideToClose).ToList())
            CloseTrade(trade, price, reason);
    }

    private void CloseByStopOrTarget(decimal spot) => CloseByStopOrTarget(null, spot);

    private void CloseByStopOrTarget(IReadOnlyList<OptionChainRow>? rows, decimal fallbackPrice)
    {
        foreach (var trade in Trades.Where(t => t.Status == PaperTradeStatus.Open).ToList())
        {
            decimal price = GetOptionPrice(trade.Symbol, rows, fallbackPrice);
            if (trade.Side == PaperTradeSide.Buy)
            {
                if (trade.StopLoss > 0 && price <= trade.StopLoss) CloseTrade(trade, price, "Option SL hit");
                else if (trade.Target2 > 0 && price >= trade.Target2) CloseTrade(trade, price, "Option Target 2 hit");
                else if (trade.Target1 > 0 && price >= trade.Target1) CloseTrade(trade, price, "Option Target 1 hit");
            }
            else
            {
                if (trade.StopLoss > 0 && price >= trade.StopLoss) CloseTrade(trade, price, "SL hit");
                else if (trade.Target2 > 0 && price <= trade.Target2) CloseTrade(trade, price, "Target 2 hit");
                else if (trade.Target1 > 0 && price <= trade.Target1) CloseTrade(trade, price, "Target 1 hit");
            }
        }
    }

    private void CloseTrade(PaperTrade trade, decimal exitPrice, string reason)
    {
        if (trade.Status == PaperTradeStatus.Closed) return;

        trade.ExitPrice = exitPrice;
        trade.ExitTime = DateTime.Now;
        trade.RealizedPnl = CalculatePnl(trade, exitPrice);
        trade.UnrealizedPnl = 0;
        trade.ExitReason = reason;
        trade.Status = PaperTradeStatus.Closed;
        Summary.LastAction = $"CLOSE {trade.SideText} #{trade.Id} @ {exitPrice:0.00} | PnL {trade.RealizedPnl:0.00} | {reason}";
    }

    private void UpdateOpenPnl(decimal spot) => UpdateOpenPnl(null, spot);

    private void UpdateOpenPnl(IReadOnlyList<OptionChainRow>? rows, decimal fallbackPrice)
    {
        foreach (var trade in Trades.Where(t => t.Status == PaperTradeStatus.Open))
        {
            decimal price = GetOptionPrice(trade.Symbol, rows, fallbackPrice);
            trade.UnrealizedPnl = CalculatePnl(trade, price);
        }
    }

    private static decimal CalculatePnl(PaperTrade trade, decimal currentPrice)
    {
        return trade.Side == PaperTradeSide.Buy
            ? (currentPrice - trade.EntryPrice) * trade.Quantity
            : (trade.EntryPrice - currentPrice) * trade.Quantity;
    }

    private void RefreshSummary(string action)
    {
        Summary.TotalTrades = Trades.Count;
        Summary.OpenTrades = Trades.Count(t => t.Status == PaperTradeStatus.Open);
        Summary.ClosedTrades = Trades.Count(t => t.Status == PaperTradeStatus.Closed);
        Summary.TotalProfit = Trades.Where(t => t.Status == PaperTradeStatus.Closed && t.RealizedPnl > 0).Sum(t => t.RealizedPnl);
        Summary.TotalLoss = Trades.Where(t => t.Status == PaperTradeStatus.Closed && t.RealizedPnl < 0).Sum(t => Math.Abs(t.RealizedPnl));
        Summary.NetPnl = Summary.TotalProfit - Summary.TotalLoss;
        //Summary.RealizedPnl = Summary.NetPnl;
        Summary.OpenPnl = Trades.Where(t => t.Status == PaperTradeStatus.Open).Sum(t => t.UnrealizedPnl);
        Summary.CurrentPosition = Trades.FirstOrDefault(t => t.Status == PaperTradeStatus.Open)?.Symbol ?? "None";
        Summary.WinRate = Summary.ClosedTrades == 0 ? 0 : Math.Round((decimal)Trades.Count(t => t.Status == PaperTradeStatus.Closed && t.RealizedPnl > 0) / Summary.ClosedTrades * 100m, 2);
        Summary.ProfitFactor = Summary.TotalLoss == 0 ? (Summary.TotalProfit > 0 ? 99m : 0m) : Math.Round(Summary.TotalProfit / Summary.TotalLoss, 2);
        Summary.MaxDrawdown = CalculateMaxDrawdown();
        if (!string.IsNullOrWhiteSpace(action)) Summary.LastAction = action;
    }
    private decimal CalculateMaxDrawdown()
    {
        decimal equity = 0;
        decimal peak = 0;
        decimal maxDrawdown = 0;
        foreach (var trade in Trades.Where(t => t.Status == PaperTradeStatus.Closed).OrderBy(t => t.EntryTime))
        {
            equity += trade.RealizedPnl;
            if (equity > peak) peak = equity;
            decimal dd = peak - equity;
            if (dd > maxDrawdown) maxDrawdown = dd;
        }
        return Math.Round(maxDrawdown, 2);
    }

}
