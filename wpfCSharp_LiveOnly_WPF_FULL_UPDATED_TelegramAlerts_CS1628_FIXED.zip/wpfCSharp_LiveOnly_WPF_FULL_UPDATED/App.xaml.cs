using System.Windows;
namespace wpfCSharp_LiveOnly_WPF;
public partial class App : Application { }
