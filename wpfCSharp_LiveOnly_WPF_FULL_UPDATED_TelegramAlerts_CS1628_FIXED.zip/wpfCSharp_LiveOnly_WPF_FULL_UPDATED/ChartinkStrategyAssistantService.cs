using wpfCSharp_LiveOnly_WPF.Models;

namespace wpfCSharp_LiveOnly_WPF.Services;

public sealed class ChartinkStrategyAssistantService
{
    public List<string> GenerateSuggestions(string text)
    {
        string t = (text ?? string.Empty).Trim().ToLowerInvariant();
        var suggestions = new List<string>();

        if (string.IsNullOrWhiteSpace(t))
        {
            suggestions.Add("RSI above 60 and RVOL20 above 1.5 and FinalScore above 70");
            suggestions.Add("SuperTrend Buy and Higher High and RVOL20 above 1.2");
            suggestions.Add("RSI below 40 and FinalScore below 35 and Lower Low");
            suggestions.Add("MFI above 60 and CMF above 0 and Momentum Buy");
            return suggestions;
        }

        if (t.Contains("buy") || t.Contains("bull") || t.Contains("breakout"))
        {
            suggestions.Add("FinalScore above 70 and RSI above 55 and RVOL20 above 1.2");
            suggestions.Add("SuperTrend Buy and Higher High and CMF above 0");
            suggestions.Add("MFI above 55 and RSI above 55 and ChangePercent above 0");
        }

        if (t.Contains("sell") || t.Contains("bear") || t.Contains("breakdown"))
        {
            suggestions.Add("FinalScore below 40 and RSI below 45 and RVOL20 above 1.2");
            suggestions.Add("SuperTrend Sell and Lower Low and CMF below 0");
            suggestions.Add("MFI below 45 and RSI below 45 and ChangePercent below 0");
        }

        if (t.Contains("rsi"))
        {
            suggestions.Add("RSI above 60 and FinalScore above 65");
            suggestions.Add("RSI below 35 and Higher Low");
        }

        if (t.Contains("volume") || t.Contains("rvol"))
        {
            suggestions.Add("RVOL20 above 2 and Higher High");
            suggestions.Add("RVOL10 above 1.5 and SuperTrend Buy");
        }

        if (t.Contains("super") || t.Contains("trend"))
        {
            suggestions.Add("SuperTrend Buy and FinalScore above 70");
            suggestions.Add("SuperTrend Sell and FinalScore below 40");
        }

        if (suggestions.Count == 0)
        {
            suggestions.Add("FinalScore above 70 and RSI above 55 and RVOL20 above 1.2");
            suggestions.Add("FinalScore below 40 and RSI below 45 and RVOL20 above 1.2");
        }

        return suggestions.Distinct(StringComparer.OrdinalIgnoreCase).Take(8).ToList();
    }

    public List<ChartinkFilterRule> BuildRules(string text)
    {
        string t = (text ?? string.Empty).ToLowerInvariant();
        var rules = new List<ChartinkFilterRule>();

        AddNumericRule(t, rules, "finalscore", "FinalScore");
        AddNumericRule(t, rules, "score", "FinalScore");
        AddNumericRule(t, rules, "rsi", "Rsi");
        AddNumericRule(t, rules, "rvol20", "Rvol20");
        AddNumericRule(t, rules, "rvol10", "Rvol10");
        AddNumericRule(t, rules, "mfi", "Mfi");
        AddNumericRule(t, rules, "cmf", "Cmf");
        AddNumericRule(t, rules, "change", "ChangePercent");
        AddNumericRule(t, rules, "supertrendscore", "SuperTrendScore");
        AddNumericRule(t, rules, "smc", "SmcScore");

        if (t.Contains("supertrend buy")) rules.Add(new ChartinkFilterRule { Field = "SuperTrendScore", Operator = ">=", Value = 80, Join = "AND" });
        if (t.Contains("supertrend sell")) rules.Add(new ChartinkFilterRule { Field = "SuperTrendScore", Operator = "<=", Value = 25, Join = "AND" });
        if (t.Contains("higher high")) rules.Add(new ChartinkFilterRule { Field = "FinalScore", Operator = ">=", Value = 55, Join = "AND" });
        if (t.Contains("lower low")) rules.Add(new ChartinkFilterRule { Field = "FinalScore", Operator = "<=", Value = 50, Join = "AND" });

        if (rules.Count == 0)
            rules.Add(new ChartinkFilterRule { Field = "FinalScore", Operator = ">=", Value = 70, Join = "AND" });

        return rules;
    }

    public string Explain(string text, IReadOnlyCollection<ChartinkFilterRule> rules)
    {
        if (string.IsNullOrWhiteSpace(text))
            return "Type a strategy in plain English. Suggestions will appear automatically.";

        string ruleText = rules.Count == 0
            ? "No numeric rules detected yet. Try RSI above 60, RVOL20 above 1.5, FinalScore above 70."
            : string.Join(" | ", rules.Select(x => x.Display));

        return "Detected strategy rules: " + ruleText;
    }

    private static void AddNumericRule(string text, List<ChartinkFilterRule> rules, string keyword, string field)
    {
        int index = text.IndexOf(keyword, StringComparison.OrdinalIgnoreCase);
        if (index < 0) return;

        string tail = text[index..Math.Min(text.Length, index + 45)];
        decimal? value = ExtractFirstNumber(tail);
        if (value == null) return;

        string op = tail.Contains("below") || tail.Contains("less") || tail.Contains("<") ? "<=" : ">=";
        rules.Add(new ChartinkFilterRule { Field = field, Operator = op, Value = value.Value, Join = "AND" });
    }

    private static decimal? ExtractFirstNumber(string text)
    {
        string token = new string(text.Select(ch => char.IsDigit(ch) || ch == '.' ? ch : ' ').ToArray())
            .Split(' ', StringSplitOptions.RemoveEmptyEntries)
            .FirstOrDefault() ?? string.Empty;

        return decimal.TryParse(token, out decimal value) ? value : null;
    }
}
