using wpfCSharp_LiveOnly_WPF.Models;

namespace wpfCSharp_LiveOnly_WPF.Services;

public sealed class RealOrderDisabledService : IBrokerOrderService
{
    public bool IsConnected => false;

    public Task<BrokerOrderResult> PreviewOrderAsync(BrokerOrderRequest request)
    {
        return Task.FromResult(new BrokerOrderResult
        {
            Success = true,
            IsBlocked = false,
            Message = $"Order preview ready: {request.Side} {request.Quantity:0} {request.Symbol} @ {request.Price:0.00}. No broker order sent."
        });
    }

    public Task<BrokerOrderResult> PlaceOrderAsync(BrokerOrderRequest request)
    {
        return Task.FromResult(new BrokerOrderResult
        {
            Success = false,
            IsBlocked = true,
            Message = "Real order blocked. Broker order placement API is not connected in this build. No real order sent."
        });
    }
}
