using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using wpfCSharp_LiveOnly_WPF.Models;

namespace wpfCSharp_LiveOnly_WPF.Services;

public sealed class ChartinkTemplateService
{
    private static string TemplatePath => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ChartinkTemplates.json");

    public ObservableCollection<ChartinkScanTemplate> Load()
    {
        try
        {
            if (!File.Exists(TemplatePath))
                return CreateDefaultTemplates();

            var templates = JsonSerializer.Deserialize<ObservableCollection<ChartinkScanTemplate>>(File.ReadAllText(TemplatePath));
            return templates ?? CreateDefaultTemplates();
        }
        catch
        {
            return CreateDefaultTemplates();
        }
    }

    public void Save(IEnumerable<ChartinkScanTemplate> templates)
    {
        var json = JsonSerializer.Serialize(templates, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(TemplatePath, json);
    }

    private static ObservableCollection<ChartinkScanTemplate> CreateDefaultTemplates()
    {
        return new ObservableCollection<ChartinkScanTemplate>
        {
            new()
            {
                Name = "Strong Bullish Breakout",
                Description = "Score, RVOL and RSI bullish setup",
                Rules = new ObservableCollection<ChartinkFilterRule>
                {
                    new() { Field = "FinalScore", Operator = ">=", Value = 70, Join = "AND" },
                    new() { Field = "Rvol20", Operator = ">=", Value = 1.2m, Join = "AND" },
                    new() { Field = "Rsi", Operator = ">=", Value = 55, Join = "AND" }
                }
            },
            new()
            {
                Name = "Bearish Breakdown",
                Description = "Weak score, weak RSI and volume support",
                Rules = new ObservableCollection<ChartinkFilterRule>
                {
                    new() { Field = "FinalScore", Operator = "<=", Value = 40, Join = "AND" },
                    new() { Field = "Rsi", Operator = "<=", Value = 45, Join = "AND" },
                    new() { Field = "Rvol20", Operator = ">=", Value = 1.2m, Join = "AND" }
                }
            }
        };
    }
}
