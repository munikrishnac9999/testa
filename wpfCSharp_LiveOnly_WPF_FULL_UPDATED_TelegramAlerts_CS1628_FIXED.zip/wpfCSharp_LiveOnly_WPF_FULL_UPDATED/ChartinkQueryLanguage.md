# Strategy Studio Chartink-Like Query Language

This project implements a local Chartink-style query language for the Strategy Studio module. It is not a copy of Chartink's proprietary server engine, but it follows the same scanner concepts: filters, attributes, indicators, comparison operations, crossovers, arithmetic expressions, grouped AND/OR filters, and functional filters.

## Supported Syntax

### Comparison filters

```text
latest close > latest ema 20
latest rsi 14 >= 60
finalscore <= 40
supertrend = buy
pattern contains hammer
```

### AND / OR filters

```text
latest close > latest ema 20 and latest rsi 14 > 60
supertrend = buy or finalscore >= 75
```

### Between filters

```text
latest rsi 14 between 55 and 70
```

### Crossover style filters

```text
latest close crossed above latest ema 20
latest close crossed below latest ema 50
```

For current StockScanResult rows, crossover is evaluated as directional comparison. Candle-by-candle historical crossover can be added later using historical candle arrays.

### Arithmetic expressions

```text
latest volume > latest rvol20 * 1.5
latest close > latest ema 20 + 5
```

### Functional filters

```text
greatest(latest rsi 14, latest mfi 14) > 60
least(rvol10, rvol20) > 1.2
abs(cmf) > 0.05
```

### Count / countstreak compatibility

```text
count(20, 1 where latest close > latest ema 20) >= 1
countstreak(20, 1 where latest close > latest ema 20) >= 1
```

Current implementation evaluates count/countstreak against the latest scanner row as compatibility mode. Full historical count/countstreak requires storing each stock's candle history in the query runtime.

## Supported fields

```text
open, high, low, close, price, ltp, volume
ema20, ema50, ema200, sma20, sma50, sma200
rsi, roc, cci, mfi, cmf, atr, adx
rvol10, rvol20
finalscore, buyscore, sellscore
supertrend, supertrendscore
smc, smcscore
pattern, signal
higher high, higher low, lower high, lower low, hh, hl, lh, ll
vwap
```

## Example queries

```text
latest close > latest ema 20 and latest rsi 14 > 60 and rvol20 > 1.5
```

```text
latest close > latest ema 50 and supertrend = buy and higher high
```

```text
latest rsi 14 between 55 and 70 and cmf > 0 and mfi > 55
```

```text
greatest(latest rsi 14, latest mfi 14) > 60 and latest close > latest ema 20
```

```text
least(rvol10, rvol20) > 1.2 and abs(cmf) > 0.05
```
