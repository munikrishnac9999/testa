using System.Data;
using System.Globalization;
using System.Text.RegularExpressions;
using wpfCSharp_LiveOnly_WPF.Models;

namespace wpfCSharp_LiveOnly_WPF.Services;

public sealed class ChartinkQueryCondition
{
    public string Join { get; set; } = "AND";
    public string Left { get; set; } = string.Empty;
    public string Operator { get; set; } = string.Empty;
    public string Right { get; set; } = string.Empty;
    public string Display => string.IsNullOrWhiteSpace(Right) ? $"{Join} {Left}" : $"{Join} {Left} {Operator} {Right}";
}

public sealed class ChartinkQueryPlan
{
    public string OriginalQuery { get; set; } = string.Empty;
    public List<ChartinkQueryCondition> Conditions { get; set; } = new();
    public string Summary => Conditions.Count == 0
        ? "No valid query conditions detected."
        : string.Join(" | ", Conditions.Select(x => x.Display));
}

public sealed class ChartinkUserFunction
{
    public string Name { get; set; } = "myfunc";
    public string Expression { get; set; } = "x";
    public string Description { get; set; } = "User-defined numeric function";
    public string Display => $"{Name}(...) = {Expression}";
}

public sealed class ChartinkQueryEngineService
{
    private static List<ChartinkUserFunction> _customFunctions = new();

    public void SetCustomFunctions(IEnumerable<ChartinkUserFunction> functions)
    {
        _customFunctions = functions
            .Where(x => !string.IsNullOrWhiteSpace(x.Name) && !string.IsNullOrWhiteSpace(x.Expression))
            .Select(x => new ChartinkUserFunction
            {
                Name = x.Name.Trim(),
                Expression = x.Expression.Trim(),
                Description = x.Description
            })
            .ToList();
    }

    public List<string> Examples { get; } = new()
    {
        "latest close > latest ema 20 and latest rsi 14 > 60 and rvol20 > 1.5",
        "latest close > latest ema 50 and supertrend = buy and higher high",
        "latest rsi 14 between 55 and 70 and cmf > 0 and mfi > 55",
        "latest close > latest vwap and finalscore >= 70 and rvol20 >= 1.2",
        "supertrend = sell and latest rsi 14 < 45 and lower low",
        "finalscore <= 40 and rvol20 >= 1.2 and cmf < 0",
        "greatest(latest rsi 14, latest mfi 14) > 60 and latest close > latest ema 20",
        "least(rvol10, rvol20) > 1.2 and abs(cmf) > 0.05",
        "count(20, 1 where latest close > latest ema 20) >= 1",
        "bullpower(rsi, mfi, rvol20) > 75"
    };

    public ChartinkQueryPlan Parse(string query)
    {
        var plan = new ChartinkQueryPlan { OriginalQuery = query ?? string.Empty };
        if (string.IsNullOrWhiteSpace(query)) return plan;

        string normalized = NormalizeQuery(query);
        string[] parts = Regex.Split(normalized, "\\s+(and|or)\\s+", RegexOptions.IgnoreCase);
        string join = "AND";

        foreach (string raw in parts.Select(x => x.Trim()).Where(x => !string.IsNullOrWhiteSpace(x)))
        {
            if (raw.Equals("and", StringComparison.OrdinalIgnoreCase) || raw.Equals("or", StringComparison.OrdinalIgnoreCase))
            {
                join = raw.ToUpperInvariant();
                continue;
            }

            var condition = ParseCondition(raw, join);
            if (condition != null)
                plan.Conditions.Add(condition);

            join = "AND";
        }

        return plan;
    }

    public List<StockScanResult> Execute(IEnumerable<StockScanResult> rows, string query, out ChartinkQueryPlan plan)
    {
        var parsedPlan = Parse(query);
        plan = parsedPlan;

        var conditions = parsedPlan.Conditions;
        if (conditions.Count == 0)
            return rows.OrderByDescending(x => x.FinalScore).ToList();

        return rows.Where(row => Evaluate(row, conditions))
            .OrderByDescending(x => x.FinalScore)
            .ThenByDescending(x => Math.Max(x.Rvol10, x.Rvol20))
            .ToList();
    }

    private static ChartinkQueryCondition? ParseCondition(string text, string join)
    {
        text = text.Trim();

        if (IsBooleanAlias(text))
            return new ChartinkQueryCondition { Join = join, Left = text, Operator = "is", Right = "true" };

        var between = Regex.Match(text, "^(?<left>.+?)\\s+between\\s+(?<a>-?\\d+(\\.\\d+)?)\\s+and\\s+(?<b>-?\\d+(\\.\\d+)?)$", RegexOptions.IgnoreCase);
        if (between.Success)
            return new ChartinkQueryCondition { Join = join, Left = between.Groups["left"].Value.Trim(), Operator = "between", Right = between.Groups["a"].Value + ":" + between.Groups["b"].Value };

        string opPattern = "crossed above|crossed below|greater than equal to|less than equal to|greater than|less than|above|below|contains|equals|is|>=|<=|!=|=|>|<";
        var match = Regex.Match(text, $"^(?<left>.+?)\\s+(?<op>{opPattern})\\s+(?<right>.+)$", RegexOptions.IgnoreCase);
        if (!match.Success) return null;

        return new ChartinkQueryCondition
        {
            Join = join,
            Left = match.Groups["left"].Value.Trim(),
            Operator = NormalizeOperator(match.Groups["op"].Value.Trim()),
            Right = match.Groups["right"].Value.Trim()
        };
    }

    private static bool Evaluate(StockScanResult row, IReadOnlyList<ChartinkQueryCondition> conditions)
    {
        bool result = true;
        bool first = true;

        foreach (var condition in conditions)
        {
            bool current = EvaluateCondition(row, condition);
            if (first)
            {
                result = current;
                first = false;
                continue;
            }

            result = condition.Join.Equals("OR", StringComparison.OrdinalIgnoreCase) ? result || current : result && current;
        }

        return result;
    }

    private static bool EvaluateCondition(StockScanResult row, ChartinkQueryCondition c)
    {
        string leftKey = FieldKey(c.Left);
        string op = c.Operator;
        string rightText = Clean(c.Right);

        if (IsBooleanField(leftKey))
            return GetBoolean(row, leftKey) == ParseBoolean(rightText);

        if (IsStringField(leftKey))
        {
            string leftString = GetString(row, leftKey);
            string rightString = rightText.Replace("'", string.Empty).Replace("\"", string.Empty);
            return op switch
            {
                "!=" => !leftString.Contains(rightString, StringComparison.OrdinalIgnoreCase),
                "contains" => leftString.Contains(rightString, StringComparison.OrdinalIgnoreCase),
                _ => leftString.Contains(rightString, StringComparison.OrdinalIgnoreCase)
            };
        }

        if (op == "between")
        {
            var bounds = rightText.Split(':');
            if (bounds.Length == 2 && decimal.TryParse(bounds[0], out decimal low) && decimal.TryParse(bounds[1], out decimal high))
            {
                decimal value = GetNumber(row, leftKey);
                return value >= low && value <= high;
            }
            return false;
        }

        // Special field-to-field comparisons such as close > ema20 or close > vwap.
        if (rightText.Contains("vwap", StringComparison.OrdinalIgnoreCase) && leftKey == "Ltp")
            return op is ">" or ">=" ? row.VwapStatus.Contains("Above", StringComparison.OrdinalIgnoreCase) : row.VwapStatus.Contains("Below", StringComparison.OrdinalIgnoreCase);

        decimal left = EvaluateNumericExpression(row, c.Left);
        decimal right = EvaluateNumericExpression(row, rightText);

        return op switch
        {
            ">" => left > right,
            ">=" => left >= right,
            "<" => left < right,
            "<=" => left <= right,
            "=" => left == right,
            "!=" => left != right,
            _ => left >= right
        };
    }

    private static decimal EvaluateNumericExpression(StockScanResult row, string expression)
    {
        string exp = Clean(expression).Trim();
        if (Regex.IsMatch(exp, "^-?\\d+(\\.\\d+)?$") && decimal.TryParse(exp, out decimal numericOnly))
            return numericOnly;

        decimal? customValue = EvaluateCustomFunction(row, exp);
        if (customValue.HasValue)
            return customValue.Value;

        if ((exp.StartsWith("greatest(", StringComparison.OrdinalIgnoreCase) || exp.StartsWith("max(", StringComparison.OrdinalIgnoreCase)) && exp.EndsWith(")"))
        {
            string inner = exp[(exp.IndexOf('(') + 1)..exp.LastIndexOf(')')];
            var values = SplitArgs(inner).Select(x => EvaluateNumericExpression(row, x)).ToList();
            return values.Count == 0 ? 0 : values.Max();
        }

        if ((exp.StartsWith("least(", StringComparison.OrdinalIgnoreCase) || exp.StartsWith("min(", StringComparison.OrdinalIgnoreCase)) && exp.EndsWith(")"))
        {
            string inner = exp[(exp.IndexOf('(') + 1)..exp.LastIndexOf(')')];
            var values = SplitArgs(inner).Select(x => EvaluateNumericExpression(row, x)).ToList();
            return values.Count == 0 ? 0 : values.Min();
        }

        if (exp.StartsWith("abs(", StringComparison.OrdinalIgnoreCase) && exp.EndsWith(")"))
        {
            string inner = exp[(exp.IndexOf('(') + 1)..exp.LastIndexOf(')')];
            return Math.Abs(EvaluateNumericExpression(row, inner));
        }

        if ((exp.StartsWith("count(", StringComparison.OrdinalIgnoreCase) || exp.StartsWith("countstreak(", StringComparison.OrdinalIgnoreCase)) && exp.EndsWith(")"))
        {
            string inner = exp[(exp.IndexOf('(') + 1)..exp.LastIndexOf(')')];
            int whereIndex = inner.IndexOf("where", StringComparison.OrdinalIgnoreCase);
            string conditionText = whereIndex >= 0 ? inner[(whereIndex + 5)..] : inner;
            var condition = ParseCondition(conditionText.Trim(), "AND");
            return condition != null && EvaluateCondition(row, condition) ? 1 : 0;
        }

        foreach (var op in new[] { " * ", " / ", " + ", " - " })
        {
            int idx = exp.IndexOf(op, StringComparison.OrdinalIgnoreCase);
            if (idx > 0)
            {
                decimal left = EvaluateNumericExpression(row, exp[..idx]);
                decimal right = EvaluateNumericExpression(row, exp[(idx + op.Length)..]);
                return op.Trim() switch
                {
                    "*" => left * right,
                    "/" => right == 0 ? 0 : left / right,
                    "+" => left + right,
                    "-" => left - right,
                    _ => left
                };
            }
        }

        if (decimal.TryParse(ExtractNumber(exp), out decimal number) && Regex.IsMatch(exp, "^[^a-zA-Z]*-?\\d+(\\.\\d+)?[^a-zA-Z]*$"))
            return number;

        return GetNumber(row, FieldKey(exp));
    }

    private static decimal? EvaluateCustomFunction(StockScanResult row, string exp)
    {
        foreach (var function in _customFunctions)
        {
            if (!exp.StartsWith(function.Name + "(", StringComparison.OrdinalIgnoreCase) || !exp.EndsWith(")"))
                continue;

            string inner = exp[(exp.IndexOf('(') + 1)..exp.LastIndexOf(')')];
            var args = SplitArgs(inner).Select(x => EvaluateNumericExpression(row, x)).ToList();
            string body = function.Expression;
            string[] tokens = { "x", "y", "z", "a", "b", "c" };
            for (int i = 0; i < tokens.Length; i++)
            {
                decimal value = i < args.Count ? args[i] : 0m;
                string number = value.ToString(CultureInfo.InvariantCulture);
                body = Regex.Replace(body, $"\\b{tokens[i]}\\b", number, RegexOptions.IgnoreCase);
                body = Regex.Replace(body, $"\\barg{i + 1}\\b", number, RegexOptions.IgnoreCase);
            }

            try
            {
                object computed = new DataTable().Compute(body, null);
                return Convert.ToDecimal(computed, CultureInfo.InvariantCulture);
            }
            catch
            {
                return EvaluateNumericExpression(row, body);
            }
        }

        return null;
    }

    private static List<string> SplitArgs(string inner)
    {
        var args = new List<string>();
        int depth = 0;
        int start = 0;
        for (int i = 0; i < inner.Length; i++)
        {
            if (inner[i] == '(') depth++;
            if (inner[i] == ')') depth--;
            if (inner[i] == ',' && depth == 0)
            {
                args.Add(inner[start..i].Trim());
                start = i + 1;
            }
        }
        args.Add(inner[start..].Trim());
        return args.Where(x => !string.IsNullOrWhiteSpace(x)).ToList();
    }

    private static string NormalizeQuery(string query)
    {
        return query
            .Replace("\r", " ")
            .Replace("\n", " ")
            .Replace("stock passes all of the below filters", string.Empty, StringComparison.OrdinalIgnoreCase)
            .Replace("cash segment", string.Empty, StringComparison.OrdinalIgnoreCase)
            .Trim();
    }

    private static string Clean(string value)
    {
        return value.ToLowerInvariant()
            .Replace("latest", string.Empty)
            .Replace("current", string.Empty)
            .Replace("minute", string.Empty)
            .Replace("min", string.Empty)
            .Replace("daily", string.Empty)
            .Replace("day", string.Empty)
            .Replace("period", string.Empty)
            .Trim();
    }

    private static string FieldKey(string field)
    {
        string f = Clean(field).Replace(" ", string.Empty).Replace("_", string.Empty).Replace("-", string.Empty);

        if (f.Contains("ema200") || f.Contains("sma200")) return "Ema200";
        if (f.Contains("ema50") || f.Contains("sma50")) return "Ema50";
        if (f.Contains("ema20") || f.Contains("sma20")) return "Ema20";
        if (f.Contains("adx")) return "Adx";
        if (f.Contains("open")) return "Open";
        if (f.Contains("high")) return "High";
        if (f.Contains("low")) return "Low";
        if (f.Contains("close") || f.Contains("ltp") || f.Contains("price")) return "Ltp";
        if (f.Contains("rsi")) return "Rsi";
        if (f.Contains("rvol10")) return "Rvol10";
        if (f == "volume" || f.Contains("volumelatest")) return "Volume";
        if (f.Contains("rvol20") || f.Contains("volume")) return "Rvol20";
        if (f.Contains("mfi")) return "Mfi";
        if (f.Contains("cmf")) return "Cmf";
        if (f.Contains("cci")) return "Cci";
        if (f.Contains("roc")) return "Roc";
        if (f.Contains("atr")) return "Atr";
        if (f.Contains("change")) return "ChangePercent";
        if (f.Contains("supertrend") && f.Contains("score")) return "SuperTrendScore";
        if (f.Contains("supertrend")) return "SuperTrend";
        if (f.Contains("finalscore") || f == "score") return "FinalScore";
        if (f.Contains("buyscore")) return "BuyScore";
        if (f.Contains("sellscore")) return "SellScore";
        if (f.Contains("smc") && f.Contains("score")) return "SmcScore";
        if (f.Contains("smc")) return "SmcSignal";
        if (f.Contains("pattern")) return "Pattern";
        if (f.Contains("signal")) return "Signal";
        if (f.Contains("higherhigh") || f == "hh") return "HigherHigh";
        if (f.Contains("higherlow") || f == "hl") return "HigherLow";
        if (f.Contains("lowerhigh") || f == "lh") return "LowerHigh";
        if (f.Contains("lowerlow") || f == "ll") return "LowerLow";
        if (f.Contains("vwap")) return "VwapStatus";
        return f.Length == 0 ? "FinalScore" : f;
    }

    private static decimal GetNumber(StockScanResult row, string key) => key switch
    {
        "Open" => row.Open,
        "High" => row.High,
        "Low" => row.Low,
        "Volume" => row.Volume,
        "Ltp" => row.Ltp,
        "Ema20" => row.Ema20,
        "Ema50" => row.Ema50,
        "Ema200" => row.Ema200,
        "Adx" => row.Adx,
        "Rsi" => row.Rsi,
        "Roc" => row.Roc,
        "Cci" => row.Cci,
        "Mfi" => row.Mfi,
        "Cmf" => row.Cmf,
        "Rvol10" => row.Rvol10,
        "Rvol20" => row.Rvol20,
        "Atr" => row.Atr,
        "FinalScore" => row.FinalScore,
        "BuyScore" => row.BuyScore,
        "SellScore" => row.SellScore,
        "SuperTrendScore" => row.SuperTrendScore,
        "SmcScore" => row.SmcScore,
        "ChangePercent" => row.ChangePercent,
        _ => 0m
    };

    private static string GetString(StockScanResult row, string key) => key switch
    {
        "SuperTrend" => row.SuperTrend,
        "Signal" => row.Signal,
        "Pattern" => row.Pattern,
        "SmcSignal" => row.SmcSignal,
        "VwapStatus" => row.VwapStatus,
        _ => string.Empty
    };

    private static bool GetBoolean(StockScanResult row, string key) => key switch
    {
        "HigherHigh" => row.HigherHigh,
        "HigherLow" => row.HigherLow,
        "LowerHigh" => row.LowerHigh,
        "LowerLow" => row.LowerLow,
        _ => false
    };

    private static bool IsBooleanAlias(string text) => IsBooleanField(FieldKey(text));
    private static bool IsBooleanField(string key) => key is "HigherHigh" or "HigherLow" or "LowerHigh" or "LowerLow";
    private static bool IsStringField(string key) => key is "SuperTrend" or "Signal" or "Pattern" or "SmcSignal" or "VwapStatus";
    private static bool ParseBoolean(string value) => !(value.Contains("false") || value.Contains("no") || value.Contains("0"));

    private static string NormalizeOperator(string op)
    {
        string o = op.ToLowerInvariant();
        return o switch
        {
            "above" or "greater than" or "crossed above" => ">",
            "below" or "less than" or "crossed below" => "<",
            "greater than equal to" => ">=",
            "less than equal to" => "<=",
            "equals" or "is" => "=",
            _ => op
        };
    }

    private static string ExtractNumber(string value)
    {
        return new string(value.Select(ch => char.IsDigit(ch) || ch == '.' || ch == '-' ? ch : ' ').ToArray())
            .Split(' ', StringSplitOptions.RemoveEmptyEntries)
            .FirstOrDefault() ?? string.Empty;
    }
}
