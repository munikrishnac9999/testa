using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using System.Windows.Threading;
using wpfCSharp_LiveOnly_WPF.Models;
using wpfCSharp_LiveOnly_WPF.Services;
namespace wpfCSharp_LiveOnly_WPF.ViewModels;
public sealed class MainViewModel : INotifyPropertyChanged
{
    private readonly FyersApiClient _api = new();
    private readonly FyersAuthService _auth = new();
    private readonly IndicatorService _ind = new();
    private readonly SmartMoneyService _smart = new();
    private readonly ChartinkScannerService _chartink = new();
    private readonly ChartinkRuleEngine _chartinkRuleEngine = new();
    private readonly ChartinkStrategyAssistantService _chartinkStrategyAssistant = new();
    private readonly ChartinkQueryEngineService _chartinkQueryEngine = new();
    private readonly ChartinkAlertDeliveryService _alertDelivery = new();
    private readonly ChartinkTemplateService _chartinkTemplateService = new();
    private readonly ChartinkBacktestService _chartinkBacktestService = new();
    private readonly PaperTradingService _paper = new();
    private readonly IBrokerOrderService _brokerOrders = new RealOrderDisabledService();
    private FyersHistoryService? _history;
    private FyersOptionChainService? _chain;
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(2) };
    private readonly DispatcherTimer _stockScannerAutoTimer = new() { Interval = TimeSpan.FromSeconds(60) };
    private string _lastCandlestickAlertKey = string.Empty;
    private string _lastDemaTemaAlertKey = string.Empty;
    private string _lastAdvancedIndicatorAlertKey = string.Empty;
    private string _lastSmcAlertKey = string.Empty;
    private string _lastOrderBlockAlertKey = string.Empty;
    private string _lastSuperTrendAlertKey = string.Empty;
    private string _lastQueryDeliveryKey = string.Empty;
    public ObservableCollection<Candle> Candles { get; } = new();
    public ObservableCollection<OptionChainRow> OptionRows { get; } = new();
    public ObservableCollection<OptionChainRow> LongBuildRows { get; } = new();
    public ObservableCollection<OptionChainRow> ShortBuildRows { get; } = new();
    public ObservableCollection<OptionChainRow> LongUnwindRows { get; } = new();
    public ObservableCollection<OptionChainRow> ShortCoverRows { get; } = new();
    public ObservableCollection<AlertMessage> Alerts { get; } = new();
    public ObservableCollection<StockScanResult> StockScanResults { get; } = new();
    public ObservableCollection<StockScanResult> BuyScanResults { get; } = new();
    public ObservableCollection<StockScanResult> SellScanResults { get; } = new();
    public ObservableCollection<StockScanResult> WaitScanResults { get; } = new();
    public ObservableCollection<StockScanResult> HigherHighScanResults { get; } = new();
    public ObservableCollection<StockScanResult> HigherLowScanResults { get; } = new();
    public ObservableCollection<StockScanResult> LowerHighScanResults { get; } = new();
    public ObservableCollection<StockScanResult> LowerLowScanResults { get; } = new();

    public ObservableCollection<ChartinkScannerSummary> ChartinkScannerSummaries { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkBullishBreakoutResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkBearishBreakdownResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkHighVolumeBreakoutResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkHighVolumeBreakdownResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkSuperTrendBuyResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkSuperTrendSellResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkRsiOversoldResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkRsiOverboughtResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkMomentumBuyResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkMomentumSellResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkSmcBuyResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkSmcSellResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkBullishPatternResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkBearishPatternResults { get; } = new();
    public ObservableCollection<StockScanResult> CustomChartinkResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkQueryResults { get; } = new();
    public ObservableCollection<ChartinkFilterRule> ChartinkRules { get; } = new();
    public ObservableCollection<ChartinkScanTemplate> ChartinkTemplates { get; } = new();
    public ObservableCollection<ChartinkBacktestResult> ChartinkBacktestResults { get; } = new();
    public ObservableCollection<string> ChartinkIntelligenceSuggestions { get; } = new();
    public ObservableCollection<string> ChartinkQueryExamples { get; } = new();
    public ObservableCollection<ChartinkUserFunction> ChartinkCustomFunctions { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkRvolSpikeResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkMoneyFlowBuyResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkMoneyFlowSellResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkUptrendPullbackResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkDowntrendPullbackResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkIntradayStrongResults { get; } = new();
    public ObservableCollection<StockScanResult> ChartinkIntradayWeakResults { get; } = new();

    private CancellationTokenSource? _stockScanCts;

    public ObservableCollection<string> TradingModes { get; } = new() { "Paper Trading", "Manual Trading", "Real Trading" };
    public ObservableCollection<PaperTrade> PaperTrades => _paper.Trades;
    public PaperTradingSummary PaperSummary => _paper.Summary;

    private int _selectedMainTabIndex;
    public int SelectedMainTabIndex
    {
        get => _selectedMainTabIndex;
        set { _selectedMainTabIndex = Math.Max(0, value); OnPropertyChanged(); }
    }

    private string _selectedTradingMode = "Paper Trading";
    public string SelectedTradingMode
    {
        get => _selectedTradingMode;
        set
        {
            if (string.IsNullOrWhiteSpace(value)) return;
            _selectedTradingMode = value;
            ApplyTradingMode(value, announce: true);
            OnPropertyChanged();
            OnPropertyChanged(nameof(IsPaperTradingSelected));
            OnPropertyChanged(nameof(IsManualTradingSelected));
            OnPropertyChanged(nameof(IsRealTradingSelected));
            OnPropertyChanged(nameof(TradingModeDescription));
        }
    }

    public bool IsPaperTradingSelected
    {
        get => SelectedTradingMode == "Paper Trading";
        set { if (value) SelectedTradingMode = "Paper Trading"; }
    }

    public bool IsManualTradingSelected
    {
        get => SelectedTradingMode == "Manual Trading";
        set { if (value) SelectedTradingMode = "Manual Trading"; }
    }

    public bool IsRealTradingSelected
    {
        get => SelectedTradingMode == "Real Trading";
        set { if (value) SelectedTradingMode = "Real Trading"; }
    }

    private string _tradingStatus = "Paper Trading active. No broker order execution.";
    public string TradingStatus { get => _tradingStatus; set { _tradingStatus = value; OnPropertyChanged(); } }

    private string _tradingStatusBrush = "#19C37D";
    public string TradingStatusBrush { get => _tradingStatusBrush; set { _tradingStatusBrush = value; OnPropertyChanged(); } }

    private bool _realTradingConfirmed;
    public bool RealTradingConfirmed { get => _realTradingConfirmed; set { _realTradingConfirmed = value; OnPropertyChanged(); } }

    public bool BrokerOrderServiceConnected => _brokerOrders.IsConnected;

    private string _lastRealOrderStatus = "No real order attempted.";
    public string LastRealOrderStatus { get => _lastRealOrderStatus; set { _lastRealOrderStatus = value; OnPropertyChanged(); } }

    private string _lastRealOrderStatusBrush = "#93A4BD";
    public string LastRealOrderStatusBrush { get => _lastRealOrderStatusBrush; set { _lastRealOrderStatusBrush = value; OnPropertyChanged(); } }

    public bool EnableAutoRealTrade
    {
        get => EnableRealTrade;
        set
        {
            EnableRealTrade = value;
            OnPropertyChanged(nameof(EnableAutoRealTrade));
        }
    }

    private decimal _realTradeQuantity = 1;
    public decimal RealTradeQuantity
    {
        get => _realTradeQuantity;
        set { _realTradeQuantity = value <= 0 ? 1 : value; OnPropertyChanged(); }
    }

    private int _realTradeBuyThreshold = 75;
    public int RealTradeBuyThreshold
    {
        get => _realTradeBuyThreshold;
        set { _realTradeBuyThreshold = Math.Max(1, Math.Min(100, value)); OnPropertyChanged(); }
    }

    private int _realTradeSellThreshold = 35;
    public int RealTradeSellThreshold
    {
        get => _realTradeSellThreshold;
        set { _realTradeSellThreshold = Math.Max(0, Math.Min(99, value)); OnPropertyChanged(); }
    }

    public string TradingModeDescription => SelectedTradingMode switch
    {
        "Paper Trading" => "Auto paper trades, paper PnL, trade journal and alerts only.",
        "Manual Trading" => "Manual simulated trades only. No broker API order is sent.",
        "Real Trading" => "Real Trading requires confirmation. Current build keeps broker execution locked and uses preview status only.",
        _ => "Select a trading mode."
    };
    public ICommand LoginCommand { get; }
    public ICommand StartCommand { get; }
    public ICommand StopCommand { get; }
    public ICommand TimeframeCommand { get; }
    public ICommand TradingModeCommand { get; }
    public ICommand ScanStocksCommand { get; }
    public ICommand StopStockScanCommand { get; }
    public ICommand ToggleAutoStockScannerCommand { get; }
    public ICommand OpenDashboardCommand { get; }
    public ICommand OpenSymbolInDashboardCommand { get; }
    public ICommand RunChartinkScannersCommand { get; }
    public ICommand ExportChartinkResultsCommand { get; }
    public ICommand AddChartinkRuleCommand { get; }
    public ICommand ClearChartinkRulesCommand { get; }
    public ICommand RunCustomChartinkCommand { get; }
    public ICommand SaveChartinkTemplateCommand { get; }
    public ICommand LoadChartinkTemplateCommand { get; }
    public ICommand AddMagicChartinkRuleCommand { get; }
    public ICommand RunChartinkBacktestCommand { get; }
    public ICommand ExportChartinkExcelCommand { get; }
    public ICommand RunSmartStrategyCommand { get; }
    public ICommand UseChartinkSuggestionCommand { get; }
    public ICommand RunChartinkQueryCommand { get; }
    public ICommand UseChartinkQueryExampleCommand { get; }
    public ICommand SendQueryAlertsCommand { get; }
    public ICommand TestAlertChannelsCommand { get; }
    public ICommand AddCustomFunctionCommand { get; }
    public ICommand ClearCustomFunctionsCommand { get; }
    public string AppId { get => _api.AppId; set { _api.AppId = value; OnPropertyChanged(); } }
    private string _appSecret = string.Empty; public string AppSecret { get => _appSecret; set { _appSecret = value; OnPropertyChanged(); } }
    private string _authCode = string.Empty; public string AuthCode { get => _authCode; set { _authCode = value; OnPropertyChanged(); } }
    private string _symbol = "NSE:NIFTY50-INDEX"; public string Symbol { get => _symbol; set { _symbol = value; OnPropertyChanged(); } }
    private string _resolution = "5";
    public string Resolution
    {
        get => _resolution;
        set
        {
            _resolution = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(TimeframeLabel));
        }
    }
    public string TimeframeLabel => Resolution switch
    {
        "60" => "1h",
        "120" => "120m",
        "180" => "180m",
        "240" => "240m",
        "280" => "280m",
        _ => string.IsNullOrWhiteSpace(Resolution) ? "-" : Resolution + "m"
    };
    // 50 gives a much broader current-expiry scan. Use 0 to request all current-expiry strikes if FYERS returns it.
    private int _strikeCount = 50; public int StrikeCount { get => _strikeCount; set { _strikeCount = value; OnPropertyChanged(); } }
    private string _status = "Not logged in"; public string Status { get => _status; set { _status = value; OnPropertyChanged(); } }
    private decimal _spot; public decimal Spot { get => _spot; set { _spot = value; OnPropertyChanged(); } }
    private string _spotChangeText = "0.00 pts (0.00%)";
    public string SpotChangeText { get => _spotChangeText; set { _spotChangeText = value; OnPropertyChanged(); } }
    private string _spotChangeBrush = "#93A4BD";
    public string SpotChangeBrush { get => _spotChangeBrush; set { _spotChangeBrush = value; OnPropertyChanged(); } }
    private string _expiry = "-"; public string Expiry { get => _expiry; set { _expiry = value; OnPropertyChanged(); } }
    private TrendSnapshot _trend = new(); public TrendSnapshot Trend { get => _trend; set { _trend = value; OnPropertyChanged(); } }
    private SmartMoneySnapshot _score = new(); public SmartMoneySnapshot Score { get => _score; set { _score = value; OnPropertyChanged(); } }
    private bool _enablePaperTrading = true;
    public bool EnablePaperTrading
    {
        get => _enablePaperTrading;
        set
        {
            _enablePaperTrading = value;
            _paper.IsEnabled = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(PaperSummary));
        }
    }
    public bool EnableAutoPaperTrade
    {
        get => EnablePaperTrading;
        set
        {
            EnablePaperTrading = value;
            OnPropertyChanged(nameof(EnableAutoPaperTrade));
            if (value)
            {
                SelectedTradingMode = "Paper Trading";
                TradingStatus = "Auto Paper Trade enabled. Paper simulation active.";
                TradingStatusBrush = "#19C37D";
            }
            else if (SelectedTradingMode == "Paper Trading")
            {
                TradingStatus = "Auto Paper Trade disabled. Paper simulation paused.";
                TradingStatusBrush = "#FFC857";
            }
        }
    }

    private bool _enableRealTrade;
    public bool EnableRealTrade
    {
        get => _enableRealTrade;
        set
        {
            _enableRealTrade = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(EnableAutoRealTrade));
            if (value)
            {
                SelectedTradingMode = "Real Trading";
                TradingStatus = RealTradingConfirmed
                    ? "Real Trade enabled and confirmed. Execution remains locked until broker order service is implemented."
                    : "Real Trade enabled. Confirmation required before any real-trade workflow can be armed.";
                TradingStatusBrush = "#FFC857";
                AddAlert("Enable Auto Real Trade selected. Confirmation is required. No broker order API is connected.", "#FFC857");
            }
            else
            {
                RealTradingConfirmed = false;
                if (SelectedTradingMode == "Real Trading") SelectedTradingMode = "Paper Trading";
                TradingStatus = "Auto Real Trade disabled. Returned to safe paper/simulation mode.";
                TradingStatusBrush = "#19C37D";
                AddAlert("Auto Real Trade disabled. Safe simulation mode active.", "#19C37D");
            }
        }
    }


    private int _paperBuyThreshold = 75;
    public int PaperBuyThreshold
    {
        get => _paperBuyThreshold;
        set { _paperBuyThreshold = Math.Max(0, Math.Min(100, value)); OnPropertyChanged(); }
    }

    private int _paperSellThreshold = 35;
    public int PaperSellThreshold
    {
        get => _paperSellThreshold;
        set { _paperSellThreshold = Math.Max(0, Math.Min(99, value)); OnPropertyChanged(); }
    }

    private decimal _paperQuantity = 1;
    public decimal PaperQuantity
    {
        get => _paperQuantity;
        set
        {
            _paperQuantity = value;
            _paper.Quantity = _paperQuantity;
            OnPropertyChanged();
            OnPropertyChanged(nameof(PaperSummary));
        }
    }
    private int _strategyFinalBuyThreshold = 75;
    public int StrategyFinalBuyThreshold
    {
        get => _strategyFinalBuyThreshold;
        set { _strategyFinalBuyThreshold = Clamp(value, 1, 100); OnPropertyChanged(); }
    }

    private int _strategyFinalSellThreshold = 35;
    public int StrategyFinalSellThreshold
    {
        get => _strategyFinalSellThreshold;
        set { _strategyFinalSellThreshold = Clamp(value, 0, 99); OnPropertyChanged(); }
    }

    private int _trendBuyThreshold = 65;
    public int TrendBuyThreshold
    {
        get => _trendBuyThreshold;
        set { _trendBuyThreshold = Clamp(value, 1, 100); OnPropertyChanged(); }
    }

    private int _trendSellThreshold = 35;
    public int TrendSellThreshold
    {
        get => _trendSellThreshold;
        set { _trendSellThreshold = Clamp(value, 0, 99); OnPropertyChanged(); }
    }

    private int _momentumBuyThreshold = 65;
    public int MomentumBuyThreshold
    {
        get => _momentumBuyThreshold;
        set { _momentumBuyThreshold = Clamp(value, 1, 100); OnPropertyChanged(); }
    }

    private int _momentumSellThreshold = 35;
    public int MomentumSellThreshold
    {
        get => _momentumSellThreshold;
        set { _momentumSellThreshold = Clamp(value, 0, 99); OnPropertyChanged(); }
    }

    private int _moneyFlowBuyThreshold = 65;
    public int MoneyFlowBuyThreshold
    {
        get => _moneyFlowBuyThreshold;
        set { _moneyFlowBuyThreshold = Clamp(value, 1, 100); OnPropertyChanged(); }
    }

    private int _moneyFlowSellThreshold = 35;
    public int MoneyFlowSellThreshold
    {
        get => _moneyFlowSellThreshold;
        set { _moneyFlowSellThreshold = Clamp(value, 0, 99); OnPropertyChanged(); }
    }

    private int _optionBuyThreshold = 65;
    public int OptionBuyThreshold
    {
        get => _optionBuyThreshold;
        set { _optionBuyThreshold = Clamp(value, 1, 100); OnPropertyChanged(); }
    }

    private int _optionSellThreshold = 35;
    public int OptionSellThreshold
    {
        get => _optionSellThreshold;
        set { _optionSellThreshold = Clamp(value, 0, 99); OnPropertyChanged(); }
    }

    private int _smcBuyThreshold = 65;
    public int SmcBuyThreshold
    {
        get => _smcBuyThreshold;
        set { _smcBuyThreshold = Clamp(value, 1, 100); OnPropertyChanged(); }
    }

    private int _smcSellThreshold = 35;
    public int SmcSellThreshold
    {
        get => _smcSellThreshold;
        set { _smcSellThreshold = Clamp(value, 0, 99); OnPropertyChanged(); }
    }

    private int _patternBuyThreshold = 65;
    public int PatternBuyThreshold
    {
        get => _patternBuyThreshold;
        set { _patternBuyThreshold = Clamp(value, 1, 100); OnPropertyChanged(); }
    }

    private int _patternSellThreshold = 35;
    public int PatternSellThreshold
    {
        get => _patternSellThreshold;
        set { _patternSellThreshold = Clamp(value, 0, 99); OnPropertyChanged(); }
    }

    private int _minBuyConfirmations = 4;
    public int MinBuyConfirmations
    {
        get => _minBuyConfirmations;
        set { _minBuyConfirmations = Clamp(value, 1, 6); OnPropertyChanged(); }
    }

    private int _minSellConfirmations = 4;
    public int MinSellConfirmations
    {
        get => _minSellConfirmations;
        set { _minSellConfirmations = Clamp(value, 1, 6); OnPropertyChanged(); }
    }

    private static int Clamp(int value, int min, int max)
    {
        return Math.Max(min, Math.Min(max, value));
    }

    private StrategyThresholdSettings BuildStrategyThresholdSettings()
    {
        return new StrategyThresholdSettings
        {
            FinalBuyThreshold = StrategyFinalBuyThreshold,
            FinalSellThreshold = StrategyFinalSellThreshold,
            TrendBuyThreshold = TrendBuyThreshold,
            TrendSellThreshold = TrendSellThreshold,
            MomentumBuyThreshold = MomentumBuyThreshold,
            MomentumSellThreshold = MomentumSellThreshold,
            MoneyFlowBuyThreshold = MoneyFlowBuyThreshold,
            MoneyFlowSellThreshold = MoneyFlowSellThreshold,
            OptionBuyThreshold = OptionBuyThreshold,
            OptionSellThreshold = OptionSellThreshold,
            SmcBuyThreshold = SmcBuyThreshold,
            SmcSellThreshold = SmcSellThreshold,
            PatternBuyThreshold = PatternBuyThreshold,
            PatternSellThreshold = PatternSellThreshold,
            MinBuyConfirmations = MinBuyConfirmations,
            MinSellConfirmations = MinSellConfirmations
        };
    }

    private string _scannerWatchlistText = "NSE:NIFTY50-INDEX,NSE:RELIANCE-EQ,NSE:TCS-EQ,NSE:HDFCBANK-EQ,NSE:INFY-EQ,NSE:ICICIBANK-EQ,NSE:SBIN-EQ,NSE:AXISBANK-EQ,NSE:LT-EQ,NSE:BHARTIARTL-EQ,NSE:ITC-EQ,NSE:KOTAKBANK-EQ,NSE:HINDUNILVR-EQ,NSE:MARUTI-EQ,NSE:BAJFINANCE-EQ";
    public string ScannerWatchlistText
    {
        get => _scannerWatchlistText;
        set { _scannerWatchlistText = value; OnPropertyChanged(); OnPropertyChanged(nameof(ScannerSymbolCount)); }
    }

    private int _scannerLookbackDays = 5;
    public int ScannerLookbackDays
    {
        get => _scannerLookbackDays;
        set { _scannerLookbackDays = Math.Max(1, Math.Min(30, value)); OnPropertyChanged(); }
    }

    private bool _isStockScannerRunning;
    public bool IsStockScannerRunning
    {
        get => _isStockScannerRunning;
        set { _isStockScannerRunning = value; OnPropertyChanged(); }
    }

    private bool _isAutoStockScannerEnabled;
    public bool IsAutoStockScannerEnabled
    {
        get => _isAutoStockScannerEnabled;
        set
        {
            _isAutoStockScannerEnabled = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(AutoStockScannerButtonText));
            OnPropertyChanged(nameof(AutoStockScannerBrush));
        }
    }

    public string AutoStockScannerButtonText => IsAutoStockScannerEnabled ? "Stop Always Run" : "Always Run Scan";
    public string AutoStockScannerBrush => IsAutoStockScannerEnabled ? "#FF4D4D" : "#19C37D";

    private string _stockScannerStatus = "Scanner ready. Login first, then click Scan All Stocks.";
    public string StockScannerStatus
    {
        get => _stockScannerStatus;
        set { _stockScannerStatus = value; OnPropertyChanged(); }
    }

    private string _stockScannerStatusBrush = "#93A4BD";
    public string StockScannerStatusBrush
    {
        get => _stockScannerStatusBrush;
        set { _stockScannerStatusBrush = value; OnPropertyChanged(); }
    }

    public int ScannerSymbolCount => ParseScannerSymbols().Count;

    private string _chartinkStatus = "Chartink module ready. Run stock scanner first or click Run Chartink Scanners.";
    public string ChartinkStatus
    {
        get => _chartinkStatus;
        set { _chartinkStatus = value; OnPropertyChanged(); }
    }

    private string _chartinkStatusBrush = "#93A4BD";
    public string ChartinkStatusBrush
    {
        get => _chartinkStatusBrush;
        set { _chartinkStatusBrush = value; OnPropertyChanged(); }
    }

    private int _chartinkMinScore = 0;
    public int ChartinkMinScore
    {
        get => _chartinkMinScore;
        set { _chartinkMinScore = Math.Max(0, Math.Min(100, value)); OnPropertyChanged(); }
    }

    private int _chartinkMaxScore = 100;
    public int ChartinkMaxScore
    {
        get => _chartinkMaxScore;
        set { _chartinkMaxScore = Math.Max(0, Math.Min(100, value)); OnPropertyChanged(); }
    }

    private decimal _chartinkMinRvol;
    public decimal ChartinkMinRvol
    {
        get => _chartinkMinRvol;
        set { _chartinkMinRvol = Math.Max(0, value); OnPropertyChanged(); }
    }

    private decimal _chartinkMinRsi = 0;
    public decimal ChartinkMinRsi
    {
        get => _chartinkMinRsi;
        set { _chartinkMinRsi = Math.Max(0, Math.Min(100, value)); OnPropertyChanged(); }
    }

    private decimal _chartinkMaxRsi = 100;
    public decimal ChartinkMaxRsi
    {
        get => _chartinkMaxRsi;
        set { _chartinkMaxRsi = Math.Max(0, Math.Min(100, value)); OnPropertyChanged(); }
    }

    private string _smartStrategyText = "RSI above 60 and RVOL20 above 1.5 and FinalScore above 70";
    public string SmartStrategyText
    {
        get => _smartStrategyText;
        set
        {
            _smartStrategyText = value;
            OnPropertyChanged();
            RefreshChartinkIntelligence();
        }
    }

    private string _smartStrategyPreview = "Type strategy in plain English. Intelligent suggestions will appear automatically.";
    public string SmartStrategyPreview
    {
        get => _smartStrategyPreview;
        set { _smartStrategyPreview = value; OnPropertyChanged(); }
    }

    private string _chartinkQueryText = "latest close > latest ema 20 and latest rsi 14 > 60 and rvol20 > 1.5";
    public string ChartinkQueryText
    {
        get => _chartinkQueryText;
        set
        {
            _chartinkQueryText = value;
            OnPropertyChanged();
            UpdateChartinkQueryPreview();
        }
    }

    private string _chartinkQueryPreview = "Query parser ready.";
    public string ChartinkQueryPreview
    {
        get => _chartinkQueryPreview;
        set { _chartinkQueryPreview = value; OnPropertyChanged(); }
    }

    private bool _enableQueryEmailAlerts;
    public bool EnableQueryEmailAlerts
    {
        get => _enableQueryEmailAlerts;
        set { _enableQueryEmailAlerts = value; OnPropertyChanged(); }
    }

    private bool _enableQuerySmsAlerts;
    public bool EnableQuerySmsAlerts
    {
        get => _enableQuerySmsAlerts;
        set { _enableQuerySmsAlerts = value; OnPropertyChanged(); }
    }

    private string _smtpHost = string.Empty;
    public string SmtpHost
    {
        get => _smtpHost;
        set { _smtpHost = value; OnPropertyChanged(); }
    }

    private int _smtpPort = 587;
    public int SmtpPort
    {
        get => _smtpPort;
        set { _smtpPort = value; OnPropertyChanged(); }
    }

    private bool _smtpEnableSsl = true;
    public bool SmtpEnableSsl
    {
        get => _smtpEnableSsl;
        set { _smtpEnableSsl = value; OnPropertyChanged(); }
    }

    private string _smtpUser = string.Empty;
    public string SmtpUser
    {
        get => _smtpUser;
        set { _smtpUser = value; OnPropertyChanged(); }
    }

    private string _smtpPassword = string.Empty;
    public string SmtpPassword
    {
        get => _smtpPassword;
        set { _smtpPassword = value; OnPropertyChanged(); }
    }

    private string _alertEmailFrom = string.Empty;
    public string AlertEmailFrom
    {
        get => _alertEmailFrom;
        set { _alertEmailFrom = value; OnPropertyChanged(); }
    }

    private string _alertEmailTo = string.Empty;
    public string AlertEmailTo
    {
        get => _alertEmailTo;
        set { _alertEmailTo = value; OnPropertyChanged(); }
    }

    private string _smsWebhookUrl = string.Empty;
    public string SmsWebhookUrl
    {
        get => _smsWebhookUrl;
        set { _smsWebhookUrl = value; OnPropertyChanged(); }
    }

    private string _smsTo = string.Empty;
    public string SmsTo
    {
        get => _smsTo;
        set { _smsTo = value; OnPropertyChanged(); }
    }

    private bool _enableQueryTelegramAlerts;
    public bool EnableQueryTelegramAlerts
    {
        get => _enableQueryTelegramAlerts;
        set { _enableQueryTelegramAlerts = value; OnPropertyChanged(); }
    }

    private string _telegramBotToken = string.Empty;
    public string TelegramBotToken
    {
        get => _telegramBotToken;
        set { _telegramBotToken = value; OnPropertyChanged(); }
    }

    private string _telegramChatId = string.Empty;
    public string TelegramChatId
    {
        get => _telegramChatId;
        set { _telegramChatId = value; OnPropertyChanged(); }
    }

    private int _queryAlertMinScore = 70;
    public int QueryAlertMinScore
    {
        get => _queryAlertMinScore;
        set { _queryAlertMinScore = Math.Max(0, Math.Min(100, value)); OnPropertyChanged(); }
    }

    private int _queryAlertTopN = 5;
    public int QueryAlertTopN
    {
        get => _queryAlertTopN;
        set { _queryAlertTopN = Math.Max(1, Math.Min(50, value)); OnPropertyChanged(); }
    }

    private string _queryAlertStatus = "Telegram query alerts are disabled.";
    public string QueryAlertStatus
    {
        get => _queryAlertStatus;
        set { _queryAlertStatus = value; OnPropertyChanged(); }
    }

    private string _newFunctionName = "bullpower";
    public string NewFunctionName
    {
        get => _newFunctionName;
        set { _newFunctionName = value; OnPropertyChanged(); }
    }

    private string _newFunctionExpression = "(x + y + (z * 20)) / 3";
    public string NewFunctionExpression
    {
        get => _newFunctionExpression;
        set { _newFunctionExpression = value; OnPropertyChanged(); }
    }

    private string _newFunctionDescription = "Combines RSI, MFI and RVOL into a bullish power score";
    public string NewFunctionDescription
    {
        get => _newFunctionDescription;
        set { _newFunctionDescription = value; OnPropertyChanged(); }
    }

    public ObservableCollection<string> ChartinkFieldOptions { get; } = new()
    {
        "FinalScore", "BuyScore", "SellScore", "Rsi", "Roc", "Cci", "Mfi", "Cmf", "Rvol10", "Rvol20", "Atr", "ChangePercent", "SuperTrendScore", "SmcScore"
    };

    public ObservableCollection<string> ChartinkOperatorOptions { get; } = new() { ">", ">=", "<", "<=", "=", "!=" };
    public ObservableCollection<string> ChartinkJoinOptions { get; } = new() { "AND", "OR" };

    private string _newChartinkField = "FinalScore";
    public string NewChartinkField
    {
        get => _newChartinkField;
        set { _newChartinkField = value; OnPropertyChanged(); }
    }

    private string _newChartinkOperator = ">=";
    public string NewChartinkOperator
    {
        get => _newChartinkOperator;
        set { _newChartinkOperator = value; OnPropertyChanged(); }
    }

    private decimal _newChartinkValue = 70;
    public decimal NewChartinkValue
    {
        get => _newChartinkValue;
        set { _newChartinkValue = value; OnPropertyChanged(); }
    }

    private string _newChartinkJoin = "AND";
    public string NewChartinkJoin
    {
        get => _newChartinkJoin;
        set { _newChartinkJoin = value; OnPropertyChanged(); }
    }

    private string _chartinkTemplateName = "My Scanner";
    public string ChartinkTemplateName
    {
        get => _chartinkTemplateName;
        set { _chartinkTemplateName = value; OnPropertyChanged(); }
    }

    private ChartinkScanTemplate? _selectedChartinkTemplate;
    public ChartinkScanTemplate? SelectedChartinkTemplate
    {
        get => _selectedChartinkTemplate;
        set { _selectedChartinkTemplate = value; OnPropertyChanged(); }
    }

    private string _magicChartinkText = "RSI above 60";
    public string MagicChartinkText
    {
        get => _magicChartinkText;
        set { _magicChartinkText = value; OnPropertyChanged(); }
    }

    private List<string> ParseScannerSymbols()
    {
        return ScannerWatchlistText
            .Split(new[] { ',', ';', '\n', '\r', '\t', ' ' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(x => x.Trim())
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    private static string LoadScannerWatchlistFromJson(string fallback)
    {
        try
        {
            string basePath = AppDomain.CurrentDomain.BaseDirectory;
            string jsonPath = System.IO.Path.Combine(basePath, "StocksWatchlist.json");

            if (!System.IO.File.Exists(jsonPath))
            {
                string projectPath = System.IO.Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "StocksWatchlist.json");
                jsonPath = System.IO.Path.GetFullPath(projectPath);
            }

            if (!System.IO.File.Exists(jsonPath))
                return fallback;

            string json = System.IO.File.ReadAllText(jsonPath);
            using var doc = System.Text.Json.JsonDocument.Parse(json);
            if (!doc.RootElement.TryGetProperty("symbols", out var symbolsElement) || symbolsElement.ValueKind != System.Text.Json.JsonValueKind.Array)
                return fallback;

            var symbols = symbolsElement
                .EnumerateArray()
                .Select(x => x.GetString())
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x!.Trim())
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            return symbols.Count == 0 ? fallback : string.Join(",", symbols);
        }
        catch
        {
            return fallback;
        }
    }

    public MainViewModel()
    {
        _scannerWatchlistText = LoadScannerWatchlistFromJson(_scannerWatchlistText);
        LoginCommand = new RelayCommand(LoginAsync);
        StartCommand = new RelayCommand(async _ => { _timer.Start(); await RefreshAsync(); Status = "LIVE"; });
        StopCommand = new RelayCommand(_ => { _timer.Stop(); Status = "Stopped"; });
        TimeframeCommand = new RelayCommand(SetTimeframeAsync);
        TradingModeCommand = new RelayCommand(p => { if (p != null) SelectedTradingMode = p.ToString() ?? "Paper Trading"; });
        ScanStocksCommand = new RelayCommand(ScanStocksAsync);
        StopStockScanCommand = new RelayCommand(_ => StopStockScan());
        ToggleAutoStockScannerCommand = new RelayCommand(ToggleAutoStockScannerAsync);
        OpenDashboardCommand = new RelayCommand(_ => OpenDashboard());
        OpenSymbolInDashboardCommand = new RelayCommand(OpenSymbolInDashboardAsync);
        RunChartinkScannersCommand = new RelayCommand(RunChartinkScannersAsync);
        ExportChartinkResultsCommand = new RelayCommand(ExportChartinkResultsAsync);
        ExportChartinkExcelCommand = new RelayCommand(ExportChartinkExcelAsync);
        RunSmartStrategyCommand = new RelayCommand(_ => RunSmartStrategy());
        UseChartinkSuggestionCommand = new RelayCommand(UseChartinkSuggestion);
        RunChartinkQueryCommand = new RelayCommand(RunChartinkQueryAsync);
        UseChartinkQueryExampleCommand = new RelayCommand(UseChartinkQueryExampleAsync);
        SendQueryAlertsCommand = new RelayCommand(SendQueryAlertsManualAsync);
        TestAlertChannelsCommand = new RelayCommand(TestAlertChannelsAsync);
        AddCustomFunctionCommand = new RelayCommand(_ => AddCustomFunction());
        ClearCustomFunctionsCommand = new RelayCommand(_ => ClearCustomFunctions());
        AddChartinkRuleCommand = new RelayCommand(_ => AddChartinkRule());
        ClearChartinkRulesCommand = new RelayCommand(_ => ClearChartinkRules());
        RunCustomChartinkCommand = new RelayCommand(_ => RunCustomChartinkScanner());
        SaveChartinkTemplateCommand = new RelayCommand(_ => SaveChartinkTemplate());
        LoadChartinkTemplateCommand = new RelayCommand(_ => LoadSelectedChartinkTemplate());
        AddMagicChartinkRuleCommand = new RelayCommand(_ => AddMagicChartinkRule());
        RunChartinkBacktestCommand = new RelayCommand(_ => RunChartinkBacktest());
        foreach (var template in _chartinkTemplateService.Load()) ChartinkTemplates.Add(template);
        if (ChartinkTemplates.Count > 0) SelectedChartinkTemplate = ChartinkTemplates[0];
        RefreshChartinkIntelligence();
        ChartinkCustomFunctions.Add(new ChartinkUserFunction { Name = "bullpower", Expression = "(x + y + (z * 20)) / 3", Description = "RSI + MFI + RVOL bullish power" });
        ChartinkCustomFunctions.Add(new ChartinkUserFunction { Name = "bearpower", Expression = "((100 - x) + (100 - y) + (z * 20)) / 3", Description = "Inverse RSI/MFI + RVOL bearish power" });
        _chartinkQueryEngine.SetCustomFunctions(ChartinkCustomFunctions);
        foreach (var example in _chartinkQueryEngine.Examples) ChartinkQueryExamples.Add(example);
        UpdateChartinkQueryPreview();
        _paper.Quantity = PaperQuantity;
        _paper.BuyThreshold = PaperBuyThreshold;
        _paper.SellThreshold = PaperSellThreshold;
        _paper.IsEnabled = EnablePaperTrading;
        ApplyTradingMode(SelectedTradingMode, announce: false);
        _timer.Tick += async (_, _) => await RefreshAsync();
        _stockScannerAutoTimer.Tick += async (_, _) =>
        {
            if (!IsStockScannerRunning && IsAutoStockScannerEnabled)
                await ScanStocksAsync(null);
        };
    }


    private void ApplyTradingMode(string mode, bool announce)
    {
        if (mode == "Paper Trading")
        {
            EnablePaperTrading = true;
            _enableRealTrade = false;
            OnPropertyChanged(nameof(EnableRealTrade));
            RealTradingConfirmed = false;
            TradingStatus = "Paper Trading active. Auto paper simulation enabled.";
            TradingStatusBrush = "#19C37D";
        }
        else if (mode == "Manual Trading")
        {
            EnablePaperTrading = false;
            _enableRealTrade = false;
            OnPropertyChanged(nameof(EnableRealTrade));
            RealTradingConfirmed = false;
            TradingStatus = "Manual Trading selected. Simulation only. No broker order execution.";
            TradingStatusBrush = "#2DD4FF";
        }
        else
        {
            EnablePaperTrading = false;
            _enableRealTrade = true;
            OnPropertyChanged(nameof(EnableRealTrade));
            RealTradingConfirmed = false;
            TradingStatus = "Real Trading selected. Enable Real Trade is ON. Confirmation required. Broker execution is locked in this build.";
            TradingStatusBrush = "#FFC857";
        }

        if (announce)
            AddAlert($"Trading mode changed to {mode}. {TradingModeDescription}", TradingStatusBrush);
    }

    public void ConfirmRealTradingPreview()
    {
        if (SelectedTradingMode != "Real Trading")
        {
            AddAlert("Real trading confirmation ignored because Real Trading mode is not selected.", "#FFC857");
            return;
        }

        _enableRealTrade = true;
        OnPropertyChanged(nameof(EnableRealTrade));
        RealTradingConfirmed = true;
        TradingStatus = BrokerOrderServiceConnected
            ? "Enable Auto Real Trade confirmed. Broker service connected state detected."
            : "Enable Auto Real Trade confirmed. Broker execution remains blocked because order API is not connected.";
        TradingStatusBrush = "#FFC857";
        AddAlert("REAL TRADING CONFIRMED: Real order workflow is armed, but broker execution is blocked unless broker order service is connected.", "#FFC857");
    }


    private async Task EvaluateAutomaticTradingAsync()
    {
        if (SelectedTradingMode != "Real Trading" || !EnableRealTrade)
        {
            LastRealOrderStatus = "Auto real trade inactive.";
            LastRealOrderStatusBrush = "#93A4BD";
            return;
        }

        if (!RealTradingConfirmed)
        {
            LastRealOrderStatus = "Auto real trade waiting for confirmation.";
            LastRealOrderStatusBrush = "#FFC857";
            return;
        }

        string side = string.Empty;
        if (Score.FinalScore >= RealTradeBuyThreshold && Score.Signal.Contains("BUY", StringComparison.OrdinalIgnoreCase))
            side = "BUY";
        else if (Score.FinalScore <= RealTradeSellThreshold && Score.Signal.Contains("SELL", StringComparison.OrdinalIgnoreCase))
            side = "SELL";

        if (string.IsNullOrWhiteSpace(side))
        {
            LastRealOrderStatus = $"No real order signal. Score {Score.FinalScore}, Signal {Score.Signal}.";
            LastRealOrderStatusBrush = "#93A4BD";
            return;
        }

        var request = new BrokerOrderRequest
        {
            Symbol = Symbol,
            Side = side,
            Quantity = RealTradeQuantity,
            Price = Spot,
            FinalScore = Score.FinalScore,
            Signal = Score.Signal,
            TradingMode = SelectedTradingMode
        };

        var preview = await _brokerOrders.PreviewOrderAsync(request);
        AddAlert("REAL PREVIEW: " + preview.Message, "#FFC857");

        var result = await _brokerOrders.PlaceOrderAsync(request);
        LastRealOrderStatus = result.Message;
        LastRealOrderStatusBrush = result.Success ? "#19C37D" : "#FF4D4D";
        AddAlert("REAL ORDER: " + result.Message, result.Success ? "#19C37D" : "#FF4D4D");
    }

    private async Task SetTimeframeAsync(object? parameter)
    {
        string? tf = parameter?.ToString();
        if (string.IsNullOrWhiteSpace(tf)) return;
        Resolution = tf;
        AddAlert($"Timeframe changed to {TimeframeLabel}", "#2DD4FF");
        if (_history != null && _chain != null)
            await RefreshAsync();
    }

    private static void ReplaceCollection(ObservableCollection<StockScanResult> target, IEnumerable<StockScanResult> source)
    {
        target.Clear();
        foreach (var item in source)
            target.Add(item);
    }

    private IEnumerable<StockScanResult> ApplyChartinkBaseFilters(IEnumerable<StockScanResult> rows)
    {
        return rows.Where(x =>
            x.FinalScore >= ChartinkMinScore &&
            x.FinalScore <= ChartinkMaxScore &&
            Math.Max(x.Rvol10, x.Rvol20) >= ChartinkMinRvol &&
            x.Rsi >= ChartinkMinRsi &&
            x.Rsi <= ChartinkMaxRsi);
    }

    private void RefreshChartinkScanners()
    {
        var rows = ApplyChartinkBaseFilters(StockScanResults).ToList();
        ReplaceCollection(ChartinkBullishBreakoutResults, _chartink.BullishBreakout(rows));
        ReplaceCollection(ChartinkBearishBreakdownResults, _chartink.BearishBreakdown(rows));
        ReplaceCollection(ChartinkHighVolumeBreakoutResults, _chartink.HighVolumeBreakout(rows));
        ReplaceCollection(ChartinkHighVolumeBreakdownResults, _chartink.HighVolumeBreakdown(rows));
        ReplaceCollection(ChartinkSuperTrendBuyResults, _chartink.SuperTrendBuy(rows));
        ReplaceCollection(ChartinkSuperTrendSellResults, _chartink.SuperTrendSell(rows));
        ReplaceCollection(ChartinkRsiOversoldResults, _chartink.RsiOversoldReversal(rows));
        ReplaceCollection(ChartinkRsiOverboughtResults, _chartink.RsiOverboughtWeakness(rows));
        ReplaceCollection(ChartinkMomentumBuyResults, _chartink.MomentumBuy(rows));
        ReplaceCollection(ChartinkMomentumSellResults, _chartink.MomentumSell(rows));
        ReplaceCollection(ChartinkSmcBuyResults, _chartink.SmcBuy(rows));
        ReplaceCollection(ChartinkSmcSellResults, _chartink.SmcSell(rows));
        ReplaceCollection(ChartinkBullishPatternResults, _chartink.BullishPattern(rows));
        ReplaceCollection(ChartinkBearishPatternResults, _chartink.BearishPattern(rows));
        ReplaceCollection(CustomChartinkResults, _chartinkRuleEngine.Apply(rows, ChartinkRules));
        var queryRows = _chartinkQueryEngine.Execute(rows, ChartinkQueryText, out _);
        ReplaceCollection(ChartinkQueryResults, queryRows);
        ReplaceCollection(ChartinkRvolSpikeResults, _chartink.RvolSpike(rows));
        ReplaceCollection(ChartinkMoneyFlowBuyResults, _chartink.MoneyFlowBuy(rows));
        ReplaceCollection(ChartinkMoneyFlowSellResults, _chartink.MoneyFlowSell(rows));
        ReplaceCollection(ChartinkUptrendPullbackResults, _chartink.UptrendPullback(rows));
        ReplaceCollection(ChartinkDowntrendPullbackResults, _chartink.DowntrendPullback(rows));
        ReplaceCollection(ChartinkIntradayStrongResults, _chartink.IntradayStrong(rows));
        ReplaceCollection(ChartinkIntradayWeakResults, _chartink.IntradayWeak(rows));

        ChartinkScannerSummaries.Clear();
        AddChartinkSummary("Bullish Breakout", "BUY score + Higher High + RVOL confirmation", ChartinkBullishBreakoutResults.Count, "Bullish");
        AddChartinkSummary("Bearish Breakdown", "SELL score + Lower Low + RVOL confirmation", ChartinkBearishBreakdownResults.Count, "Bearish");
        AddChartinkSummary("High Volume Breakout", "Higher High with RVOL10/RVOL20 above 1.5", ChartinkHighVolumeBreakoutResults.Count, "Volume");
        AddChartinkSummary("High Volume Breakdown", "Lower Low with RVOL10/RVOL20 above 1.5", ChartinkHighVolumeBreakdownResults.Count, "Volume");
        AddChartinkSummary("SuperTrend Buy", "Strong Buy / Buy SuperTrend structure", ChartinkSuperTrendBuyResults.Count, "Bullish");
        AddChartinkSummary("SuperTrend Sell", "Strong Sell / Sell SuperTrend structure", ChartinkSuperTrendSellResults.Count, "Bearish");
        AddChartinkSummary("RSI Oversold Reversal", "RSI below 35 with Higher Low or BUY bias", ChartinkRsiOversoldResults.Count, "Bullish");
        AddChartinkSummary("RSI Overbought Weakness", "RSI above 65 with Lower High or SELL bias", ChartinkRsiOverboughtResults.Count, "Bearish");
        AddChartinkSummary("Momentum Buy", "RSI, ROC, CCI and CMF bullish alignment", ChartinkMomentumBuyResults.Count, "Bullish");
        AddChartinkSummary("Momentum Sell", "RSI, ROC, CCI and CMF bearish alignment", ChartinkMomentumSellResults.Count, "Bearish");
        AddChartinkSummary("SMC Buy", "SMC Buy or high SMC score with bullish score", ChartinkSmcBuyResults.Count, "Bullish");
        AddChartinkSummary("SMC Sell", "SMC Sell or high SMC score with bearish score", ChartinkSmcSellResults.Count, "Bearish");
        AddChartinkSummary("Bullish Pattern", "Bullish candlestick patterns", ChartinkBullishPatternResults.Count, "Bullish");
        AddChartinkSummary("Bearish Pattern", "Bearish candlestick patterns", ChartinkBearishPatternResults.Count, "Bearish");
        AddChartinkSummary("Custom Builder", "User-built scanner rules and magic filter conditions", CustomChartinkResults.Count, "Neutral");
        AddChartinkSummary("Chartink Query", "Structured query parser conditions", ChartinkQueryResults.Count, "Neutral");
        AddChartinkSummary("RVOL Spike", "RVOL10 or RVOL20 above 2.0", ChartinkRvolSpikeResults.Count, "Volume");
        AddChartinkSummary("Money Flow Buy", "MFI above 55 and CMF positive", ChartinkMoneyFlowBuyResults.Count, "Bullish");
        AddChartinkSummary("Money Flow Sell", "MFI below 45 and CMF negative", ChartinkMoneyFlowSellResults.Count, "Bearish");
        AddChartinkSummary("Uptrend Pullback", "Higher Low + SuperTrend Buy + controlled RSI", ChartinkUptrendPullbackResults.Count, "Bullish");
        AddChartinkSummary("Downtrend Pullback", "Lower High + SuperTrend Sell + controlled RSI", ChartinkDowntrendPullbackResults.Count, "Bearish");
        AddChartinkSummary("Intraday Strong", "Positive change, strong score and RVOL confirmation", ChartinkIntradayStrongResults.Count, "Bullish");
        AddChartinkSummary("Intraday Weak", "Negative change, weak score and RVOL confirmation", ChartinkIntradayWeakResults.Count, "Bearish");

        ChartinkStatus = $"Chartink scanners ready. Total stock rows={StockScanResults.Count}, Bullish breakout={ChartinkBullishBreakoutResults.Count}, Bearish breakdown={ChartinkBearishBreakdownResults.Count}.";
        ChartinkStatusBrush = ChartinkBullishBreakoutResults.Count > ChartinkBearishBreakdownResults.Count ? "#19C37D" : ChartinkBearishBreakdownResults.Count > 0 ? "#FF4D4D" : "#FFC857";
    }

    private void AddChartinkSummary(string name, string description, int count, string type)
    {
        ChartinkScannerSummaries.Add(new ChartinkScannerSummary
        {
            ScannerName = name,
            Description = description,
            Count = count,
            SignalType = type
        });
    }

    private async Task RunChartinkScannersAsync(object? _)
    {
        if (StockScanResults.Count == 0)
            await ScanStocksAsync(null);
        else
            RefreshChartinkScanners();

        AddAlert("CHARTINK MODULE: " + ChartinkStatus, ChartinkStatusBrush);
    }

    private void AddCustomFunction()
    {
        if (string.IsNullOrWhiteSpace(NewFunctionName) || string.IsNullOrWhiteSpace(NewFunctionExpression))
        {
            QueryAlertStatus = "Custom function name/expression is required.";
            return;
        }

        var existing = ChartinkCustomFunctions.FirstOrDefault(x => x.Name.Equals(NewFunctionName.Trim(), StringComparison.OrdinalIgnoreCase));
        if (existing != null)
            ChartinkCustomFunctions.Remove(existing);

        ChartinkCustomFunctions.Add(new ChartinkUserFunction
        {
            Name = NewFunctionName.Trim(),
            Expression = NewFunctionExpression.Trim(),
            Description = NewFunctionDescription.Trim()
        });

        _chartinkQueryEngine.SetCustomFunctions(ChartinkCustomFunctions);
        UpdateChartinkQueryPreview();
        QueryAlertStatus = "Custom function added: " + NewFunctionName.Trim();
        AddAlert("CUSTOM FUNCTION: " + NewFunctionName.Trim() + " registered.", "#2DD4FF");
    }

    private void ClearCustomFunctions()
    {
        ChartinkCustomFunctions.Clear();
        _chartinkQueryEngine.SetCustomFunctions(ChartinkCustomFunctions);
        QueryAlertStatus = "Custom functions cleared.";
        AddAlert("CUSTOM FUNCTIONS: Cleared.", "#FFC857");
    }

    private QueryAlertDeliverySettings BuildQueryAlertSettings()
    {
        return new QueryAlertDeliverySettings
        {
            EnableEmail = false,
            EnableSms = false,
            EnableTelegram = EnableQueryTelegramAlerts,
            SmtpHost = SmtpHost,
            SmtpPort = SmtpPort,
            SmtpEnableSsl = SmtpEnableSsl,
            SmtpUser = SmtpUser,
            SmtpPassword = SmtpPassword,
            EmailFrom = AlertEmailFrom,
            EmailTo = AlertEmailTo,
            SmsWebhookUrl = SmsWebhookUrl,
            SmsTo = SmsTo,
            TelegramBotToken = TelegramBotToken,
            TelegramChatId = TelegramChatId
        };
    }

    private async Task TestAlertChannelsAsync(object? _)
    {
        try
        {
            string message = "Test alert from WPF Strategy Studio at " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ".";
            string result = await _alertDelivery.SendAsync(BuildQueryAlertSettings(), "Strategy Studio Telegram Test Alert", message);
            QueryAlertStatus = result;
            AddAlert("ALERT TEST: " + result, result.Contains("failed", StringComparison.OrdinalIgnoreCase) ? "#FF4D4D" : "#19C37D");
        }
        catch (Exception ex)
        {
            QueryAlertStatus = "Alert test failed: " + ex.Message;
            AddAlert("ALERT TEST ERROR: " + ex.Message, "#FF4D4D");
        }
    }

    private async Task SendQueryAlertsManualAsync(object? _)
    {
        await SendQueryResultAlertsAsync(force: true);
    }

    private async Task SendQueryResultAlertsAsync(bool force)
    {
        if (!EnableQueryTelegramAlerts)
        {
            QueryAlertStatus = "Telegram query alerts are disabled.";
            return;
        }

        var matches = ChartinkQueryResults
            .Where(x => x.FinalScore >= QueryAlertMinScore)
            .OrderByDescending(x => x.FinalScore)
            .ThenByDescending(x => Math.Max(x.Rvol10, x.Rvol20))
            .Take(QueryAlertTopN)
            .ToList();

        if (matches.Count == 0)
        {
            QueryAlertStatus = "No query result met alert threshold.";
            return;
        }

        string key = string.Join("|", matches.Select(x => x.Symbol + ":" + x.FinalScore));
        if (!force && key == _lastQueryDeliveryKey)
        {
            QueryAlertStatus = "Duplicate query alert skipped.";
            return;
        }

        string subject = "Strategy Studio Query Alert - " + matches.Count + " match(es)";
        string body = BuildQueryAlertMessage(matches);

        try
        {
            string result = await _alertDelivery.SendAsync(BuildQueryAlertSettings(), subject, body);
            _lastQueryDeliveryKey = key;
            QueryAlertStatus = result;
            AddAlert("QUERY ALERT DELIVERY: " + result, result.Contains("failed", StringComparison.OrdinalIgnoreCase) ? "#FF4D4D" : "#19C37D");
        }
        catch (Exception ex)
        {
            QueryAlertStatus = "Alert delivery failed: " + ex.Message;
            AddAlert("QUERY ALERT DELIVERY ERROR: " + ex.Message, "#FF4D4D");
        }
    }

    private string BuildQueryAlertMessage(IEnumerable<StockScanResult> rows)
    {
        var lines = new List<string>
        {
            "Strategy Studio Query Alert",
            "Time: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
            "Query: " + ChartinkQueryText,
            "Min Score: " + QueryAlertMinScore,
            "",
            "Matches:"
        };

        foreach (var x in rows)
        {
            lines.Add($"{x.Symbol} | {x.Signal} | Score {x.FinalScore} | LTP {x.Ltp:0.00} | RSI {x.Rsi:0.00} | RVOL20 {x.Rvol20:0.00} | ST {x.SuperTrend} | {x.Reason}");
        }

        return string.Join(Environment.NewLine, lines);
    }

    private void UpdateChartinkQueryPreview()
    {
        var plan = _chartinkQueryEngine.Parse(ChartinkQueryText);
        ChartinkQueryPreview = "Query: " + plan.Summary;
    }

    private async Task UseChartinkQueryExampleAsync(object? parameter)
    {
        if (parameter is string query && !string.IsNullOrWhiteSpace(query))
        {
            ChartinkQueryText = query;
            await RunChartinkQueryAsync(null);
        }
    }

    private async Task RunChartinkQueryAsync(object? _)
    {
        if (StockScanResults.Count == 0)
            await ScanStocksAsync(null);

        var rows = ApplyChartinkBaseFilters(StockScanResults).ToList();
        var result = _chartinkQueryEngine.Execute(rows, ChartinkQueryText, out var plan);
        ReplaceCollection(ChartinkQueryResults, result);
        ChartinkQueryPreview = "Query: " + plan.Summary;
        ChartinkStatus = $"Chartink query executed. Conditions={plan.Conditions.Count}, Matches={ChartinkQueryResults.Count}.";
        ChartinkStatusBrush = ChartinkQueryResults.Count > 0 ? "#19C37D" : "#FFC857";
        AddAlert("CHARTINK QUERY: " + ChartinkStatus, ChartinkStatusBrush);
        await SendQueryResultAlertsAsync(force: false);
    }

    private void RefreshChartinkIntelligence()
    {
        ChartinkIntelligenceSuggestions.Clear();
        foreach (var suggestion in _chartinkStrategyAssistant.GenerateSuggestions(SmartStrategyText))
            ChartinkIntelligenceSuggestions.Add(suggestion);

        var previewRules = _chartinkStrategyAssistant.BuildRules(SmartStrategyText);
        SmartStrategyPreview = _chartinkStrategyAssistant.Explain(SmartStrategyText, previewRules);
    }

    private void UseChartinkSuggestion(object? parameter)
    {
        if (parameter is string suggestion && !string.IsNullOrWhiteSpace(suggestion))
        {
            SmartStrategyText = suggestion;
            RunSmartStrategy();
        }
    }

    private void RunSmartStrategy()
    {
        ChartinkRules.Clear();
        foreach (var rule in _chartinkStrategyAssistant.BuildRules(SmartStrategyText))
            ChartinkRules.Add(rule);

        RunCustomChartinkScanner();
        ChartinkStatus = $"Smart strategy executed. Rules={ChartinkRules.Count}, Matches={CustomChartinkResults.Count}.";
        ChartinkStatusBrush = CustomChartinkResults.Count > 0 ? "#19C37D" : "#FFC857";
    }

    private void AddChartinkRule()
    {
        ChartinkRules.Add(new ChartinkFilterRule
        {
            Field = NewChartinkField,
            Operator = NewChartinkOperator,
            Value = NewChartinkValue,
            Join = NewChartinkJoin
        });
        RunCustomChartinkScanner();
    }

    private void AddMagicChartinkRule()
    {
        var rule = _chartinkRuleEngine.ParseMagicFilter(MagicChartinkText);
        if (rule != null)
        {
            ChartinkRules.Add(rule);
            RunCustomChartinkScanner();
            ChartinkStatus = "Magic filter converted to rule: " + rule.Display;
            ChartinkStatusBrush = "#2DD4FF";
        }
    }

    private void ClearChartinkRules()
    {
        ChartinkRules.Clear();
        CustomChartinkResults.Clear();
        ChartinkStatus = "Custom Chartink rules cleared.";
        ChartinkStatusBrush = "#FFC857";
    }

    private void RunCustomChartinkScanner()
    {
        var rows = ApplyChartinkBaseFilters(StockScanResults).ToList();
        ReplaceCollection(CustomChartinkResults, _chartinkRuleEngine.Apply(rows, ChartinkRules));
        ChartinkStatus = $"Custom scanner executed. Rules={ChartinkRules.Count}, Matches={CustomChartinkResults.Count}.";
        ChartinkStatusBrush = CustomChartinkResults.Count > 0 ? "#19C37D" : "#FFC857";
    }

    private void SaveChartinkTemplate()
    {
        var template = new ChartinkScanTemplate
        {
            Name = string.IsNullOrWhiteSpace(ChartinkTemplateName) ? "My Scanner" : ChartinkTemplateName.Trim(),
            Description = "Saved from WPF Chartink builder",
            Rules = new ObservableCollection<ChartinkFilterRule>(ChartinkRules.Select(x => new ChartinkFilterRule
            {
                Field = x.Field,
                Operator = x.Operator,
                Value = x.Value,
                Join = x.Join
            }))
        };

        ChartinkTemplates.Add(template);
        SelectedChartinkTemplate = template;
        _chartinkTemplateService.Save(ChartinkTemplates);
        ChartinkStatus = "Saved Chartink template: " + template.Name;
        ChartinkStatusBrush = "#19C37D";
    }

    private void LoadSelectedChartinkTemplate()
    {
        if (SelectedChartinkTemplate == null) return;
        ChartinkRules.Clear();
        foreach (var rule in SelectedChartinkTemplate.Rules)
        {
            ChartinkRules.Add(new ChartinkFilterRule
            {
                Field = rule.Field,
                Operator = rule.Operator,
                Value = rule.Value,
                Join = rule.Join
            });
        }
        ChartinkTemplateName = SelectedChartinkTemplate.Name;
        RunCustomChartinkScanner();
        ChartinkStatus = "Loaded Chartink template: " + SelectedChartinkTemplate.Name;
        ChartinkStatusBrush = "#2DD4FF";
    }

    private void RunChartinkBacktest()
    {
        ChartinkBacktestResults.Clear();
        ChartinkBacktestResults.Add(_chartinkBacktestService.Summarize("Custom Builder", CustomChartinkResults));
        ChartinkBacktestResults.Add(_chartinkBacktestService.Summarize("Chartink Query", ChartinkQueryResults));
        ChartinkBacktestResults.Add(_chartinkBacktestService.Summarize("Bullish Breakout", ChartinkBullishBreakoutResults));
        ChartinkBacktestResults.Add(_chartinkBacktestService.Summarize("Bearish Breakdown", ChartinkBearishBreakdownResults));
        ChartinkBacktestResults.Add(_chartinkBacktestService.Summarize("SuperTrend Buy", ChartinkSuperTrendBuyResults));
        ChartinkBacktestResults.Add(_chartinkBacktestService.Summarize("SuperTrend Sell", ChartinkSuperTrendSellResults));
        ChartinkStatus = "Backtest-style summary refreshed for active scanner results.";
        ChartinkStatusBrush = "#2DD4FF";
    }

    private async Task ExportChartinkExcelAsync(object? _)
    {
        if (ChartinkScannerSummaries.Count == 0)
            await RunChartinkScannersAsync(null);

        string folder = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        if (string.IsNullOrWhiteSpace(folder) || !System.IO.Directory.Exists(folder))
            folder = AppDomain.CurrentDomain.BaseDirectory;

        string fileName = "ChartinkResults_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xls";
        string path = System.IO.Path.Combine(folder, fileName);

        var sb = new System.Text.StringBuilder();
        sb.AppendLine("<?xml version=\"1.0\"?>");
        sb.AppendLine("<?mso-application progid=\"Excel.Sheet\"?>");
        sb.AppendLine("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\">");
        sb.AppendLine("<Worksheet ss:Name=\"ChartinkResults\"><Table>");
        sb.AppendLine("<Row><Cell><Data ss:Type=\"String\">Scanner</Data></Cell><Cell><Data ss:Type=\"String\">Symbol</Data></Cell><Cell><Data ss:Type=\"String\">Signal</Data></Cell><Cell><Data ss:Type=\"String\">Score</Data></Cell><Cell><Data ss:Type=\"String\">LTP</Data></Cell><Cell><Data ss:Type=\"String\">Structure</Data></Cell><Cell><Data ss:Type=\"String\">SuperTrend</Data></Cell><Cell><Data ss:Type=\"String\">RSI</Data></Cell><Cell><Data ss:Type=\"String\">RVOL20</Data></Cell><Cell><Data ss:Type=\"String\">Reason</Data></Cell></Row>");
        AppendExcelRows(sb, "Custom Builder", CustomChartinkResults);
        AppendExcelRows(sb, "Chartink Query", ChartinkQueryResults);
        AppendExcelRows(sb, "Bullish Breakout", ChartinkBullishBreakoutResults);
        AppendExcelRows(sb, "Bearish Breakdown", ChartinkBearishBreakdownResults);
        AppendExcelRows(sb, "SuperTrend Buy", ChartinkSuperTrendBuyResults);
        AppendExcelRows(sb, "SuperTrend Sell", ChartinkSuperTrendSellResults);
        AppendExcelRows(sb, "RVOL Spike", ChartinkRvolSpikeResults);
        AppendExcelRows(sb, "Money Flow Buy", ChartinkMoneyFlowBuyResults);
        AppendExcelRows(sb, "Money Flow Sell", ChartinkMoneyFlowSellResults);
        AppendExcelRows(sb, "Intraday Strong", ChartinkIntradayStrongResults);
        AppendExcelRows(sb, "Intraday Weak", ChartinkIntradayWeakResults);
        sb.AppendLine("</Table></Worksheet></Workbook>");

        await System.IO.File.WriteAllTextAsync(path, sb.ToString());
        ChartinkStatus = "Excel-compatible Chartink export created: " + path;
        ChartinkStatusBrush = "#19C37D";
        AddAlert("CHARTINK EXCEL EXPORT: " + path, "#19C37D");
    }

    private static void AppendExcelRows(System.Text.StringBuilder sb, string scanner, IEnumerable<StockScanResult> rows)
    {
        foreach (var x in rows)
        {
            sb.AppendLine("<Row>" +
                ExcelCell(scanner) +
                ExcelCell(x.Symbol) +
                ExcelCell(x.Signal) +
                ExcelCell(x.FinalScore.ToString()) +
                ExcelCell(x.Ltp.ToString("0.00")) +
                ExcelCell(x.StructureSignal) +
                ExcelCell(x.SuperTrend) +
                ExcelCell(x.Rsi.ToString("0.00")) +
                ExcelCell(x.Rvol20.ToString("0.00")) +
                ExcelCell(x.Reason) +
                "</Row>");
        }
    }

    private static string ExcelCell(string? value)
    {
        value ??= string.Empty;
        string escaped = System.Security.SecurityElement.Escape(value) ?? string.Empty;
        return $"<Cell><Data ss:Type=\"String\">{escaped}</Data></Cell>";
    }

    private async Task ExportChartinkResultsAsync(object? _)
    {
        if (ChartinkScannerSummaries.Count == 0)
            await RunChartinkScannersAsync(null);

        string folder = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        if (string.IsNullOrWhiteSpace(folder) || !System.IO.Directory.Exists(folder))
            folder = AppDomain.CurrentDomain.BaseDirectory;

        string fileName = "ChartinkResults_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".csv";
        string path = System.IO.Path.Combine(folder, fileName);

        var sb = new System.Text.StringBuilder();
        sb.AppendLine("Scanner,Rank,Symbol,Signal,Score,LTP,ChangePercent,Structure,SuperTrend,RSI,ROC,MFI,CMF,RVOL10,RVOL20,Pattern,SMC,Reason");

        AppendChartinkCsv(sb, "Bullish Breakout", ChartinkBullishBreakoutResults);
        AppendChartinkCsv(sb, "Bearish Breakdown", ChartinkBearishBreakdownResults);
        AppendChartinkCsv(sb, "High Volume Breakout", ChartinkHighVolumeBreakoutResults);
        AppendChartinkCsv(sb, "High Volume Breakdown", ChartinkHighVolumeBreakdownResults);
        AppendChartinkCsv(sb, "SuperTrend Buy", ChartinkSuperTrendBuyResults);
        AppendChartinkCsv(sb, "SuperTrend Sell", ChartinkSuperTrendSellResults);
        AppendChartinkCsv(sb, "RSI Oversold Reversal", ChartinkRsiOversoldResults);
        AppendChartinkCsv(sb, "RSI Overbought Weakness", ChartinkRsiOverboughtResults);
        AppendChartinkCsv(sb, "Momentum Buy", ChartinkMomentumBuyResults);
        AppendChartinkCsv(sb, "Momentum Sell", ChartinkMomentumSellResults);
        AppendChartinkCsv(sb, "SMC Buy", ChartinkSmcBuyResults);
        AppendChartinkCsv(sb, "SMC Sell", ChartinkSmcSellResults);
        AppendChartinkCsv(sb, "Bullish Pattern", ChartinkBullishPatternResults);
        AppendChartinkCsv(sb, "Bearish Pattern", ChartinkBearishPatternResults);
        AppendChartinkCsv(sb, "Custom Builder", CustomChartinkResults);
        AppendChartinkCsv(sb, "Chartink Query", ChartinkQueryResults);
        AppendChartinkCsv(sb, "RVOL Spike", ChartinkRvolSpikeResults);
        AppendChartinkCsv(sb, "Money Flow Buy", ChartinkMoneyFlowBuyResults);
        AppendChartinkCsv(sb, "Money Flow Sell", ChartinkMoneyFlowSellResults);
        AppendChartinkCsv(sb, "Uptrend Pullback", ChartinkUptrendPullbackResults);
        AppendChartinkCsv(sb, "Downtrend Pullback", ChartinkDowntrendPullbackResults);
        AppendChartinkCsv(sb, "Intraday Strong", ChartinkIntradayStrongResults);
        AppendChartinkCsv(sb, "Intraday Weak", ChartinkIntradayWeakResults);

        await System.IO.File.WriteAllTextAsync(path, sb.ToString());
        ChartinkStatus = "Chartink results exported: " + path;
        ChartinkStatusBrush = "#19C37D";
        AddAlert("CHARTINK EXPORT: " + path, "#19C37D");
    }

    private static void AppendChartinkCsv(System.Text.StringBuilder sb, string scanner, IEnumerable<StockScanResult> rows)
    {
        foreach (var x in rows)
        {
            sb.AppendLine(string.Join(",", new[]
            {
                Csv(scanner),
                x.Rank.ToString(),
                Csv(x.Symbol),
                Csv(x.Signal),
                x.FinalScore.ToString(),
                x.Ltp.ToString("0.00"),
                x.ChangePercent.ToString("0.00"),
                Csv(x.StructureSignal),
                Csv(x.SuperTrend),
                x.Rsi.ToString("0.00"),
                x.Roc.ToString("0.00"),
                x.Mfi.ToString("0.00"),
                x.Cmf.ToString("0.000"),
                x.Rvol10.ToString("0.00"),
                x.Rvol20.ToString("0.00"),
                Csv(x.Pattern),
                Csv(x.SmcSignal),
                Csv(x.Reason)
            }));
        }
    }

    private static string Csv(string? value)
    {
        value ??= string.Empty;
        return "\"" + value.Replace("\"", "\"\"").Replace("\r", " ").Replace("\n", " ") + "\"";
    }

    private async Task ToggleAutoStockScannerAsync(object? _)
    {
        IsAutoStockScannerEnabled = !IsAutoStockScannerEnabled;

        if (IsAutoStockScannerEnabled)
        {
            _stockScannerAutoTimer.Start();
            StockScannerStatus = "Always Run scanner enabled. Running scan now and repeating every 60 seconds.";
            StockScannerStatusBrush = "#19C37D";
            AddAlert("STOCK SCANNER: Always Run enabled.", "#19C37D");
            if (!IsStockScannerRunning)
                await ScanStocksAsync(null);
        }
        else
        {
            _stockScannerAutoTimer.Stop();
            StockScannerStatus = "Always Run scanner stopped.";
            StockScannerStatusBrush = "#FFC857";
            AddAlert("STOCK SCANNER: Always Run stopped.", "#FFC857");
        }
    }

    private void OpenDashboard()
    {
        SelectedMainTabIndex = 0;
        AddAlert("NAVIGATION: Opened Dashboard tab.", "#2DD4FF");
    }

    private async Task OpenSymbolInDashboardAsync(object? parameter)
    {
        string? selectedSymbol = parameter switch
        {
            StockScanResult row => row.Symbol,
            string text => text,
            _ => null
        };

        if (!string.IsNullOrWhiteSpace(selectedSymbol))
        {
            Symbol = selectedSymbol.Trim();
            AddAlert($"NAVIGATION: Dashboard opened for {Symbol}.", "#2DD4FF");
        }

        SelectedMainTabIndex = 0;

        if (_history != null && _chain != null)
            await RefreshAsync();
    }

    private async Task ScanStocksAsync(object? _)
    {
        if (_history == null)
        {
            StockScannerStatus = "Login first before scanning stocks.";
            StockScannerStatusBrush = "#FFC857";
            AddAlert("STOCK SCANNER: Login first before scanning stocks.", "#FFC857");
            return;
        }

        var symbols = ParseScannerSymbols();
        if (symbols.Count == 0)
        {
            StockScannerStatus = "Add at least one symbol to scanner watchlist.";
            StockScannerStatusBrush = "#FFC857";
            return;
        }

        _stockScanCts?.Cancel();
        _stockScanCts = new CancellationTokenSource();
        IsStockScannerRunning = true;
        StockScannerStatus = $"Scanning {symbols.Count} symbols on TF {TimeframeLabel}...";
        StockScannerStatusBrush = "#2DD4FF";
        StockScanResults.Clear();
        BuyScanResults.Clear();
        SellScanResults.Clear();
        WaitScanResults.Clear();
        HigherHighScanResults.Clear();
        HigherLowScanResults.Clear();
        LowerHighScanResults.Clear();
        LowerLowScanResults.Clear();

        try
        {
            var scanner = new StockScannerService(_history, _ind, _smart);
            var results = await scanner.ScanAsync(symbols, Resolution, ScannerLookbackDays, BuildStrategyThresholdSettings(), _stockScanCts.Token);

            int rank = 1;
            foreach (var row in results)
            {
                row.Rank = rank++;
                StockScanResults.Add(row);
                if (row.Signal.StartsWith("BUY", StringComparison.OrdinalIgnoreCase)) BuyScanResults.Add(row);
                else if (row.Signal.StartsWith("SELL", StringComparison.OrdinalIgnoreCase)) SellScanResults.Add(row);
                else WaitScanResults.Add(row);

                if (row.HigherHigh) HigherHighScanResults.Add(row);
                if (row.HigherLow) HigherLowScanResults.Add(row);
                if (row.LowerHigh) LowerHighScanResults.Add(row);
                if (row.LowerLow) LowerLowScanResults.Add(row);
            }

            StockScannerStatus = $"Scan completed. Total={StockScanResults.Count}, BUY={BuyScanResults.Count}, SELL={SellScanResults.Count}, WAIT={WaitScanResults.Count}, HH={HigherHighScanResults.Count}, HL={HigherLowScanResults.Count}, LH={LowerHighScanResults.Count}, LL={LowerLowScanResults.Count}.";
            StockScannerStatusBrush = BuyScanResults.Count > 0 ? "#19C37D" : SellScanResults.Count > 0 ? "#FF4D4D" : "#FFC857";
            RefreshChartinkScanners();
            AddAlert("STOCK SCANNER: " + StockScannerStatus, StockScannerStatusBrush);
        }
        catch (OperationCanceledException)
        {
            StockScannerStatus = "Stock scan stopped.";
            StockScannerStatusBrush = "#FFC857";
            AddAlert("STOCK SCANNER: Scan stopped.", "#FFC857");
        }
        catch (Exception ex)
        {
            StockScannerStatus = "Scanner error: " + ex.Message;
            StockScannerStatusBrush = "#FF4D4D";
            AddAlert("STOCK SCANNER ERROR: " + ex.Message, "#FF4D4D");
        }
        finally
        {
            IsStockScannerRunning = false;
        }
    }

    private void StopStockScan()
    {
        _stockScanCts?.Cancel();
        StockScannerStatus = "Stopping stock scan...";
        StockScannerStatusBrush = "#FFC857";
    }

    private async Task LoginAsync(object? _)
    {
        _api.AccessToken = await _auth.ExchangeAuthCodeAsync(_api.RawHttpClient, AppId, AppSecret, AuthCode);
        _history = new FyersHistoryService(_api); _chain = new FyersOptionChainService(_api);
        Status = "Logged in. Click Start Live.";
        AddAlert("Login success. Live-only mode enabled.", "#19C37D");
    }
    private async Task RefreshAsync()
    {
        if (_history == null || _chain == null) return;
        try
        {
            var candles = await _history.GetCandlesAsync(Symbol, Resolution, 5); _ind.ApplyAll(candles);
            Candles.Clear(); foreach (var c in candles.TakeLast(120)) Candles.Add(c);
            Trend = _ind.BuildTrend(candles);
            RaiseCandlestickAlertIfNeeded(candles);
            RaiseDemaTemaAlertIfNeeded(candles);
            RaiseAdvancedIndicatorAlertIfNeeded(candles);
            RaiseSmcAlertIfNeeded(candles);
            RaiseOrderBlockAlertIfNeeded(candles);
            RaiseSuperTrendAlertIfNeeded(candles);
            var rows = await _chain.GetRowsAsync(Symbol, StrikeCount);
            OptionRows.Clear(); foreach (var r in rows) OptionRows.Add(r);
            UpdateBuildTabs(rows);
            Spot = _chain.CurrentSpot > 0 ? _chain.CurrentSpot : candles.LastOrDefault()?.Close ?? 0;
            if (candles.Count >= 2)
            {
                decimal previousClose = candles[^2].Close;
                decimal change = Spot - previousClose;
                decimal changePercent = previousClose == 0 ? 0 : change / previousClose * 100m;
                SpotChangeText = $"{(change >= 0 ? "+" : "")}{change:0.00} pts ({(changePercent >= 0 ? "+" : "")}{changePercent:0.00}%)";
                SpotChangeBrush = change > 0 ? "#19C37D" : change < 0 ? "#FF4D4D" : "#93A4BD";
            }
            Expiry = _chain.CurrentExpiry;
            Score = _smart.Build(Trend, rows, Spot, BuildStrategyThresholdSettings());
            _paper.IsEnabled = EnablePaperTrading;
            _paper.Quantity = PaperQuantity;
            _paper.BuyThreshold = PaperBuyThreshold;
            _paper.SellThreshold = PaperSellThreshold;
            string beforeAction = PaperSummary.LastAction;
            _paper.ProcessSignal(Symbol, Spot, Score, rows);
            OnPropertyChanged(nameof(PaperSummary));
            if (beforeAction != PaperSummary.LastAction)
                AddAlert("PAPER: " + PaperSummary.LastAction, PaperSummary.NetPnl >= 0 ? "#19C37D" : "#FF4D4D");
            await EvaluateAutomaticTradingAsync();
            AddAlert($"{Score.Signal} | Score {Score.FinalScore} | {Score.Reason}", Score.Signal.StartsWith("BUY") ? "#19C37D" : Score.Signal.StartsWith("SELL") ? "#FF4D4D" : "#FFC857");
            TradingStatus = $"{SelectedTradingMode} | {Score.Signal} | Score {Score.FinalScore} | Spot {Spot:0.00} | TF {TimeframeLabel} | {DateTime.Now:HH:mm:ss}";
            if (SelectedTradingMode == "Real Trading") TradingStatus += EnableRealTrade ? (RealTradingConfirmed ? $" | AutoReal ON | Confirmed | BrokerConnected {BrokerOrderServiceConnected}" : " | AutoReal ON | Awaiting Confirmation") : " | AutoReal OFF";
            if (SelectedTradingMode == "Paper Trading") TradingStatus += EnableAutoPaperTrade ? " | AutoPaper ON" : " | AutoPaper OFF";
            TradingStatusBrush = Score.Signal.StartsWith("BUY") ? "#19C37D" : Score.Signal.StartsWith("SELL") ? "#FF4D4D" : "#FFC857";
            Status = "LIVE " + DateTime.Now.ToString("HH:mm:ss");
        }
        catch (Exception ex) { Status = "Error"; AddAlert(ex.Message, "#FF4D4D"); }
    }

    private void RaiseCandlestickAlertIfNeeded(List<Candle> candles)
    {
        var last = candles.LastOrDefault();
        if (last == null) return;
        if (string.IsNullOrWhiteSpace(last.CandlestickPattern) || last.CandlestickPattern == "-") return;

        string key = $"{last.Time:yyyyMMddHHmm}_{last.CandlestickPattern}";
        if (key == _lastCandlestickAlertKey) return;

        _lastCandlestickAlertKey = key;
        string brush = last.CandlestickBias == "Bullish" ? "#19C37D" : last.CandlestickBias == "Bearish" ? "#FF4D4D" : "#FFC857";
        AddAlert($"CANDLE: {last.CandlestickPattern} | {last.CandlestickBias} | TF {TimeframeLabel} | {last.Time:HH:mm}", brush);
    }

    private void RaiseDemaTemaAlertIfNeeded(List<Candle> candles)
    {
        var last = candles.LastOrDefault();
        if (last == null) return;
        if (string.IsNullOrWhiteSpace(last.DemaTemaSignal) || last.DemaTemaSignal == "Equal") return;

        string key = $"{last.Time:yyyyMMddHHmm}_{last.DemaTemaSignal}";
        if (key == _lastDemaTemaAlertKey) return;

        _lastDemaTemaAlertKey = key;
        string brush = last.DemaTemaSignal.StartsWith("DEMA") ? "#19C37D" : "#FF4D4D";
        AddAlert($"DEMA/TEMA: {last.DemaTemaSignal} | TF {TimeframeLabel} | DEMA {last.Dema20:0.00} | TEMA {last.Tema20:0.00}", brush);
    }


    private void RaiseAdvancedIndicatorAlertIfNeeded(List<Candle> candles)
    {
        var last = candles.LastOrDefault();
        if (last == null) return;

        string key = $"{last.Time:yyyyMMddHHmm}_{last.TtmSqueezeStatus}_{last.VortexSignal}_{last.PsarSignal}_{last.AroonSignal}_{last.CamarillaZone}";
        if (key == _lastAdvancedIndicatorAlertKey) return;

        _lastAdvancedIndicatorAlertKey = key;
        string brush = last.PsarSignal == "Bullish" && last.VortexSignal == "Bullish" ? "#19C37D" :
                       last.PsarSignal == "Bearish" && last.VortexSignal == "Bearish" ? "#FF4D4D" : "#FFC857";
        AddAlert($"ADV: TTM {last.TtmSqueezeStatus} | Vortex {last.VortexSignal} | PSAR {last.PsarSignal} | Aroon {last.AroonSignal} | {last.CamarillaZone}", brush);
    }

    private void RaiseSmcAlertIfNeeded(List<Candle> candles)
    {
        var last = candles.LastOrDefault();
        if (last == null) return;
        if (string.IsNullOrWhiteSpace(last.SmartMoneyStructureSignal) || last.SmartMoneyStructureSignal == "Neutral") return;

        string key = $"{last.Time:yyyyMMddHHmm}_{last.BosSignal}_{last.LiquiditySignal}_{last.OrderBlockSignal}_{last.FvgSignal}_{last.SmartMoneyStructureSignal}";
        if (key == _lastSmcAlertKey) return;

        _lastSmcAlertKey = key;
        string brush = last.SmartMoneyStructureSignal.Contains("Buy") ? "#19C37D" : "#FF4D4D";
        AddAlert($"SMC: {last.SmartMoneyStructureSignal} | BOS {last.BosSignal} | Liq {last.LiquiditySignal} | OB {last.OrderBlockSignal} | FVG {last.FvgSignal} | TF {TimeframeLabel}", brush);
    }

    private void RaiseOrderBlockAlertIfNeeded(List<Candle> candles)
    {
        var last = candles.LastOrDefault();
        if (last == null) return;
        if (string.IsNullOrWhiteSpace(last.OrderBlockSignal) || last.OrderBlockSignal == "None") return;

        string key = $"{last.Time:yyyyMMddHHmm}_{last.OrderBlockSignal}_{last.OrderBlockHigh:0.00}_{last.OrderBlockLow:0.00}";
        if (key == _lastOrderBlockAlertKey) return;

        _lastOrderBlockAlertKey = key;
        string brush = last.OrderBlockSignal == "Bullish OB" ? "#19C37D" : "#FF4D4D";
        AddAlert($"OB: {last.OrderBlockSignal} | Zone {last.OrderBlockLow:0.00}-{last.OrderBlockHigh:0.00} | TF {TimeframeLabel}", brush);
    }

    private void RaiseSuperTrendAlertIfNeeded(List<Candle> candles)
    {
        var last = candles.LastOrDefault();
        if (last == null) return;

        string signal = last.SuperTrendBullish ? "Buy" : "Sell";
        string key = $"{last.Time:yyyyMMddHHmm}_{signal}_{TimeframeLabel}";
        if (key == _lastSuperTrendAlertKey) return;

        _lastSuperTrendAlertKey = key;
        string brush = last.SuperTrendBullish ? "#19C37D" : "#FF4D4D";
        AddAlert($"SuperTrend: {signal} | Score {(last.SuperTrendBullish ? 80 : 25)} | TF {TimeframeLabel} | ST {last.SuperTrend:0.00}", brush);
    }

    private void UpdateBuildTabs(List<OptionChainRow> rows)
    {
        LongBuildRows.Clear();
        ShortBuildRows.Clear();
        LongUnwindRows.Clear();
        ShortCoverRows.Clear();

        foreach (var row in rows)
        {
            if (row.CE?.Signal == "Long Build" || row.PE?.Signal == "Long Build") LongBuildRows.Add(row);
            if (row.CE?.Signal == "Short Build" || row.PE?.Signal == "Short Build") ShortBuildRows.Add(row);
            if (row.CE?.Signal == "Long Unwind" || row.PE?.Signal == "Long Unwind") LongUnwindRows.Add(row);
            if (row.CE?.Signal == "Short Cover" || row.PE?.Signal == "Short Cover") ShortCoverRows.Add(row);
        }
    }

    private void AddAlert(string text, string brush)
    {
        Alerts.Insert(0, new AlertMessage { Text = text, Brush = brush });
        while (Alerts.Count > 50) Alerts.RemoveAt(Alerts.Count - 1);
    }
    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? n = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
}
