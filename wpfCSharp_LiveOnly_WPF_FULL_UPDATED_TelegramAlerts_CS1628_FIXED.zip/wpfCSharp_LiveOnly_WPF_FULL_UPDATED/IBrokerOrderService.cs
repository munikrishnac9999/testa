using wpfCSharp_LiveOnly_WPF.Models;

namespace wpfCSharp_LiveOnly_WPF.Services;

public interface IBrokerOrderService
{
    bool IsConnected { get; }
    Task<BrokerOrderResult> PreviewOrderAsync(BrokerOrderRequest request);
    Task<BrokerOrderResult> PlaceOrderAsync(BrokerOrderRequest request);
}
