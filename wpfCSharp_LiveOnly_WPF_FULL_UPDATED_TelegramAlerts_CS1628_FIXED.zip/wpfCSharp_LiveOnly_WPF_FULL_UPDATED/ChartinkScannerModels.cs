namespace wpfCSharp_LiveOnly_WPF.Models;

public sealed class ChartinkScannerSummary
{
    public string ScannerName { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public int Count { get; set; }
    public string SignalType { get; set; } = "Neutral";
    public string Brush => SignalType == "Bullish" ? "#19C37D" : SignalType == "Bearish" ? "#FF4D4D" : SignalType == "Volume" ? "#2DD4FF" : "#FFC857";
}
