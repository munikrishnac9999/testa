using wpfCSharp_LiveOnly_WPF.Models;

namespace wpfCSharp_LiveOnly_WPF.Services;

public sealed class ChartinkScannerService
{
    public List<StockScanResult> BullishBreakout(IEnumerable<StockScanResult> rows) => rows
        .Where(x => (x.Signal.StartsWith("BUY", StringComparison.OrdinalIgnoreCase) || x.FinalScore >= 70)
                    && x.HigherHigh
                    && (x.Rvol10 >= 1.20m || x.Rvol20 >= 1.20m))
        .OrderByDescending(x => x.FinalScore)
        .ThenByDescending(x => Math.Max(x.Rvol10, x.Rvol20))
        .ToList();

    public List<StockScanResult> BearishBreakdown(IEnumerable<StockScanResult> rows) => rows
        .Where(x => (x.Signal.StartsWith("SELL", StringComparison.OrdinalIgnoreCase) || x.FinalScore <= 40)
                    && x.LowerLow
                    && (x.Rvol10 >= 1.20m || x.Rvol20 >= 1.20m))
        .OrderBy(x => x.FinalScore)
        .ThenByDescending(x => Math.Max(x.Rvol10, x.Rvol20))
        .ToList();

    public List<StockScanResult> HighVolumeBreakout(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.HigherHigh && (x.Rvol10 >= 1.50m || x.Rvol20 >= 1.50m))
        .OrderByDescending(x => Math.Max(x.Rvol10, x.Rvol20))
        .ThenByDescending(x => x.FinalScore)
        .ToList();

    public List<StockScanResult> HighVolumeBreakdown(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.LowerLow && (x.Rvol10 >= 1.50m || x.Rvol20 >= 1.50m))
        .OrderByDescending(x => Math.Max(x.Rvol10, x.Rvol20))
        .ThenBy(x => x.FinalScore)
        .ToList();

    public List<StockScanResult> SuperTrendBuy(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.SuperTrend.Contains("Buy", StringComparison.OrdinalIgnoreCase))
        .OrderByDescending(x => x.SuperTrendScore)
        .ThenByDescending(x => x.FinalScore)
        .ToList();

    public List<StockScanResult> SuperTrendSell(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.SuperTrend.Contains("Sell", StringComparison.OrdinalIgnoreCase))
        .OrderBy(x => x.SuperTrendScore)
        .ThenBy(x => x.FinalScore)
        .ToList();

    public List<StockScanResult> RsiOversoldReversal(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.Rsi <= 35 && (x.HigherLow || x.Signal.StartsWith("BUY", StringComparison.OrdinalIgnoreCase)))
        .OrderBy(x => x.Rsi)
        .ThenByDescending(x => x.FinalScore)
        .ToList();

    public List<StockScanResult> RsiOverboughtWeakness(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.Rsi >= 65 && (x.LowerHigh || x.Signal.StartsWith("SELL", StringComparison.OrdinalIgnoreCase)))
        .OrderByDescending(x => x.Rsi)
        .ThenBy(x => x.FinalScore)
        .ToList();

    public List<StockScanResult> MomentumBuy(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.Rsi >= 55 && x.Roc > 0 && x.Cci > 0 && x.Cmf >= 0)
        .OrderByDescending(x => x.FinalScore)
        .ThenByDescending(x => x.Roc)
        .ToList();

    public List<StockScanResult> MomentumSell(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.Rsi <= 45 && x.Roc < 0 && x.Cci < 0 && x.Cmf <= 0)
        .OrderBy(x => x.FinalScore)
        .ThenBy(x => x.Roc)
        .ToList();

    public List<StockScanResult> SmcBuy(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.SmcSignal.Contains("Buy", StringComparison.OrdinalIgnoreCase) || x.SmcScore >= 70 && x.FinalScore >= 60)
        .OrderByDescending(x => x.SmcScore)
        .ThenByDescending(x => x.FinalScore)
        .ToList();

    public List<StockScanResult> SmcSell(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.SmcSignal.Contains("Sell", StringComparison.OrdinalIgnoreCase) || x.SmcScore >= 70 && x.FinalScore <= 45)
        .OrderByDescending(x => x.SmcScore)
        .ThenBy(x => x.FinalScore)
        .ToList();

    public List<StockScanResult> BullishPattern(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.PatternBias == "Bullish")
        .OrderByDescending(x => x.FinalScore)
        .ToList();

    public List<StockScanResult> BearishPattern(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.PatternBias == "Bearish")
        .OrderBy(x => x.FinalScore)
        .ToList();
    public List<StockScanResult> RvolSpike(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.Rvol10 >= 2.0m || x.Rvol20 >= 2.0m)
        .OrderByDescending(x => Math.Max(x.Rvol10, x.Rvol20))
        .ThenByDescending(x => x.FinalScore)
        .ToList();

    public List<StockScanResult> MoneyFlowBuy(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.Mfi >= 55 && x.Cmf > 0 && x.FinalScore >= 55)
        .OrderByDescending(x => x.Mfi)
        .ThenByDescending(x => x.FinalScore)
        .ToList();

    public List<StockScanResult> MoneyFlowSell(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.Mfi <= 45 && x.Cmf < 0 && x.FinalScore <= 50)
        .OrderBy(x => x.Mfi)
        .ThenBy(x => x.FinalScore)
        .ToList();

    public List<StockScanResult> UptrendPullback(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.HigherLow && x.SuperTrend.Contains("Buy", StringComparison.OrdinalIgnoreCase) && x.Rsi >= 45 && x.Rsi <= 60)
        .OrderByDescending(x => x.FinalScore)
        .ThenByDescending(x => x.Rvol20)
        .ToList();

    public List<StockScanResult> DowntrendPullback(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.LowerHigh && x.SuperTrend.Contains("Sell", StringComparison.OrdinalIgnoreCase) && x.Rsi >= 40 && x.Rsi <= 55)
        .OrderBy(x => x.FinalScore)
        .ThenByDescending(x => x.Rvol20)
        .ToList();

    public List<StockScanResult> IntradayStrong(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.ChangePercent > 0 && x.FinalScore >= 70 && (x.Rvol10 >= 1.2m || x.Rvol20 >= 1.2m))
        .OrderByDescending(x => x.ChangePercent)
        .ThenByDescending(x => x.FinalScore)
        .ToList();

    public List<StockScanResult> IntradayWeak(IEnumerable<StockScanResult> rows) => rows
        .Where(x => x.ChangePercent < 0 && x.FinalScore <= 40 && (x.Rvol10 >= 1.2m || x.Rvol20 >= 1.2m))
        .OrderBy(x => x.ChangePercent)
        .ThenBy(x => x.FinalScore)
        .ToList();

}
