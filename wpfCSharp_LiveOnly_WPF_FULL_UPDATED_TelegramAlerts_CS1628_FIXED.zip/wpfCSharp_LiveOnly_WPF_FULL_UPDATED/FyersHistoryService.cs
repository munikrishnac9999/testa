using Newtonsoft.Json.Linq;
using wpfCSharp_LiveOnly_WPF.Models;
namespace wpfCSharp_LiveOnly_WPF.Services;
public sealed class FyersHistoryService
{
    private readonly FyersApiClient _api;
    public FyersHistoryService(FyersApiClient api) => _api = api;
    public async Task<List<Candle>> GetCandlesAsync(string symbol, string resolution, int lookbackDays)
    {
        string from = DateTime.Today.AddDays(-lookbackDays).ToString("yyyy-MM-dd");
        string to = DateTime.Today.ToString("yyyy-MM-dd");
        string url = "https://api-t1.fyers.in/data/history" +
            $"?symbol={Uri.EscapeDataString(symbol)}&resolution={resolution}&date_format=1&range_from={from}&range_to={to}&cont_flag=1";
        string json = await _api.GetAsync(url);
        JObject root = JObject.Parse(json);
        var candles = new List<Candle>();
        foreach (JArray row in root["candles"] as JArray ?? new JArray())
        {
            long epoch = row[0]!.Value<long>();
            candles.Add(new Candle
            {
                Time = DateTimeOffset.FromUnixTimeSeconds(epoch).LocalDateTime,
                Open = row[1]!.Value<decimal>(),
                High = row[2]!.Value<decimal>(),
                Low = row[3]!.Value<decimal>(),
                Close = row[4]!.Value<decimal>(),
                Volume = row.Count > 5 ? row[5]!.Value<decimal>() : 0
            });
        }
        return candles.OrderBy(x => x.Time).ToList();
    }
}
