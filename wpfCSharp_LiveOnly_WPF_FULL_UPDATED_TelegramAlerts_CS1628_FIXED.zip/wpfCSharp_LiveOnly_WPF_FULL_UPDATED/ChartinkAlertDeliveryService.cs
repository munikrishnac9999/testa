using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Net.Mail;

namespace wpfCSharp_LiveOnly_WPF.Services;

public sealed class QueryAlertDeliverySettings
{
    // Email and SMS are intentionally disabled in the UI for now.
    public bool EnableEmail { get; set; }
    public bool EnableSms { get; set; }
    public bool EnableTelegram { get; set; }

    public string SmtpHost { get; set; } = string.Empty;
    public int SmtpPort { get; set; } = 587;
    public bool SmtpEnableSsl { get; set; } = true;
    public string SmtpUser { get; set; } = string.Empty;
    public string SmtpPassword { get; set; } = string.Empty;
    public string EmailFrom { get; set; } = string.Empty;
    public string EmailTo { get; set; } = string.Empty;

    public string SmsWebhookUrl { get; set; } = string.Empty;
    public string SmsTo { get; set; } = string.Empty;

    public string TelegramBotToken { get; set; } = string.Empty;
    public string TelegramChatId { get; set; } = string.Empty;
}

public sealed class ChartinkAlertDeliveryService
{
    private static readonly HttpClient Http = new();

    public async Task<string> SendAsync(QueryAlertDeliverySettings settings, string subject, string message, CancellationToken cancellationToken = default)
    {
        var results = new List<string>();

        if (settings.EnableEmail)
            results.Add(await SendEmailAsync(settings, subject, message));

        if (settings.EnableSms)
            results.Add(await SendSmsAsync(settings, message, cancellationToken));

        if (settings.EnableTelegram)
            results.Add(await SendTelegramAsync(settings, message, cancellationToken));

        return results.Count == 0 ? "No alert delivery channel enabled." : string.Join(" | ", results);
    }

    private static async Task<string> SendEmailAsync(QueryAlertDeliverySettings settings, string subject, string message)
    {
        if (string.IsNullOrWhiteSpace(settings.SmtpHost) || string.IsNullOrWhiteSpace(settings.EmailFrom) || string.IsNullOrWhiteSpace(settings.EmailTo))
            return "Email skipped: SMTP host/from/to is missing.";

        using var smtp = new SmtpClient(settings.SmtpHost, settings.SmtpPort)
        {
            EnableSsl = settings.SmtpEnableSsl
        };

        if (!string.IsNullOrWhiteSpace(settings.SmtpUser))
            smtp.Credentials = new NetworkCredential(settings.SmtpUser, settings.SmtpPassword);

        using var mail = new MailMessage(settings.EmailFrom, settings.EmailTo, subject, message);
        await smtp.SendMailAsync(mail);
        return "Email sent to " + settings.EmailTo;
    }

    private static async Task<string> SendSmsAsync(QueryAlertDeliverySettings settings, string message, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(settings.SmsWebhookUrl))
            return "SMS skipped: webhook URL is missing.";

        var payload = new
        {
            to = settings.SmsTo,
            message,
            source = "WPF Strategy Studio"
        };

        using var response = await Http.PostAsJsonAsync(settings.SmsWebhookUrl, payload, cancellationToken);
        return response.IsSuccessStatusCode
            ? "SMS webhook sent" + (string.IsNullOrWhiteSpace(settings.SmsTo) ? string.Empty : " to " + settings.SmsTo)
            : "SMS webhook failed: " + (int)response.StatusCode + " " + response.ReasonPhrase;
    }

    private static async Task<string> SendTelegramAsync(QueryAlertDeliverySettings settings, string message, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(settings.TelegramBotToken) || string.IsNullOrWhiteSpace(settings.TelegramChatId))
            return "Telegram skipped: bot token/chat id is missing.";

        string url = $"https://api.telegram.org/bot{settings.TelegramBotToken}/sendMessage";
        var payload = new
        {
            chat_id = settings.TelegramChatId,
            text = message,
            disable_web_page_preview = true
        };

        using var response = await Http.PostAsJsonAsync(url, payload, cancellationToken);
        return response.IsSuccessStatusCode
            ? "Telegram alert sent to chat " + settings.TelegramChatId
            : "Telegram alert failed: " + (int)response.StatusCode + " " + response.ReasonPhrase;
    }

}
