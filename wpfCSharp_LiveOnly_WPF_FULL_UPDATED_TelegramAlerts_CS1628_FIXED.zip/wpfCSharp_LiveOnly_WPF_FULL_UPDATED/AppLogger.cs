using System.IO;

namespace wpfCSharp_LiveOnly_WPF.Services;

public static class AppLogger
{
    private static readonly object LockObj = new();
    private static readonly string LogFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs");
    private static readonly string LogFile = Path.Combine(LogFolder, "trading-log.txt");

    public static string GetLogPath()
    {
        Directory.CreateDirectory(LogFolder);
        return LogFile;
    }

    public static void Info(string message) => Write("INFO", message);
    public static void Warn(string message) => Write("WARN", message);
    public static void Error(string message, Exception? ex = null) => Write("ERROR", ex == null ? message : message + " | " + ex);

    private static void Write(string level, string message)
    {
        lock (LockObj)
        {
            Directory.CreateDirectory(LogFolder);
            File.AppendAllText(LogFile, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff} [{level}] {message}{Environment.NewLine}");
        }
    }
}
